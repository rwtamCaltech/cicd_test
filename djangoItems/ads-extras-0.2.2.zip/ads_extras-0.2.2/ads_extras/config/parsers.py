try:
    from ConfigParser import ConfigParser
except:
    from configparser import ConfigParser
import glob
import os
import re
try:
    from ast import literal_eval
except ImportError:
    # Only python 2.6 and later have ast.literal_eval.  The below is a
    # backport of ast.literal_eval to earlier pythons.  I got it from here:
    # http://mail.python.org/pipermail/python-list/2009-September/1219992.html
    from compiler import parse
    from compiler.ast import *  # NOQA

    def literal_eval(node_or_string):  # NOQA
        """
        Safely evaluate an expression node or a string containing a Python
        expression.  The string or node provided may only consist of the following
        Python literal structures: strings, numbers, tuples, lists, dicts,  booleans,
        and None.
        """
        _safe_names = {'None': None, 'True': True, 'False': False}
        if isinstance(node_or_string, basestring):
            node_or_string = parse(node_or_string, mode='eval')
        if isinstance(node_or_string, Expression):
            node_or_string = node_or_string.node

        def _convert(node):
            if isinstance(node, Const) and isinstance(node.value,
                                                      (basestring, int, float, long, complex)):
                return node.value
            elif isinstance(node, Tuple):
                return tuple(map(_convert, node.nodes))
            elif isinstance(node, List):
                return list(map(_convert, node.nodes))
            elif isinstance(node, Dict):
                return dict((_convert(k), _convert(v)) for k, v
                            in node.items)
            elif isinstance(node, Name):
                if node.name in _safe_names:
                    return _safe_names[node.name]
            elif isinstance(node, UnarySub):
                return -_convert(node.expr)
            raise ValueError('malformed string')
        return _convert(node_or_string)

from ads_extras.config import (NoSuchConfigFileException, NoIncludedConfigFilesException,
                                   NotThisOptionTypeException)
from ads_extras.config.options import (EnvironmentVariableOption, AWSMetadataOption, RawOption)


class IncludingConfigParser(object):

    def __init__(self, allow_python_literals=False):
        self.allow_python_literals = allow_python_literals

    def buildIncludeFileList(self, raw_includes, path=''):
        includes = list()
        for i in raw_includes:
            if not os.path.isabs(i):
                i = os.path.join(path, i)
            matches = glob.glob(i)
            if not matches and not re.search("[\[\]*?]+", i):
                raise NoSuchConfigFileException("Included file \"%s\" not found" % i)
            includes.extend(matches)
        return includes

    def getIncludes(self, config):
        if config.has_section('control'):
            if config.has_option('control', 'includes'):
                raw_includes = [x.strip() for x in config.get('control', 'includes', raw=True).split(',')]
                return(raw_includes)
        else:
            raise NoIncludedConfigFilesException('no included config files found')

    def getMainConfig(self, config_file):
        if self.allow_python_literals:
            config = EvaluatingConfigParser()
        else:
            config = ConfigParser()
        if not os.path.exists(config_file):
            raise NoSuchConfigFileException("%s does not exist" % config_file)
        config.readfp(open(config_file))
        return(config)

    def read(self, config_file):
        config = self.getMainConfig(config_file)
        path = os.path.dirname(os.path.abspath(config_file))
        try:
            raw_includes = self.getIncludes(config)
            includes = self.buildIncludeFileList(raw_includes, path)
            config.read(includes)
        except NoIncludedConfigFilesException:
            pass
        return(config)


class EvaluatingConfigParser(ConfigParser):
    """
    This subclass of ConfigParser overrides the ``get`` method to
    perform some further evaluation of option values.

    Currently, this means:

        * Try to evaluate the value according to :class:`~ads_extras.configs.options.EnvironmentVariableOption`
        * Then try to evaluate the value according to :class:`~ads_extras.configs.options.ConsulServiceOption`
        * Finally, evaluate the results as a python literal.
    """

    option_types = [
        EnvironmentVariableOption,
        AWSMetadataOption,
        RawOption
    ]

    # keep the capitalization of our options
    optionxform = str

    def evaluate_value(self, value, raw=False):
        if not raw:
            # we should be checking here for whether
            # `value` is a dict, list ot tuple and iterating
            # through them if so
            for option_type in self.option_types:
                try:
                    value = option_type.process(value)
                except NotThisOptionTypeException:
                    pass
                try:
                    value = literal_eval(value)
                except (ValueError, SyntaxError):
                    pass
        try:
            return literal_eval(value)
        except (ValueError, SyntaxError):
            return value

    def get(self, section, option, **kwargs):
        """
        Ask `ConfigParser` for the value for an option, evaluating the option
        value for any special values (environment variables, Consul service
        lookups, etc.) and then evaluating that subsequent value into Python
        literal type if possible.

        :param section: the name of the section in our config files
        :type section: string

        :param key: the key in `section` in our config files
        :type key: string

        This is included in the kwargs, since py3 has other keyword args that have to
        be passed in:
        :param raw: don't do `ConfigParser` % interpolations or
                    any of our special evaluations (environment
                    variable expansion, etc.).
                    Still do interpret as python literals, however.
        :type raw: boolean

        :rtype: varies
        """
        value = super(EvaluatingConfigParser, self).get(section, option, **kwargs)
        return self.evaluate_value(value, raw=kwargs['raw'])

    def items(self, section, raw=False):
        """
        Return a list of (option, value) tuples for a section, evaluating the
        option values for any special values (environment variables, Consul
        service lookups, etc.) and then evaluating that subsequent value into
        Python literal type if possible.

        :param section: the name of the section in our config files
        :type section: string

        :param key: the key in `section` in our config files
        :type key: string

        :param raw: don't do `ConfigParser` % interpolations or
                    any of our special evaluations (environment
                    variable expansion, Consul service lookups, etc.).
                    Still do interpret as python literals, however.
        :type raw: boolean
        """
        items = ConfigParser.items(self, section, raw)
        evaluated_items = []
        for k, v in items:
            evaluated_items.append((k, self.evaluate_value(v, raw=raw)))
        return evaluated_items


class NamespacedIncludingConfigParser(IncludingConfigParser):

    def read(self, config_file):
        config = self.getMainConfig(config_file)
        path = os.path.dirname(os.path.abspath(config_file))
        raw_includes = self.getIncludes(config)
        includes = self.buildIncludeFileList(raw_includes, path)
        configs = dict()
        for i in includes:
            if self.allow_python_literals:
                c = EvaluatingConfigParser()
            else:
                c = ConfigParser()
            c.read(i)
            if not c.has_section('control'):
                c.add_section('control')
            c.set('control', 'origin', i)
            key = os.path.basename(os.path.splitext(i)[0])
            configs[key] = c
        return(configs)
