try:
    import ConfigParser
except:
    import configparser as ConfigParser
import functools
import os

from ads_extras.config.dict import EvaluatingDict
from ads_extras.config.parsers import (IncludingConfigParser, EvaluatingConfigParser)
from ads_extras.logging.Logging import get_default_logger


class AbstractAppContext(object):

    def clear(self):
        """
        Clear out any options and values we may have loaded.
        """
        raise NotImplementedError

    def get(self, section, option, **kwargs):
        """
        Get an option.  If the option or section does not exist, raise
        the appropriate `ConfigParser` exception.

        :param section: the name of the section in our config files
        :type section: string

        :param key: the key in `section` in our config files
        :type key: string

        :rtype: varies
        """
        return self.config.get(section, option, **kwargs)  # pylint: disable=E1101

    def get_safe(self, section, option, default, **kwargs):
        """
        Get an option.  If the option or section does not exist,
        return ``default`` instead.

        :param section: the section from the config file
        :type section: string

        :param option: the option from ``section`` in the config file
        :type option: string

        :param default: return this if ``section`` or ``option`` do not
                        exist
        :type default: varies

        :rtype: varies or the type of ``default``
        """
        retval = default
        try:
            retval = self.get(section, option, **kwargs)
        except (ConfigParser.NoSectionError, ConfigParser.NoOptionError, ValueError):
            pass
        return retval

    def getarray(self, section, option):
        """
        This method allows you to use configs that include a comma-separated
        list of values. For example if we have this section in our config file:

            [some_section]
            options = foo, baz, bar

            config.getarray('some_section', 'options') will return ['foo', 'baz', 'bar']

        :param section: the section from the config file
        :type section: string

        :param option: the option from ``section`` in the config file
        :type option: string

        :rtype: list
        """
        return [x.strip() for x in self.get(section, option).split(",")]

    def getdictionary(self, section, option):
        """
        This method allows you to create configs that contain multi-line
        dictionaries. For example, a config file like this:

            [oracle_ldap_sync:address-mapping]
            mapping = address_line1: CAPAddressLine1,
             city: l,
             state: st,
             zipcode: postalCode,

        ..note::

            The second and subsequent lines of this dictionary are indented one
            space to enable the dictionary to be parsed.

        Can be read with ``config.getdictionary('oracle_ldap_sync:address-mapping', 'mapping')``
        and will return the dicctionary:

            {'address_line1': 'CAPAddressLine1',
             'city': 'l',
             'state': 'st',
             'zipcode': 'postalCode'}

        :param section: the section from the config file
        :type section: string

        :param option: the option from ``section`` in the config file
        :type option: string

        :rtype: dict
        """
        config_array = self.getarray(section, option)
        config_dict = {}
        for item in config_array:
            item_array = item.split(":")
            if len(item_array) == 2:
                config_dict[item_array[0]] = item_array[1].strip()
        return config_dict

    def sections(self):
        """
        Return a list of available sections.

        :rtype: list
        """
        return self.config.sections()  # pylint: disable=E1101

    def options(self, section):
        """
        Return a list of available options in ``section``.

        :param section: the section from the config file
        :type section: string

        :rtype: list
        """
        return self.config.options(section)  # pylint: disable=E1101

    def items(self, section, **kwargs):
        """
        Return a list of (name, value) pairs for each option in the given section.

        :param section: the section from the config file
        :type section: string

        :rtype: list of tuples
        """
        return self.config.items(section, **kwargs)

    def to_dict(self, *args, **kwargs):
        """
        Return all the sections, options and values in our ConfigParser object
        as a nested dictionary.

        This is for dependent modules (e.g. access.caltech-core) that need to
        accept configuration options from a variety of sources and thus have
        settled on dictionaries as a neutral format.

        :rtype: dictionary
        """
        output = {}
        for section in self.sections():
            if section == 'control':
                continue
            output[section] = {}
            for k, v in self.items(section):
                output[section][k] = v
        return output


class ToEvaluatingDictMixin(object):

    def to_dict(self):
        """
        Return all the sections, options and values in our AppContext object
        as a nested dictionary-like.  In this case, we're returning a nested
        :class:`ads_extras.config.dict.EvaluatingDict`, which is like a `dict()`
        but will evaluate any values matching "``CONSUL:SERVICE:*``" at time
        of retrieval.

        This is for dependent modules (e.g. access.caltech-core) that need to
        accept configuration options from a variety of sources and thus have
        settled on dictionaries as a neutral format.

        :rtype: dictionary
        """
        output = EvaluatingDict()
        for section in self.sections():
            if section == 'control':
                continue
            output[section] = EvaluatingDict()
            for k, v in self.items(section, raw=True):
                output[section][k] = self.get(section, k)
        return output


class FileBasedAppContext(ToEvaluatingDictMixin, AbstractAppContext):
    """
    A file based, including, evaluating ConfigParser-like object.

    By "including", we mean we will merge many independent config files on disk
    into a single ``ConfigParser`` object.  If the main config file file
    (typically "``/etc/context.conf``" contains a ``[control]`` section with an
    ``includes`` option, merge in all config files that match the ``includes``
    glob.   Example::

        [control]
        includes=/etc/context.d/*.conf

    will cause ``FileBasedAppContext`` to merge all config files that match
    "``/etc/context.d/*.conf``" into a single ``ConfigParser`` object.

    By "evaluating", we mean that we will evaluate all option values as Python
    literals -- booleans, lists, dicts, tuples, integers and floats.  To ensure
    something will be evaluated as a string, enclose it in quotes.

    ..note::

        ``FileBasedAppContext`` only reads its config files from disk once,
        at instatiation time.  It then caches what it read into a class variable
        and thereafter all ``.get()`` calls will read from the cached version.
        This means that if you change a config file on disk and want the change
        to be noticed by the running process, you'll need to restart the running
        process.

    There are a few special kinds of options available in this class:

     * If the option's value looks like "ENV:<env_var>" (e.g. ENV:MY_PASSWORD)
       look in the environment for the environment variable named `<env_var>` and
       return its value instead.

     * If the option's value looks like "ENV:<env_var>:<default_value>"
       (e.g. ENV:MY_PASSWORD:abcded), look in the environment for the environment
       variable named `<env_var>` and return its value instead.  If `<env_var>` does not exist
       in the environment, return `<default_value>`.

     * If the option's value looks like "CONSUL:SERVICE:<service_name>" (e.g.
       ``CONSUL:SERVICE:db``), contact the Consul server on its DNS interface,
       look up the hostnames and ports for the service and return the first one
       in the list.  Consul randomizes the ordering of hosts in a particular
       service, so we can use that as a poor man's load balancer.

     * If the option's value looks like "CONSUL:SERVICE:<service_name>:ALL" (e.g.
       ``CONSUL:SERVICE:db``), contact the Consul server on its DNS interface,
       look up the hostnames and ports for the service and return the full list of
       servers as a python list.

     * If the option's value looks like "AWS:METADATA:<key>" (e.g.
       ``AWS:METADATA:LOCAL-IPADDRESS``), retrieve the EC2 instance metadata and return
       the appropriate value.  This only works if we're on an EC2 instance.

       ``key`` can take one of four values:

        * ``LOCAL-IPADDRESS``:  return the local IP address for the instance.  This
          will be an address from one of the private IP address ranges (10.0.0.0/8,
          192.168.0.0/16, 172.16.0.0/12)
        * ``LOCAL-HOSTNAME``: the AWS hostname associated with our local IP address
        * ``PUBLIC-IPADDRESS``: the public ipaddress for the instance.  If the instance
          is in a private subnet, it will not have a public ipaddress, and accessing
          this option will cause ``KeyError`` to be rasied
        * ``PUBLIC-HOSTNAME``: the public hostname for the instance.  If the instance
          is in a private subnet, it will not have a public hostname, and accessing
          this option will cause ``KeyError`` to be rasied

    ..note::

        For the ``CONSUL:SERVICE`` type options, tell us where to find the
        Consul DNS server by exporting the environment variable
        "``CONSUL_SERVER=<host>``" (e.g.  ``CONSUL_SERVER=192.168.99.100``).
        You may also do one of these if you are running your code on an
        EC2 instance:

        * ``CONSUL_SERVER=AWS:METADATA:LOCAL-IPADDRESS``
        * ``CONSUL_SERVER=AWS:METADATA:LOCAL-HOSTNAME``
        * ``CONSUL_SERVER=AWS:METADATA:PUBLIC-IPDADRESS``
        * ``CONSUL_SERVER=AWS:METADATA:PUBLIC-HOSTNAME``

        If the environment variable ``CONSUL_SERVER`` is not set, we will assume
        that the Consul DNS server answers on 127.0.0.1:53 UDP.
    """

    _shared_state = {}

    def __init__(self, config_file="/etc/context.conf"):
        config_file = os.environ.get('CONTEXT_CONF', config_file)
        if "config" not in self._shared_state:
            self._shared_state["config"] = self.read(config_file)
        self.__dict__ = self._shared_state

    def get(self, section, option, raw=False):
        """
        Return the value of option ``option`` from section ``section``.

        :param section: the name of the section in our config files
        :type section: string

        :param key: the key in `section` in our config files
        :type key: string

        :param raw: if ``True``, then don't evaluate the value to be returned
                    (for instance, if the value of the option is "``ENV:FOOBAR``", return
                    "``ENV:FOOBAR``" instead of the value of the environment variable.
        :type section: boolean

        :rtype: varies
        """
        return super(FileBasedAppContext, self).get(section, option, raw=raw)

    def clear(self):
        """
        Clear out our saved options and values.
        """
        self.__class__._shared_state = {}

    def read(self, config_file):
        """
        Read in the ConfigParser files from disk, evaluate all option values as
        Python literals.

        :rtype: ConfigParser
        """
        return(IncludingConfigParser(allow_python_literals=True).read(config_file))


class AppContext(AbstractAppContext):
    """
    This is a proxywrapper for the actual ``AppContext`` implementations.  There are
    two modes: 'file' and 'consul'.

    In 'file' mode, use :class:`.FileBasedAppContext` as our ``AppContext``
    implementation.

    In 'consul' mode, use :class:`.ConsulKeyValueStoreAppContext` as our
    ``AppContext`` implementation.

    The mode can be set either via the constructor keyword argument "mode":

        context = AppContext(mode='file')

    or via the ``CONTEXT_MODE`` environment variable:

        os.environ['CONTEXT_MODE'] = 'file'
        context = AppContext()

    If both the keyword argument and the environment variable are set, the
    keyword argument wins.
    """

    def __init__(self, *args, **kwargs):
        context_mode = 'file'
        if 'mode' in kwargs:
            context_mode = kwargs['mode']
            del kwargs['mode']
        else:
            context_mode = os.environ.get("CONTEXT_MODE", context_mode)
        self.context = FileBasedAppContext(*args, **kwargs)

    def clear(self):
        self.context.clear()

    def get(self, section, key, **kwargs):
        return self.context.get(section, key, **kwargs)

    def get_safe(self, section, key, default, **kwargs):
        return self.context.get_safe(section, key, default, **kwargs)

    def getarray(self, section, option):
        return self.context.getarray(section, option)

    def getdictionary(self, section, option):
        return self.context.getdictionary(section, option)

    def sections(self):
        return self.context.sections()

    def options(self, section):
        return self.context.options(section)

    def items(self, section, **kwargs):
        return self.context.items(section, **kwargs)

    def to_dict(self, *args, **kwargs):
        return self.context.to_dict(*args, **kwargs)
