import os

from ads_extras.config import (NoSuchEnvironmentVariableException, NotThisOptionTypeException, NotEC2InstanceException)
from ads_extras.logging.Logging import get_default_logger


class AbstractOption(object):

    @staticmethod
    def process(value):
        raise NotImplementedError


class EnvironmentVariableOption(AbstractOption):
    """
    If the option's value looks like "ENV:<env_var>" (e.g. ENV:MY_PASSWORD)
    look in the environment for the environment variable named `<env_var>` and
    return its value instead.

    If the option's value looks like "ENV:<env_var>:<default_value>" (e.g.
    ENV:MY_PASSWORD:abcded), look in the environment for the environment
    variable named `<env_var>` and return its value instead.  If `<env_var>`
    does not exist in the environment, r return `<default_value>`.

    :param value: a value from a ``ConfigParser`` option to evaluate
    :type value: string

    :rtype: string or list of strings
    """

    @staticmethod
    def process(value):
        if hasattr(value, 'capitalize') and value.startswith("ENV:"):
            tail = value[4:]
            fields = tail.split(":", 1)
            env_var = fields[0]
            default_value = None
            if len(fields) > 1:
                default_value = fields[1]
            if env_var not in os.environ:
                if not default_value:
                    raise NoSuchEnvironmentVariableException("The environment variable {0} does not exist".format(env_var))
                else:
                    value = default_value
            else:
                value = os.environ.get(env_var)
            return value
        else:
            raise NotThisOptionTypeException


class AWSMetadataOption(AbstractOption):
    """
    This option type is only useful for code that is running on an AWS
    EC2 instance, because it extracts values from the AWS instance metadata.

    If the option's value looks like "AWS:METADATA:<key>" (e.g.
    ``AWS:METADATA:LOCAL-IPADDRESS``), retrieve the instance metadata and return
    the appropriate value.

    ``key`` can take one of four values:

    * ``LOCAL-IPADDRESS``:  return the local IP address for the instance.  This
      will be an address from one of the private IP address ranges (10.0.0.0/8,
      192.168.0.0/16, 172.16.0.0/12)
    * ``LOCAL-HOSTNAME``: the AWS hostname associated with our local IP address
    * ``PUBLIC-IPADDRESS``: the public ipaddress for the instance.  If the instance
      is in a private subnet, it will not have a public ipaddress, and accessing
      this option will cause ``KeyError`` to be rasied
    * ``PUBLIC-HOSTNAME``: the public hostname for the instance.  If the instance
      is in a private subnet, it will not have a public hostname, and accessing
      this option will cause ``KeyError`` to be rasied

    :param value: a value from a ``ConfigParser`` option to evaluate
    :type value: string

    :rtype: string or list of strings
    """

    @staticmethod
    def process(value):
        if hasattr(value, 'capitalize') and value.startswith("AWS:METADATA:"):
            import boto.utils
            metadata = boto.utils.get_instance_metadata(timeout=15)
            if not metadata:
                raise NotEC2InstanceException
            key = value.split(':')[2]
            if key == 'LOCAL-IPADDRESS':
                return metadata['local-ipv4']
            if key == 'PUBLIC-IPADDRESS':
                return metadata['public-ipv4']
            elif key == 'LOCAL-HOSTNAME':
                return metadata['local-hostname']
            elif key == 'PUBLIC-HOSTNAME':
                return metadata['public-hostname']
            else:
                raise KeyError
        else:
            raise NotThisOptionTypeException


class RawOption(AbstractOption):

    @staticmethod
    def process(value):
        return value


class ConsulServerOption(AbstractOption):
    """
    This option is only used when evaluating the CONSUL_SERVER
    environment variable.  Either use the value directly, or
    interpret it as an AWS metadata lookup.
    """

    @staticmethod
    def process(value):
        option_types = [
            AWSMetadataOption,
            RawOption
        ]

        for option_type in option_types:
            try:
                value = option_type.process(value)
            except NotThisOptionTypeException:
                pass
        return value
