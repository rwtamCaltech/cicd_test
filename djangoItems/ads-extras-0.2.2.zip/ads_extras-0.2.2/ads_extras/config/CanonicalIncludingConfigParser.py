import ConfigParser
import os

from ads_decorators.config import NoIncludedConfigFilesException
from ads_decorators.config.parsers import (EvaluatingConfigParser, IncludingConfigParser)

try:
    from collections import OrderedDict
except ImportError:
    # Before Python 2.7/3.1, OrderedDict isn't in the std library.
    from ads_decorators.utils.OrderedDict import OrderedDict


# CanonicalIncludingConfigParser can't move to parsers.py without updating
# zookeeper/rolodex, because that code imports this class directly from this
# file

class CanonicalIncludingConfigParser(IncludingConfigParser):

    """
    ``CanonicalIncludingConfigParser`` searches for all ``ConfigParser``
    compatible configuration files in the given directory and loads them into a
    single namespace, It will re-read all config files from  disk each time
    read() is called, allowing for changes to the configs without restarting the
    server.

    Why would you use this class instead of ``AppConfig``?   Imagine that your
    application has a lot of configuration and that that configuration is likely
    to change after the deployment of the application.  ``rolodex`` is the
    perfect example.  ``rolodex`` serves lists of contact information based on
    (among other things) LDAP searches, flatfiles and other backend sources.
    Using ``CanonicalIncludingConfigParser`` allows the unix-admins to add and
    modify list configuration after the app has been installed and without
    having to muck with the other configuration in the app.

    ``directory`` is the name of the directory containing your application's
    config files.  ``CanonicalIncludingConfigParser`` will load any ``*.conf``
    files in that directory.

    If ``allow_python_literals`` is set to ``True``, then values of options in
    the included config files will be evaluated as python literals: strings,
    lists, numbers and dictionaries.  Default: False.

    If ``case_sensitive`` is set to ``True``, then the option names will retain
    their case.   Normal ``ConfigParser`` operation is to lowercase all option
    names.

    """

    def __init__(self, directory, allow_python_literals=False,
                 case_sensitive=False):
        IncludingConfigParser.__init__(self, allow_python_literals)
        self.case_sensitive = case_sensitive
        self.raw_includes = os.path.join(directory, "*.conf")

    def getMainConfig(self):
        """
        This is almost the same function as IncludingConfigParser.getMainConfig;
        it just adds the case_sensitive functionality.
        """
        # Because some of our software cares about the order in which options appear
        # in config files, we use an OrderedDict for our config parsers.
        if self.allow_python_literals:
            config = EvaluatingConfigParser(dict_type=OrderedDict)
        else:
            config = ConfigParser.ConfigParser(dict_type=OrderedDict)
        if self.case_sensitive:
            # RawConfigParser.optionxform() calls lower() on option name strings.
            # With case_sensitive we want optionxform() to be a no-op instead.
            config.optionxform = lambda x: x  # NOQA
        return config

    def read(self):
        config = self.getMainConfig()
        try:
            includes = self.buildIncludeFileList([self.raw_includes])
            config.read(includes)
        except NoIncludedConfigFilesException:
            pass
        return(config)
