import ConfigParser


class Config:
    __shared_state = {}

    def __init__(self, app_name, config_file=None):
        if not self.__shared_state.get(app_name, None):
            if not config_file:
                raise Exception('configuration not seeded')
            else:
                self.__shared_state[app_name] = {}
                self.__shared_state[app_name][
                    '_config'] = self.__parse_configuration(config_file)

        self.__dict__ = self.__shared_state[app_name]

    def get(self, section, key):
        return self._config.get(section, key)  # pylint: disable=E1101

    def getint(self, section, key):
        return self._config.getint(section, key)  # pylint: disable=E1101

    def getboolean(self, section, key):
        return self._config.getboolean(section, key)  # pylint: disable=E1101

    def options(self, section):
        return self._config.options(section)  # pylint: disable=E1101

    def items(self, section):
        return self._config.items(section)  # pylint: disable=E1101

    def sections(self):
        return self._config.sections()  # pylint: disable=E1101

    def __parse_configuration(self, config_file):
        config = ConfigParser.ConfigParser()
        files_read = config.read(config_file)
        if len(files_read) == 0:
            raise IOError("Can't find %s!" % config_file)
        return config
