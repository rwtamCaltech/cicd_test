import ConfigParser
import os
import socket

from ads_decorators.config import NoConfigFilesException
from ads_decorators.config.parsers import NamespacedIncludingConfigParser


class RawAppConfig(object):

    _shared_state = {}

    @staticmethod
    def getConfigFilename(config_file=None):
        """
        Return the full path to our top level AppConfig file.

        If the environment variable `APPS_CONF` exists, use that as the
        full path to our AppConfig file.

        The 'apps.conf' file should contain a section named 'control' that
        indicates where to find the config files for all the apps on this
        server.

        Example `apps.conf` file:

            [control]
            includes = /srv/ads/python/etc/*.conf

        :param config_file: (optional) if supplied, look here for our apps.conf
        :type config_file: string

        :rtype: string
        """
        if 'APPS_CONF' in os.environ:
            config_file = os.environ['APPS_CONF']
        if not config_file:
            config_files = ['/srv/%s/ads/python/apps.conf' % socket.gethostname(),
                            '/srv/localhost/ads/python/apps.conf',
                            '/srv/ads/python/apps.conf']
            for cf in config_files:
                if os.path.exists(cf):
                    config_file = cf
                    break
            if not config_file:
                raise NoConfigFilesException(
                    'no config files found in any of these locations: %s' %
                    ','.join(config_files))
        config_file = os.path.abspath(config_file)
        return(config_file)

    def __init__(self, app, config_file=None, reread_file=False):
        self.load(app, config_file, reread_file)

    @classmethod
    def clear(cls):
        cls._shared_state = {}

    def read(self, config_file=None):
        return(NamespacedIncludingConfigParser().read(RawAppConfig.getConfigFilename(config_file)))

    def load(self, app, config_file=None, reread_file=False):
        # If the data has not yet been read from disk, or the reread_file arg is
        # True, rebuild the config data borg.
        if self._shared_state == {} or reread_file:
            configs = self.read(config_file)
            for k in configs.keys():
                self._shared_state[k] = {}
                self._shared_state[k]['config'] = configs[k]
            self.__dict__ = self._shared_state[app]
        # Set our data up from the borg
        self.__dict__ = self._shared_state[app]

    def get(self, section, key, raw=False):
        """
        Get an option.  If the option or section does not exist, raise
        the appropriate `ConfigParser` exception.

        If the option's value looks like "ENV:<env_var>" (e.g. ENV:MY_PASSWORD)
        look in the environment for the environment variable named `<env_var>` and
        return its value instead.

        :param section: the name of the section in our config files
        :type section: string

        :param key: the key in `section` in our config files
        :type key: string

        :rtype: varies
        """
        return self.config.get(section, key)  # pylint: disable=E1101

    def get_safe(self, section, key, raw=False, default=None):
        """
        Get an option.  If the option or section  does not exist, return
        ``default`` instead.

        Values will be interpreted as python literals
        before being returned (so the string "True" will be returned as
        the boolean ``True``, for instance).

        :param section: the section from the config file
        :type section: string

        :param option: the option from ``section`` in the config file
        :type option: string

        :param raw: if ``True``, don't interpret values as python literals
        :type raw: boolean

        :param default: return this if ``section`` or ``option`` do not
                        exist
        :type default: varies

        :rtype: string or the type of ``default``
        """
        retval = default
        try:
            retval = self.get(section, key, raw)
        except (ConfigParser.NoSectionError, ConfigParser.NoOptionError, ValueError):
            pass
        return retval

    def getint(self, section, option):
        return self.config.getint(section, option)  # pylint: disable=E1101

    def getfloat(self, section, option):
        return self.config.getfloat(section, option)  # pylint: disable=E1101

    def getboolean(self, section, option):
        try:
            return self.config.getboolean(section, option)  # pylint: disable=E1101
        except AttributeError:
            # We're evaluating all our option values as python literals.  If we set our boolean
            # value to 1 expecting that to evaluate to True, the python evaluation will convert
            # the 1 to an int and then self.config.getboolean will throw an exception, since it
            # expected a string.
            value = self.config.get(section, option)  # pylint: disable=E1101
            if type(value) == int:
                if value == 1:
                    return True
                elif value == 0:
                    return False

    def getarray(self, section, option):
        """
        This method allows you to use configs that include a
        comma-separated list of values. For example if we have this
        section in our config file:

        [some_section]
        options = foo, baz, bar

        config.getarray('some_section', 'options') will return ['foo', 'baz', 'bar']
        """
        return [x.strip() for x in self.get(section, option).split(",")]

    def getdictionary(self, section, option):
        """
        This method allows you to create configs that contain
        multi-line dictionaries. For example, a config file like this:

            [oracle_ldap_sync:address-mapping]
            mapping = address_line1: CAPAddressLine1,
             city: l,
             state: st,
             zipcode: postalCode,

        Can be read with config.getdictionary('oracle_ldap_sync:address-mapping', 'mapping')
        and will return the dictionary:

            {'address_line1': 'CAPAddressLine1', 'city': 'l', 'state': 'st', 'zipcode': 'postalCode'}

        NB, the second and subsequent lines of this dictionary are
        indented one space to enable the dictionary to be parsed.

        """
        config_array = self.getarray(section, option)
        config_dict = {}
        for item in config_array:
            item_array = item.split(":")
            if len(item_array) == 2:
                config_dict[item_array[0]] = item_array[1].strip()
        return config_dict

    def options(self, section):
        return self.config.options(section)  # pylint: disable=E1101

    def items(self, section):
        return self.config.items(section)  # pylint: disable=E1101

    def sections(self):
        return self.config.sections()  # pylint: disable=E1101


class AppConfig(RawAppConfig):

    _shared_state = {}

    def read(self, config_file=None):
        return(NamespacedIncludingConfigParser(allow_python_literals=True).read(RawAppConfig.getConfigFilename(config_file)))
