import collections

from ads_extras.config import NotThisOptionTypeException
from ads_extras.config.options import RawOption


class EvaluatingDict(collections.MutableMapping):
    """
    This works exactly like a regular Python dictionary except that certain
    values will be evaluated at retrieval time.  Notably:

     * If the value looks like "CONSUL:SERVICE:<service_name>" (e.g.
       ``CONSUL:SERVICE:db``), contact the Consul server on its DNS interface,
       look up the hostnames and ports for the service and return the first one
       in the list.  Consul randomizes the ordering of hosts in a particular
       service, so we can use that as a poor man's load balancer.

     * If the value looks like "CONSUL:SERVICE:<service_name>:ALL" (e.g.
       ``CONSUL:SERVICE:db``), contact the Consul server on its DNS interface,
       look up the hostnames and ports for the service and return the full list of
       servers as a python list.

    ..note::

        For the ``CONSUL:SERVICE`` type options, tell ``EvaluatingDict``
        where to find the Consul DNS server by exporting the environment
        variable "``CONSUL_SERVER=<host>``" (e.g.
        ``CONSUL_SERVER=192.168.99.100``)

        If the environment variable ``CONSUL_SERVER`` is not set,
        ``EvaluatingDict`` will assume that the Consul DNS server answers on
        127.0.0.1:8600.
    """

    value_types = [
        RawOption
    ]

    def __init__(self, *args, **kwargs):
        self.store = dict()
        self.update(dict(*args, **kwargs))

    def __getitem__(self, key):
        value = self.store[key]
        for t in self.value_types:
            try:
                value = t.process(value)
            except NotThisOptionTypeException:
                pass
        return value

    def __setitem__(self, key, value):
        self.store[key] = value

    def __delitem__(self, key):
        del self.store[key]

    def __iter__(self):
        return iter(self.store)

    def __len__(self):
        return len(self.store)
