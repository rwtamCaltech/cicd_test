from ads_decorators.exception.ExceptionCatcher import ExceptionCatcher
from mod_python import apache #@UnresolvedImport

class ModPythonSafeExceptionCatcher(ExceptionCatcher):
    """
    Just like ExceptionCatcher, except that it ignores mod_python apache exceptions
    used for flow control: redirects, 404 not found, etc.
    """
    
    def __init__(self, *args, **kwargs):
        ExceptionCatcher.__init__(self, *args, **kwargs)
        
    def __call__(self, function):
        def decorate(*args, **kwargs):
            try:
                obj = function(*args,**kwargs)
                return obj
            except apache.SERVER_RETURN:
                raise
            except:
                self.sendMessage(function, args, kwargs)
                raise
        decorate.__name__ = function.__name__
        decorate.__doc__ = function.__doc__
        decorate.__dict__.update(function.__dict__)
        return decorate 