from ads_decorators.logging.Logging import get_default_logger
from datetime import datetime
import StringIO
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
import traceback
import socket
from ads_decorators.config.AppContext import AppContext
from ConfigParser import NoOptionError

class ExceptionCatcher(object):
    
    """
    When a method on a class is wrapped with this decorator, if any Exception is
    emitted by that method, ``ExceptionCatcher`` will catch it and send an email to
    a specified e-mail address describing the exception.  Here's an example of
    how to use it::
    
        class Foo(object):
        
            @ExceptionCatcher('foo', toAddr='bar@caltech.edu)
            def amethod(self)
                # ...some code

    When an exception is caught, the resulting e-mail looks something like this::
    
        In foo::foo.bar.Foo, amethod(). 
        Timestamp: Fri Jan  4 12:13:49 2013
        
        Host: someserver.caltech.edu
        Service: foo
        Module: foo.bar.Foo
        Function name: amethod
        Invocation: amethod(args: (), kwargs: {})
        Function code: <code object amethod at 0x9ab39a0, file "/srv/ads/python/foo/bar/Foo.py", line 864>
        
        ================================================================
        Traceback (most recent call last):
          ... Traceback here ...
          
    E-mails will come from ``exception-catcher@caltech.edu``.

    """
    
    def __init__(self, program_name='default',
                       server="smtp-server.its.caltech.edu", 
                       toAddr="imss-ads-staff@caltech.edu", 
                       smtp_user=None, 
                       smtp_pass=None):
        """
        Constructor.
        
        :type program_name: string
        :param program_name: In the notification email, mark the
                             exception as coming from program ``program_name``.

        :type server: string
        :param server: Use ``server`` as the SMTP server to use to 
                       send our mail. Default: smtp-server.its.caltech.edu.

        :type toAddr: string
        :param server: send mails to the email address ``toAddr``.
                       Default: imss-ads-staff@caltech.edu.
                       
        :type smtp_user: string
        :param smtp_user: For authenticated SMTP, use ``smtp_user`` as the
                          username.  ``ExceptionCatcher`` will only use 
                          authenticated SMTP if both ``smtp_user`` and
                          ``smtp_pass`` are passed to the constructor.
                          
        :type smtp_pass: string
        :param smtp_pass: For authenticated SMTP, use ``smtp_pass`` as the
                          password.  ``ExceptionCatcher`` will only use 
                          authenticated SMTP if both ``smtp_user`` and
                          ``smtp_pass`` are passed to the constructor.
         
        
        """
        self.__program = program_name
        self.__server = server
        self.__smtp_user = smtp_user
        self.__smtp_pass = smtp_pass
        self.__toAddr = toAddr
        self.__fromAddr = "exception_catcher@caltech.edu"
        self.__replyTo = toAddr

    def _composeBody(self, f, args, kwargs):
        mesg_args = dict()
        mesg_args["hostname"] = socket.gethostname()
        mesg_args["service"] = self.__program
        mesg_args["function_name"] = f.__name__
        mesg_args["module"] = f.__module__
        mesg_args["function_code"] = f.func_code
        mesg_args["args"] = str(args)
        mesg_args["kwargs"] = str(kwargs)
        mesg_args["timestamp"] = datetime.now().strftime("%c")
        sio = StringIO.StringIO()
        traceback.print_exc(None, sio)
        exception_trace = sio.getvalue()
        sio.close()
        mesg_args["exception_trace"] = exception_trace
        body = """
In %(service)s::%(module)s, %(function_name)s().
Timestamp: %(timestamp)s

Host: %(hostname)s
Service: %(service)s
Module: %(module)s
Function name: %(function_name)s
Invocation: %(function_name)s(args: %(args)s, kwargs: %(kwargs)s)
Function code: %(function_code)s

================================================================
%(exception_trace)s
    """ % mesg_args
        return body

        
    def _composeSubject(self, f):
        return("ExceptionCatcher(%s): Uncaught exception detected in %s" % (self.__program, "%s.%s" % (f.__module__, f.__name__)))

    def _buildMessage(self, f, args, kwargs):
        message = MIMEMultipart()
        message["Subject"] = self._composeSubject(f)
        message["From"] = self.__fromAddr
        message["To"] = self.__toAddr
        message["Reply-To"] = self.__replyTo
        body = self._composeBody(f, args, kwargs)
        message.attach(MIMEText(body))
        return(message.as_string())
    
    def sendMessage(self, f, args, kwargs):
        message = self._buildMessage(f, args, kwargs)
        try:
            server = smtplib.SMTP(self.__server)
            if (self.__smtp_user and self.__smtp_pass):
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login(self.__smtp_user, self.__smtp_pass)
                print "bound to %s as %s" % (self.__server, self.__smtp_user)
        except Exception, e:
            l = get_default_logger(program="ExceptionCatcher")
            l.fatal("ExceptionCatcher had this problem sending: %s %s %s" % (self.__server, e.__class__, e))
        else:
            server.set_debuglevel(0)
            server.sendmail(self.__fromAddr, self.__toAddr, message)
            server.quit()
        
    def __call__(self, function):
        def decorate(*args, **kwargs):
            try:
                obj = function(*args,**kwargs)
                return obj
            except:
                self.sendMessage(function, args, kwargs)
                raise
        decorate.__name__ = function.__name__
        decorate.__doc__ = function.__doc__
        decorate.__dict__.update(function.__dict__)
        return decorate 

class ContextReadingExceptionCatcher(ExceptionCatcher):
    """
    This subclass of ``ExceptionCatcher`` reads the ``server``,
    ``toAddr``, ``smtp_user`` and ``smtp_pass`` constructor arguments
    to ``ExceptionCatcher`` from an ``AppContext()`` context section.
    
    Otherwise, ``ContextReadingExceptionCatcher`` behaves just like
    ``ExceptionCatcher``.
    
    Here's an example of how to use it. Suppose your project was called
    ``foobar``.  Add these lines in `/etc/context.d/foobar.conf`::
    
        [foobar:smtp]
        smtp_server = smtp-server.its.caltech.edu
        to_address = devops@caltech.edu
        
    Then wrap your method like so::
    
        class Foo(object):
        
            @ContextReadingExceptionCatcher('foo', context_section='foobar:smtp')
            def amethod(self)
                # ...some code    
    """
    
    def __init__(self, program_name, context_section):
        """
        Constructor.
        
        The context_section should have the following keys: 
        
        * ``smtp_server``: hostname of the SMTP server to use (required)
        * ``to_address``: send the exception emails to this address (optional). Default: imss-ads-staff@caltech.edu
        * ``smtp_user``: Use Authenticated SMTP, and use this as the username (optional).
        * ``smtp_pass``: Use Authenticated SMTP, and use this as the password (optional).
        
        Example::
        
            [foobar:smtp]
            smtp_server = smtp-server.its.caltech.edu
            to_address = devops@caltech.edu
            smtp_user = devops
            smtp_pass = asdlkfj93lkj
        
        :type program_name: string
        :param program_name: In the notification email, mark the
                             exception as coming from program ``program_name``.

        :type context_section: string
        :param context_section: The name of a context section to ask AppContext()
                                to retrieve options from.
        """
        context = AppContext()
        smtp_server = context.get(context_section, 'smtp_server')
        try:
            smtp_user = context.get(context_section, 'smtp_user')
            smtp_pass = context.get(context_section, 'smtp_pass')
        except NoOptionError:
            smtp_user = None
            smtp_pass = None
        try:                
            to_address = context.get(context_section, 'to_address')
        except NoOptionError:
            to_address = "imss-ads-staff@caltech.edu"
        ExceptionCatcher.__init__(self, program_name,
                                        toAddr=to_address, 
                                        server=smtp_server, 
                                        smtp_user=smtp_user,
                                        smtp_pass=smtp_pass)
