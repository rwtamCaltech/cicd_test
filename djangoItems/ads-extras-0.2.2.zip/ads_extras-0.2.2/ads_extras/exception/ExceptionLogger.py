'''
Created on Aug 12, 2009

@author: bwicks
'''
import os.path
import traceback
import StringIO
from datetime import datetime
import stat
import socket
def FileLogged( appname = 'default', apptier = 'default' ):
    def call( function ):
        def decorate( self, *args, **kwargs ):
            _loggingContext = {}
            try:
                if not kwargs:
                    kwargs = {}
                kwargs['_loggingContext'] = _loggingContext
                handle = loghandle()
                kwargs['_logHandle'] = handle
                obj = function( self, *args, **kwargs )
                if not len( handle.lines ) == 0:
                    sio = StringIO.StringIO()
                    sio.writelines( handle.lines )
                    write_file( appname, apptier, sio.getvalue() )
                    sio.close()
                return obj
            except:
                sio = StringIO.StringIO()
                traceback.print_exc( None, sio )
                exception_trace = sio.getvalue()
                sio.close()
                sio = StringIO.StringIO()
                sio.write( '<h2>Exception</h2>' )
                sio.write( '<table>' )
                sio.write( '<tr><td>timestamp</td><td>%s</td></tr>' % ( datetime.now().strftime( "%c" ) ) )
                sio.write( '<tr><td>hostname</td><td>%s</td></tr>' % ( socket.gethostname() ) )
                sio.write( '<tr><td>function_name</td><td>%s</td></tr>' % ( function.__name__ ) )
                sio.write( '<tr><td>module</td><td>%s</td></tr>' % ( function.__module__ ) )
                sio.write( '<tr><td>function_code</td><td>%s</td></tr>' % ( function.func_code ) )
                sio.write( '<tr><td>args</td><td>%s</td></tr>' % ( str( args ) ) )
                del kwargs['_loggingContext']
                del kwargs['_logHandle']
                sio.write( '<tr><td>kwargs</td><td>%s</td></tr>' % ( str( kwargs ) ) )
                if len( _loggingContext.keys() ) <> 0:
                    sio.write( '<tr><td>_loggingContext</td><td>&nbsp;</td></tr>' )
                    for ( k, v ) in _loggingContext.items():
                        sio.write( '<tr><td>%s=%s</td></tr>' % ( k, v ) )
                sio.write( '<tr><td colspan="2"><pre>%s</pre></td></tr>' % ( exception_trace ) )
                sio.write( '</table>' )

                write_file( appname, apptier, sio.getvalue() )
                sio.close()
                raise
        decorate.__name__ = function.__name__
        decorate.__doc__ = function.__doc__
        decorate.__dict__.update( function.__dict__ )
        return decorate
    return call

def write_file( appname, apptier, msg ):
    root = '/var/tmp/ads_logging'
    dir = os.path.join( root, appname )
    dir = os.path.join( dir , apptier )
    if not os.path.exists( dir ):
        os.makedirs( dir, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP )
    rfile = os.path.join( dir, 'error.log.html' )
    fp = file( rfile, 'ab' )
    fp.write( msg )
    fp.close()

class loghandle:
    def __init__( self ):
        self.lines = []
    def append( self, msg ):
        self.lines.append( msg )

class test:
    @FileLogged( appname = 'Testapp', apptier = 'CMD' )
    def throwException( self, var1 , _loggingContext , **kw ):
        _loggingContext['user'] = 'bwicks'
        raise Exception()


if __name__ == '__main__':
    test().throwException( 3, name = 'xyz' )
