from sys import exc_info
from traceback import format_tb

from mako.lookup import TemplateLookup


class ErrorPageMiddleware(object):
    """
    Catch exceptions emitted by our wrapped application and show a pretty error
    page.

    You provide the Mako template and a folder that contains it and its
    dependent template files and ``ErrorPageMiddleware`` will render that
    template when the wrapped application throws an unhandled exception.

    ``ErrorPageMiddleware`` will provide the exception traceback to your template
    in the context variable ``traceback`` as an orderd list of strings: one line of
    the traceback per item.

    The reason we need both ``template_dir`` and ``template`` is that we need to be
    able to find anything that ``template`` might import.  Those things should be
    in ``template_dir``.

    Constructor arguments:

    :param template_dir: the folder that holds your Mako templates
    :type viewdir: string

    :param template: the name of the template that you want to use as
                        as your error page
    :type tempalte: string

    :param page_args: (optional) any context variables that are necessary for
                      rendering your template should be passed in this dictionary
    :type page_args: dictionary
    """

    def __init__(self, app, template_dir, template, page_args={}):
        """

        """
        self.app = app
        self.template_dir = template_dir
        self.template = template
        self.page_args = page_args

    def __call__(self, environ, start_response):
        appiter = None
        try:
            return self.app(environ, start_response)
        except:
            e_type, e_value, tb = exc_info()
            traceback = ['Traceback (most recent call last):']
            traceback += format_tb(tb)
            traceback.append('%s: %s' % (e_type.__name__, e_value))
            # we might have not a stated response by now. try
            # to start one with the status code 500 or ignore an
            # raised exception if the application already started one.
            self.page_args['traceback'] = traceback
            l = TemplateLookup(directories=[self.template_dir], disable_unicode=True)
            t = l.get_template(self.template)
            try:
                start_response('500 INTERNAL SERVER ERROR', [('Content-Type', 'text/html')])
            except:
                pass
            return t.render(**self.page_args)

        # wsgi applications might have a close function. If it exists
        # it *must* be called.
        if hasattr(appiter, 'close'):
            appiter.close()
