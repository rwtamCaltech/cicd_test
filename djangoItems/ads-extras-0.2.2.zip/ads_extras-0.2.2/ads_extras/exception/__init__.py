class ADSException(Exception):
    """
    Use this class as the base class of all custom-made exceptions,
    so that they act like normal exceptions, but gain additional functionality
    in the form of the optional keyword arguments.
    """
    def __init__(self, message, **kw):
        Exception.__init__(self, message)
        for key, val in kw.items():
            setattr(self, key, val)
