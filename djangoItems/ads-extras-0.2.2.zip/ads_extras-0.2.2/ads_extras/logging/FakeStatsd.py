class FakeStatsClient(object):

    class FakePipeline(object):
        
        def incr(self, metric):
            pass
        
        def timing(self, metric, milliseconds):
            pass
        
        def send(self):
            pass

    def __init__(self, *args, **kwargs):
        pass
        
    def pipeline(self):
        return FakeStatsClient.FakePipeline()

    def incr(self, *args):
        pass    

    def timing(self, *args):
        pass    
    