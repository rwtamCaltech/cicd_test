import os
import re
import sys
import datetime
import codecs
try:
    from ConfigParser import ConfigParser
except:
    from configparser import ConfigParser
from logging import StreamHandler
import logging.config
from logging.handlers import SysLogHandler

try:
    import syslog
except ImportError:
    # We must be on Windows, which has no syslog module
    from ads_extras.logging.WinSyslog import WinSyslog
    syslog = WinSyslog()

LOGGING_CONFIGURED = False


def Logged(x):
    def call(function):
        def decorate(*args, **kwargs):
            try:
                info_args = {'function': str(function.__name__),
                             'args': str(args),
                             'kwargs': str(kwargs)}
                get_default_logger().debug('invoking ' + str(info_args))
                obj = function(*args, **kwargs)
                return obj
            except:
                get_default_logger().exception('')
                raise
        decorate.__name__ = function.__name__
        decorate.__doc__ = function.__doc__
        decorate.__dict__.update(function.__dict__)
        return decorate
    return call(x)


class NamedLogged(object):

    def __init__(self, program_name='default'):
        self.__program = program_name

    def __call__(self, function):
        def decorate(*args, **kwargs):
            try:
                info_args = {'function': str(function.__name__),
                             'args': str(args),
                             'kwargs': str(kwargs)}
                get_default_logger(program=self.__program).debug('invoking ' + str(info_args))
                obj = function(*args, **kwargs)
                return obj
            except:
                get_default_logger(program=self.__program).exception('')
                raise
        decorate.__name__ = function.__name__
        decorate.__doc__ = function.__doc__
        decorate.__dict__.update(function.__dict__)
        return decorate


class BottleRouteLogged(object):
    """
    This class is identical to NamedLogged, but it ignores HTTPResponse exceptions,
    since those are thrown by bottle's implementation of HTTP redirects.
    """

    def __init__(self, program_name='default'):
        self.__program = program_name

    def __call__(self, function):
        def decorate(*args, **kwargs):
            try:
                info_args = {
                    'function': str(function.__name__),
                    'args': str(args),
                    'kwargs': str(kwargs)
                }
                get_default_logger(program=self.__program).debug('invoking ' + str(info_args))
                obj = function(*args, **kwargs)
                return obj
            except Exception as e:
                if e.__class__.__name__ != 'HTTPResponse':
                    get_default_logger(program=self.__program).exception('')
                    raise
        decorate.__name__ = function.__name__
        decorate.__doc__ = function.__doc__
        decorate.__dict__.update(function.__dict__)
        return decorate


def handleError(self, record):
    """
    On OSX (and apparently all BSD-based unix systems), there is a hard limit on the number of
    characters that that can be sent to the syslog on a single line.  If a message is sent that is
    too long, an "[Errno 40] message too long" exception will be thrown.

    This function deals with that by re-emitting the message after manually splitting it
    into chunks that are smaller than the hard character limit.
    """
    # If this isn't "[Errno 40] message too long", just pass it on to the error handler
    ei = sys.exc_info()
    if not hasattr(ei[1], 'errno') or ei[1].errno != 40:
        sys.stderr.write("An error has occured during logging, but this error has not been propagated to your app.  It is printed below for informational purposes only:\n")
        logging.Handler.handleError(self, record)

    # rrollins 2011/1/5: The below block is from the original SysLogHandler.emit function.
    # I don't know if it's actually necessary, so I left it in just in case.
    msg = self.format(record)
    msg = self.log_format_string % (self.encodePriority(self.facility, self.mapPriority(record.levelname)), msg)
    # Treat unicode messages as required by RFC 5424
    if type(msg) is unicode:
        msg = msg.encode('utf-8')
        msg = codecs.BOM_UTF8 + msg

    try:
        # Split the output into MAX_LEN-character log messages.
        MAX_LEN = 2048
        while msg:
            self.socket.send(msg[:MAX_LEN])
            msg = msg[MAX_LEN:]
    except (KeyboardInterrupt, SystemExit):
        raise
    except:
        sys.stderr.write("An error has occured during logging, but this error has not been propagated to your app.  It is printed below for informational purposes only:\n")
        logging.Handler.handleError(self, record)
        # Monkey-patch this function into SysLogHandler.  Normally I would have just subclassed SysLogHandler,
        # but I couldn't figure out how to set up a new class as the handler in the get_default_logging_config() function.
        SysLogHandler.handleError = handleError


def configure_python_logging(config, disable_existing_loggers=1):
    """
    This function duplicates what logging.config.fileConfig() does, but takes a
    ConfigParser-like object as it's source-data paramter, instead of a filename.
    """
    formatters = logging.config._create_formatters(config)

    # critical section
    logging._acquireLock()
    try:
        logging._handlers.clear()
        del logging._handlerList[:]
        # Handlers add themselves to logging._handlers
        handlers = logging.config._install_handlers(config, formatters)
        logging.config._install_loggers(config, handlers, disable_existing_loggers)
    finally:
        logging._releaseLock()


def get_default_logging_config(debug=True):
    """
    Builds the default, syslog-based logging config object for our apps, as shown below.
    By default, the logging level is set to DEBUG.  Passing debug=False to this function
    will set the logging level to INFO.

    [loggers]
    keys = root

    [handlers]
    keys = syslogHandler

    [formatters]
    keys = syslogFormatter

    [logger_root]
    level = DEBUG
    handlers = syslogHandler

    [handler_syslogHandler]
    class = handlers.SysLogHandler
    facility = LOG_LOCAL0
    level = DEBUG
    formatter = syslogFormatter
    args = ()

    [formatter_syslogFormatter]
    format = %(levelname)s : %(name)s : %(message)s
    """
    config = ConfigParser()

    config.add_section('loggers')
    config.set('loggers', 'keys', 'root')

    config.add_section('handlers')
    config.set('handlers', 'keys', 'syslogHandler')

    config.add_section('formatters')
    config.set('formatters', 'keys', 'syslogFormatter')

    config.add_section('logger_root')
    config.set('logger_root', 'level', debug and 'DEBUG' or 'INFO')
    config.set('logger_root', 'handlers', 'syslogHandler')

    config.add_section('handler_syslogHandler')
    config.set('handler_syslogHandler', 'class', 'handlers.SysLogHandler')
    config.set('handler_syslogHandler', 'level', debug and 'DEBUG' or 'INFO')
    config.set('handler_syslogHandler', 'formatter', 'syslogFormatter')
    if sys.platform == 'darwin':
        config.set('handler_syslogHandler', 'args', "('/var/run/syslog',)")
    elif sys.platform.startswith('linux'):
        config.set('handler_syslogHandler', 'args', "('/dev/log',)")
    else:  # We don't know what paltform we're on, so use the default, which is to communicate with the localhost syslog over TCP
        config.set('handler_syslogHandler', 'args', "()")

    config.add_section('formatter_syslogFormatter')
    config.set('formatter_syslogFormatter', 'format', '%(name)s: [%(levelname)s]  %(message)s')

    return config

get_syslog_logging_config = get_default_logging_config


def get_stdout_logging_config(program="default", debug=True):
    """
    Builds the a stdout-based logging config object for our apps, as shown below.
    By default, the logging level is set to DEBUG.  Passing debug=False to this function
    will set the logging level to INFO.
    """
    config = ConfigParser()

    config.add_section('loggers')
    config.set('loggers', 'keys', 'root')

    config.add_section('handlers')
    config.set('handlers', 'keys', 'syslogHandler')

    config.add_section('formatters')
    config.set('formatters', 'keys', 'syslogFormatter')

    config.add_section('logger_root')
    config.set('logger_root', 'level', debug and 'DEBUG' or 'INFO')
    config.set('logger_root', 'handlers', 'syslogHandler')

    config.add_section('handler_syslogHandler')
    config.set('handler_syslogHandler', 'class', 'handlers.SysLogHandler')
    config.set('handler_syslogHandler', 'level', debug and 'DEBUG' or 'INFO')
    config.set('handler_syslogHandler', 'formatter', 'syslogFormatter')
    if sys.platform == 'darwin':
        config.set('handler_syslogHandler', 'args', "('/var/run/syslog',)")
    elif sys.platform.startswith('linux'):
        config.set('handler_syslogHandler', 'args', "('/dev/log',)")
    else:  # We don't know what paltform we're on, so use the default, which is to communicate with the localhost syslog over TCP
        config.set('handler_syslogHandler', 'args', "()")

    config.add_section('formatter_syslogFormatter')
    config.set('formatter_syslogFormatter', 'format', '%(name)s: [%(levelname)s]  %(message)s')

    return config


class LoggerMixin(object):

    """

    ``LoggerMixin`` adds helper methods to any class that will do proper logging
    without you having to configure python logging.  If you want different
    information in your log messages, subclass this and override the ``_log()``
    method to add to the `msg` parameter and then do ``super(YourClass,
    self)._log(level, msg)``.

    ``LoggerMixin`` can
be configured to log to stderr to the local syslog
    device, or to a remote syslog host.  You can configure it either via
    constructor arguments or environment variables.  The default is to log to
    syslog if a log device is found, stderr otherwise.

    .. note::

        Environment variables take precedence over constructor arguments if both
        are used.  This is so that you can have a default log mode but override it
        in your development environment.

    To configure ``LoggerMixin`` to log to stderr::

        LoggerMixin()

    or
        LoggerMixin(mode='print')

    or, set the environment variable ``LOGGING_MODE`` to 'print' and do:

        LoggerMixin()


    To configure ``LoggerMixin`` to log to the local log device::

        LoggerMixin(mode='syslog')

    or, set the environment variable ``LOGGING_MODE`` to 'syslog' and do:

        LoggerMixin()

    To configure ``LoggerMixin`` to log to a remote syslog host::

        LoggerMixin(mode='syslog', loghost='1.2.3.4')

    or, set the environment variable ``LOGGING_MODE`` to 'syslog' and the
    environment variable ``LOGGING_LOGHOST`` to '1.2.3.4' and do:

        LoggerMixin()


    The default log level for the logger created is ``logging.DEBUG``.  If
    you want to raise the level (to exclude debug logging, for example), you can
    either specify the level you want in the constructor:

        LoggerMixin(log_level='INFO')

    or, set the environment variable ``LOGGING_LEVEL`` to the level you want and do:

        LoggerMixin()

    **Newlines in log messages**

    By default, if a log message has newlines in it (e.g. a stack trace), those
    newlines will written as ``\n`` verbatim in the message.  Sometimes this can
    be painful to disentangle in the logging subsystem, for example when we're
    in a Docker container.

    If you set the environment variable ``LOGGING_CONVERT_NEWLINES`` to "True",
    ``LoggerMixin`` will convert all ``\n`` characters in msg to "|||".
    Alternatively you can pass in the ``convert_newlines`` kwarg:

        LoggerMixin(convert_newlines=True)

    **Labelling lines for logstash**

    When outputting log messages from a Docker container, all logs from all processes
    get mingled in stdout.  It's useful if we can easily distinguish them later so we
    can filter or route them appropriate.

    For mode 'print' only, if you set the environment variable
    ``LOGGING_PREFIX`` to a string, all messages will be prefixed by that
    string.

    Alternatively you can pass in the ``convert_newlines`` kwarg:

        LoggerMixin(prefix="LABEL")

    """

    MODES = [
        'print',
        'syslog',
    ]

    def __init__(self, program="default", mode=None, log_level='DEBUG', convert_newlines=False, prefix=None, **kwargs):
        """
        :param program: set the program name in our log messages to this.  Default: 'default'
        :type program: string

        :param mode: one of 'syslog', 'print'
        :type mode: string

        :param log_level: (optional) filter reported logs to this level and above. Default: DEBUG
        :type loghost: string

        :param kwargs: dictionary of keyword arguments that might be used in setting up the logging mode
        :type mode: dict
        """
        self.program = program
        self.convert_newlines = convert_newlines
        if "LOGGING_CONVERT_NEWLINES" in os.environ:
            val = os.environ['LOGGING_CONVERT_NEWLINES'].lower()
            if val == 'true':
                self.convert_newlines = True
            elif val == 'false':
                self.convert_newlines = False
        self.prefix = prefix
        if "LOGGING_PREFIX" in os.environ:
            self.prefix = os.environ['LOGGING_PREFIX']
        self._setup(mode, log_level=log_level, **kwargs)

    @classmethod
    def is_setup(cls):
        """
        Return ``True`` if we've already configured logging, ``False`` otherwise.

        :rtype: boolean
        """
        return(LOGGING_CONFIGURED)

    @classmethod
    def reconfigure(cls):
        """
        Clear out all handlers from the root logger and allow ``_setup()`` to run again. This is
        useful for unit testing, for the most part.
        """
        global LOGGING_CONFIGURED
        LOGGING_CONFIGURED = False
        l = logging.getLogger()
        l.handlers = []

    def _get_log_device(self):
        """
        Detect our log device by platform.
        """
        if sys.platform == 'darwin':
            return '/var/run/syslog'
        elif sys.platform.startswith('linux'):
            return '/dev/log'
        else:
            return None

    def _setup(self, mode=None, log_level='DEBUG', **kwargs):
        """
        Add our handlers to the root logger.  Ensure that this runs only once so
        that we don't end up with a new handler set for each class that
        subclasses this one.

        :param mode: one of 'syslog', 'print'
        :type mode: string

        :param log_level: (optional) filter reported logs to this level and above. Default: DEBUG
        :type loghost: string

        :param kwargs: dictionary of keyword arguments that might be used in setting up the logging mode
        :type mode: dict
        """
        global LOGGING_CONFIGURED
        # This use of the LOGGING_CONFIGURED global variable to determine whether we've
        # setup our logging handlers seems like it should be problematic.  If many classes
        # subclass LoggerMixin, only the first to be instantiated will get to set up the
        # handlers.  What if different classes asked for different handlers?

        # Basically, subclassess should not try to change handlers.  That should
        # be configured once at the global level.  The root logger's handlers are used by
        # all child loggers. If we allowed resetting of the handlers for every
        # subclass of LoggerMixin, we'd get unpredictable behavior globally --
        # the application as a whole would log via whatever handlers the last class to be
        # instantiated used.

        if (not LoggerMixin.is_setup()):
            level = log_level
            if "LOGGING_LEVEL" in os.environ and os.environ['LOGGING_LEVEL']:
                level = os.environ.get('LOGGING_LEVEL', 'DEBUG')
                if level not in ['CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG']:
                    sys.stderr.write("{0} [WARNING] {1}: event='logging.config.invalid_level' msg='{2} is not a valid log level'\n".format(datetime.datetime.now().strftime('%c'), self.program, level))
                    level = 'DEBUG'
            if "LOGGING_MODE" in os.environ and os.environ['LOGGING_MODE']:
                mode = os.environ['LOGGING_MODE']
            if not mode:
                log_device = self._get_log_device()
                if os.path.exists(log_device):
                    mode = 'syslog'
                else:
                    sys.stderr.write("{0} [WARNING] {1}: event='logging.config.no_log_device' msg='{2} does not exist'\n".format(datetime.datetime.now().strftime('%c'), self.program, log_device))
                    mode = 'print'
                sys.stderr.write("{0} [WARNING] {1}: event='logging.config.no_mode_specified' msg='setting log mode to \"{2}\"'\n".format(datetime.datetime.now().strftime('%c'), self.program, mode))
            if mode not in LoggerMixin.MODES:
                sys.stderr.write("{0} [WARNING] {1}: event='logging.config.invalid_mode' value='{2}' msg='should be one of [syslog, print]; using \"print\"'\n".format(datetime.datetime.now().strftime('%c'), self.program, mode))
                mode = 'print'
            self._setup_logging(mode, log_level=level, **kwargs)
            LOGGING_CONFIGURED = True

    def _setup_logging(self, mode, **kwargs):
        if mode == "syslog":
            self._setup_syslog_config(**kwargs)
        elif mode == "print":
            self._setup_stderr_config(**kwargs)
        else:
            self._setup_stderr_config(**kwargs)

    def _setup_syslog_config(self, loghost=None, log_level='DEBUG'):
        """
        Add a properly configured SysLogHandler to our root logger. Send logs to the
        LOCAL0 facility.

        If ``loghost`` is not ``None`` or the environment variable ``LOGGING_LOGHOST``
        is set and is not empty, send our logs to UDP port 514 on the host so
        named.

        If ``loghost`` is ``None`` and the environment variable ``LOGGING_LOGHOST`` is
        either not set or empty, write logs to the local log device and have
        ``syslogd`` handle our logs for us.  Choose the appropriate log device to
        write to based on our ``os.platform``.

        :param loghost: (optional) the hostname or IP address of a remote syslog host
        :type loghost: string

        :param log_level: (optional) filter reported logs to this level and above. Default: DEBUG
        :type loghost: string
        """
        logger = logging.getLogger()
        level = getattr(logging, log_level)
        logger.setLevel(level)

        # If there's already a SysLogHandler-based logging handler on the root logger, adding ours would be redundant.
        for handler in logger.handlers:
            if issubclass(handler.__class__, SysLogHandler):
                return

        if "LOGGING_LOGHOST" in os.environ and os.environ['LOGGING_LOGHOST']:
            loghost = os.environ['LOGGING_LOGHOST']
        if loghost:
            sh = SysLogHandler(address=(loghost, logging.handlers.SYSLOG_UDP_PORT), facility="local0")
        else:
            log_device = self._get_log_device()
            if log_device:
                sh = SysLogHandler(address=log_device, facility="local0")
            else:
                # We don't know what paltform we're on, so use the default: communicate with localhost syslog over TCP.
                sh = SysLogHandler(address=(), facility="local0")
        formatter = logging.Formatter('%(name)s: %(message)s')
        sh.setFormatter(formatter)
        logger.addHandler(sh)

    def _setup_stderr_config(self, log_level='DEBUG'):
        """
        Add a properly configured StreanHandler to our root logger that will send logs to
        stderr.

        :param log_level: (optional) filter reported logs to this level and above. Default: DEBUG
        :type loghost: string
        """
        logger = logging.getLogger()
        level = getattr(logging, log_level)
        logger.setLevel(level)

        # If there's already a StreamHandler-based logging handler for
        # sys.stderr on the root logger, adding ours would be redundant.
        for handler in logger.handlers:
            if issubclass(handler.__class__, StreamHandler):
                if handler.stream == sys.stderr:
                    return

        sh = StreamHandler(sys.stderr)
        fmt = '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        if self.prefix:
            fmt = "{0} {1}".format(self.prefix, fmt)
        formatter = logging.Formatter(fmt)
        sh.setFormatter(formatter)
        logger.addHandler(sh)

    def _log(self, level, msg):
        """
        Log a ``msg`` with severity ``level``, where level is one of 'debug', 'info', 'warning',
        'error', 'critical', 'exception'.

        :param level: message severity
        :type level: string

        :param msg: the text to log
        :type msg: string
        """
        logger = logging.getLogger(self.program)
        log_fn = getattr(logger, level)
        if self.convert_newlines:
            msg = re.sub('\n', '|||', msg)
        if self.prefix:
            msg = "{0} {1}".format(self.prefix, msg)
        log_fn(msg)

    def log_debug(self, msg):
        self._log('debug', msg)

    def log_info(self, msg):
        self._log('info', msg)

    def log_warning(self, msg):
        self._log('warning', msg)

    def log_error(self, msg):
        self._log('error',  msg)

    def log_critical(self, msg):
        self._log('critical', msg)

    def log_exception(self, msg):
        self._log('exception', msg)


class EventLoggerMixin(LoggerMixin):

    """
    A wrapper for ``LoggerMixin`` that changes the format of the log messages to be vaguely like
    structlog (https://structlog.readthedocs.org/en/stable/).
    """

    def __init__(self, *args, **kwargs):
        super(EventLoggerMixin, self).__init__(*args, **kwargs)

    def _log(self, level, event, msg=None):
        """
        Log a message with severity ``level``, where level is one of 'debug', 'info', 'warning',
        'error', 'critical', 'exception'.

        Log message will start with "event='${event}'" and have ``msg`` appended to it.  Example::

            event="foobar.baz" here is a nice message

        :param level: message severity
        :type level: string

        :param event: event name
        :type event: string

        :param msg: (optional) additional text to log
        :type msg: string
        """
        logmsg = "event='{event}'".format(event=event)
        if msg:
            logmsg += ' {msg}'.format(msg=msg)
        super(EventLoggerMixin, self)._log(level, logmsg)

    def log_debug(self, event, msg=None):
        self._log('debug', event, msg)

    def log_info(self, event, msg=None):
        self._log('info', event, msg)

    def log_warning(self, event, msg=None):
        self._log('warning', event, msg)

    def log_error(self, event, msg=None):
        self._log('error', event, msg)

    def log_critical(self, event, msg=None):
        self._log('critical', event, msg)

    def log_exception(self, event, msg=None):
        self._log('exception', event, msg)


class get_default_logger(LoggerMixin):

    def __init__(self, program='default', verbose=False, log_level='DEBUG'):
        super(get_default_logger, self).__init__(program=program, mode="syslog", log_level=log_level)
        if verbose:
            self._setup_stderr_config()

    def info(self, msg):
        self.log_info(msg)

    def debug(self, msg):
        self.log_debug(msg)

    def warning(self, msg):
        self.log_warning(msg)

    def fatal(self, msg):
        self.log_critical(msg)

    def exception(self, message):
        self.log_exception(message)
