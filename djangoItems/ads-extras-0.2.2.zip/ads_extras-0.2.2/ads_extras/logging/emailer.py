'''
Created on Feb 10, 2012

@author: rrollins
'''
import socket
import smtplib
import logging
from datetime import datetime
from email.MIMEText import MIMEText #@UnresolvedImport
from email.MIMEMultipart import MIMEMultipart #@UnresolvedImport

def send_email(subject, email_body, recipient, sender="emailer@caltech.edu", reply_to="imss-ads-staff@caltech.edu", smtp_server="smtp-server.its.caltech.edu"):
    message = MIMEMultipart()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = recipient
    message["Reply-To"] = reply_to
    
    timestamp = "Timestamp: {0}".format(datetime.now().strftime("%c"))
    host      = "Host: {0}".format(socket.gethostname())
    sep       = "\n================================================================"
    message.attach(MIMEText("\n".join([timestamp, host, sep, email_body])))
    
    try:
        server = smtplib.SMTP(smtp_server)
        server.set_debuglevel(0)
        server.sendmail(sender, recipient, message.as_string())
        server.quit()
    except Exception, e:
        logging.getLogger("emailer").error('Failed to send email with subject "{0}" to "{1}" because: {2} {3}'.format(subject, recipient, e.__class__, e))
