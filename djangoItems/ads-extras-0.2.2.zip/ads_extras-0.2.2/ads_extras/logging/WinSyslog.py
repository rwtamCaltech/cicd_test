#!/usr/bin/env python
import os
import socket
import datetime

class WinSyslog(object):

    LOG_EMERG        = 0        #  system is unusable 
    LOG_ALERT        = 1        #  action must be taken immediately 
    LOG_CRIT         = 2        #  critical conditions 
    LOG_ERR          = 3        #  error conditions 
    LOG_WARNING      = 4        #  warning conditions 
    LOG_NOTICE       = 5        #  normal but significant condition 
    LOG_INFO         = 6        #  informational 
    LOG_DEBUG        = 7        #  debug-level messages 
    
    #  facility codes 
    LOG_KERN        = 0        #  kernel messages 
    LOG_USER        = 1        #  random user-level messages 
    LOG_MAIL        = 2        #  mail system 
    LOG_DAEMON      = 3        #  system daemons 
    LOG_AUTH        = 4        #  security/authorization messages 
    LOG_SYSLOG      = 5        #  messages generated internally by syslogd 
    LOG_LPR         = 6        #  line printer subsystem 
    LOG_NEWS        = 7        #  network news subsystem 
    LOG_UUCP        = 8        #  UUCP subsystem 
    LOG_CRON        = 9        #  clock daemon 
    LOG_AUTHPRIV    = 10    #  security/authorization messages (private) 
    
    #  other codes through 15 reserved for system use 
    LOG_LOCAL0        = 16        #  reserved for local use 
    LOG_LOCAL1        = 17        #  reserved for local use 
    LOG_LOCAL2        = 18        #  reserved for local use 
    LOG_LOCAL3        = 19        #  reserved for local use 
    LOG_LOCAL4        = 20        #  reserved for local use 
    LOG_LOCAL5        = 21        #  reserved for local use 
    LOG_LOCAL6        = 22        #  reserved for local use 
    LOG_LOCAL7        = 23        #  reserved for local use 
    
    LOG_PID           = 0x01
    LOG_CONS          = 0x02
    LOG_ODELAY        = 0x04
    LOG_NDELAY        = 0x08
    LOG_NOWAIT        = 0x10
    LOG_PERROR        = 0x20


    def __init__(self, filename=None):
        self.logfile = filename or os.path.join(os.sep, "tmp", "messages")
        self.program = 'default'
        self.hostname = socket.gethostname().split('.')[0]

    def syslog(self, priority, message=None):
        if not message:
            message = priority
        fd = open(self.logfile, 'a+')
        timestamp = datetime.datetime.now()
        fd.write("%s %s %s: %s\n" % (timestamp.strftime("%b %d %H:%M:%S"), self.hostname, self.program, message))
        fd.close()
    
    def openlog(self, ident, logopt=None, facility=None):
        self.program = ident
    
    def closelog(self):
        self.program = 'default'
    
    def setlogmask(self, maskpri):
        pass