"""
Dummy is a stub object that is used in unit tests. Use it to replace complicated
objects where you want full control over return values with minimal side effects.
Dummy objects can now act like methods or dicts or lists now, since __call__,
__setitem__, and __getitem__ are now overridden and tracked.

By default, any attempt to access a method or member will return 'None' and the
usage will be added to the calls or attributes list.

It is possible to provide a list of strings and lists that will by default return
"" and [] respectively. This is needed for those times that iterators or regular
expressions will be applied to the Dummy's return values.

It is also possible to provide a list of members that should *not* exist in the
Dummy, and an AttributeError will be raised.

Any additional kwargs that are supplied will result in the Dummy returning those
values when the named attribute is accessed.

Usage examples:
    When testing method Foo(an_obj), Foo expects to access an_obj.bar.
        dummy = Dummy(bar="Some Value")
        Foo(dummy)
        ... perform asserts ...

    When testing method Foo(an_obj), Foo expects to access an_obj.bar, and an
    underlying method accesses an_obj.some_list. Foo doesn't care about
    an_obj.some_list.
        dummy = Dummy(bar="Some Value", lists=['some_list'])
        Foo(dummy)
        ... perform asserts ...

    When testing method Foo(an_obj), Foo expects to access an_obj.bar. An
    underlying method accesses an_obj.some_string. Foo doesn't care about the
    string.
        dummy = Dummy(bar="Some Value", strings=['some_string'])
        Foo(dummy)
        ... perform asserts ...

    When testing method Foo(an_obj), Foo expects to access an_obj.bar and an_obj.baz.
    It expects an_obj.baz to be non-existent.

        dummy = Dummy(bar="Some Value", bad_fields=['baz'])
        Foo(dummy)
        ... perform asserts ...

    When testing method Foo(an_obj), Foo expects to access an_obj.bar. Underlying
    methods access a number of members and methods, and expect returns other than
    'None'. Why not return 'True' by default instead?
        dummy = Dummy(bar="Some Value", default_return=True)
        Foo(dummy)
        ... perform asserts ...

    When testing method Foo(a_callback), Foo expects to invoke the passed callback.
    Invocation of the "callback" will add an entry to Dummy.calls.
        dummy = Dummy(default_return=True)
        Foo(dummy)
        ... perform asserts ...

    When testing method Foo(a_list) or Foo(a_dict), Foo expects to access & modify
    the passed list or dict. Accessing or setting values will add entries to
    Dummy.attributes. Passing bad_fields=[...] will allow the dummy to throw
    KeyError and IndexError as appropriate.
        dummy = Dummy(default_return=True, bad_fields=['foo', 'bar'])
        Foo(dummy)
        ... perform asserts ...

Created on Mar 29, 2013

@author smeinel
"""

builtins = [
    'attributes',
    'calls',
    'default_return',
    'default_string',
    'default_list',
    'lists',
    'strings',
    'bad_fields',
    'debug_flag',
]


class Dummy(object):

    def __init__(self, default_return=None, default_string="", default_list=[], lists=[], strings=[], bad_fields=[], special_attributes={}, debug_flag=False, **kwargs):
        self.default_return = default_return
        self.default_string = default_string
        self.default_list = default_list
        self.calls = []
        self.attributes = []
        self.lists = lists
        self.strings = strings
        self.bad_fields = bad_fields
        self.debug_flag = debug_flag

        for attr_name, attr_value in special_attributes.items():
            self.__dict__[attr_name] = attr_value

        for attr_name, attr_value in kwargs.items():
            self.__dict__[attr_name] = attr_value

    #   Object emulation
    def __getattr__(self, attr, *args, **kwargs):
        if self.debug_flag:
            print(attr)
        if args or len(kwargs):
            self.calls.append({'function': attr, 'args': args, 'kwargs': kwargs})
        else:
            self.attributes.append(attr)

        if attr in self.lists:
            return self.default_list
        elif attr in self.strings:
            return self.default_string
        elif attr in self.bad_fields:
            raise AttributeError("{0} not in Dummy!".format(attr))

        return self.default_return

    def __setattr__(self, attr, value):
        if attr in builtins:
            self.__dict__[attr] = value
        else:
            if "debug_flag" in self.__dict__ and self.__dict__["debug_flag"]:
                print(attr)
            if "attributes" in self.__dict__:
                self.attributes.append((attr, value))
            if "bad_fields" in self.__dict__ and attr in self.bad_fields:
                raise AttributeError("{0} not in Dummy!".format(attr))
            if attr in self.__dict__:
                self.__dict__[attr] = value

    #   Dict/List Emulation
    def __getitem__(self, key):
        if "debug_flag" in self.__dict__ and self.__dict__["debug_flag"]:
            print(key)
        if "attributes" in self.__dict__:
            self.attributes.append(key)
        if "bad_fields" in self.__dict__ and key in self.bad_fields:
            if isinstance(key, int):
                raise IndexError("{0} not in Dummy!".format(key))
            else:
                raise KeyError("{0} not in Dummy!".format(key))
        if key in self.__dict__:
            return self.__dict__[key]
        elif key in self.__dict__['lists']:
            return self.__dict__['default_list']
        elif key in self.__dict__['strings']:
            return self.__dict__['default_string']
        else:
            return self.__dict__['default_return']

    def __setitem__(self, key, value):
        if "debug_flag" in self.__dict__ and self.__dict__["debug_flag"]:
            print(key)
        if "attributes" in self.__dict__:
            self.attributes.append((key, value))
        if "bad_fields" in self.__dict__ and key in self.bad_fields:
            if isinstance(key, int):
                raise IndexError("{0} not in Dummy!".format(key))
            else:
                raise KeyError("{0} not in Dummy!".format(key))
        self.__dict__[key] = value

    def __delitem__(self, key):
        if "debug_flag" in self.__dict__ and self.__dict__["debug_flag"]:
            print(key)
        if "attributes" in self.__dict__:
            self.attributes.append(key)
        if "bad_fields" in self.__dict__ and key in self.bad_fields:
            if isinstance(key, int):
                raise IndexError("{0} not in Dummy!".format(key))
            else:
                raise KeyError("{0} not in Dummy!".format(key))
        if key in self.lists:
            self.lists.remove(key)
        elif key in self.strings:
            self.strings.remove(key)
        elif key in self.__dict__:
            del self.__dict__[key]

    def __iter__(self):
        for x in self.lists:
            yield self.default_list
        for x in self.strings:
            yield self.default_string
        for x in [y for y in self.__dict__ if y not in builtins]:
            if x in self.__dict__:
                yield self.__dict__[x]
            else:
                yield self.default_return

    def __contains__(self, item):
        for x in self.lists:
            if x == item:
                return True
        for x in self.strings:
            if x == item:
                return True
        for x in [y for y in self.__dict__ if y not in builtins]:
            if x == item:
                return True
        return False

    def get(self, key, default=None):
        try:
            return self.__getitem__(key)
        except:
            return default

    #   Method emulation
    def __call__(self, *args, **kwargs):
        self.calls.append({'function': 'Dummy', 'args': args, 'kwargs': kwargs})
        return self.default_return

    #   Resets the Dummy object to its pristine, post-init state.
    def reset_dummy(self):
        self.calls = []
        self.attributes = []

        for value in self.__dict__.values():
            if isinstance(value, Dummy):
                value.reset_dummy()
