#!/usr/bin/env python
from ads_extras import __version__
from setuptools import setup, find_packages

setup(name="ads_extras",
      version=__version__,
      description="Various general modules for use in ADS projects",
      author="IMSS ADS",
      author_email="imss-ads-staff@caltech.edu",
      packages=find_packages(exclude=["src", "*.test", "*.test.*"])
      )
