from django.contrib.auth.backends import RemoteUserBackend

from .logging_handlers import djunk_logger


class AccessCaltechAutoUserBackend(RemoteUserBackend):
    """
    This is the same as ``RemoteUserBackend`` except that we populate the user record with more data.

    We do our own subclass because we know how to get the real email address and full name from the appropriate
    access.caltech headers and can thus more fully populate our user records.
    """
    # Subclasses can override this to use an app-specific logger.
    logger = djunk_logger

    def authenticate(self, request, remote_user):
        """
        Override ``RemoteUserBackend.authenticate()`` so that we can update the user's biographical
        info from what CIT_AUTH provided.
        """
        user = super().authenticate(request, remote_user)
        if user:
            # Only update the bio data if it actually changed
            email, fullname, first_name, last_name = self.__get_access_caltech_bio(request)
            if (
                user.email != email or
                user.fullname != fullname or
                user.first_name != first_name or
                user.last_name != last_name
            ):
                user.email = email
                user.fullname = fullname
                user.first_name = first_name
                user.last_name = last_name
                user.save()
                self.logger.info(
                    'auth.user.updated',
                    username=user.username,
                    email=user.email,
                    fullname=user.fullname,
                    first_name=user.first_name,
                    last_name=user.last_name
                )
        return user

    # As of Django 2.2, this method can be called as either configure_user(request, user) or just configure_user(user).
    # The caller will test for which version we provide. Django 3.1 drops support for configure_user(user).
    # noinspection PyMethodOverriding
    def configure_user(self, request, user):
        """
        Add our usual access.caltech data to the user object.
        """
        email, fullname, first_name, last_name = self.__get_access_caltech_bio(request)
        user.email = email
        user.fullname = fullname
        user.first_name = first_name
        user.last_name = last_name
        user.save()
        self.logger.info(
            'auth.user.created',
            username=user.username,
            email=user.email,
            fullname=user.fullname,
            first_name=user.first_name,
            last_name=user.last_name
        )
        return user

    def __get_access_caltech_bio(self, request):
        """
        Extract bio data from the CIT_AUTH headers.
        Set them to something reasonable if those headers don't exist, such as when we're in dev.
        """
        email = request.META.get('HTTP_USER_MAIL', 'UNKNOWN@caltech.edu')
        fullname = request.META.get('HTTP_USER_CN', 'UNKNOWN')
        first_name = request.META.get('HTTP_USER_FIRST_NAME', 'UNKNOWN')
        last_name = request.META.get('HTTP_USER_LAST_NAME', 'UNKNOWN')
        return email, fullname, first_name, last_name
