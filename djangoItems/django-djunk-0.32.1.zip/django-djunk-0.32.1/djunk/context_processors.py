from django.conf import settings


def add_DEBUG_to_templates(context):
    return {
        'DEBUG': settings.DEBUG
    }
