from django.db.models import ManyToManyField, QuerySet


def model_to_dict(instance, exclude_passwords=False):
    """
    Convert the given model instance to a dictionary keyed by field name.
    Pass in exclude_passwords = True to skip any field named "password". This is primarily useful to prevent
    hashed passwords from being logged when a User object is created or changed.
    """
    data = {}
    for f in instance._meta.get_fields():
        if not isinstance(f, ManyToManyField) and (exclude_passwords and f.name != 'password'):
            if hasattr(f, 'value_from_object'):
                try:
                    data[f.name] = f.value_from_object(instance)
                except:
                    # If anything goes wrong at this step, just ignore this field.
                    pass
                else:
                    if isinstance(data[f.name], QuerySet):
                        # Convert QuerySets to concrete lists, so they're printable and comparable (for logging).
                        data[f.name] = list(data[f.name].all())
            else:
                field_data = getattr(instance, f.name, None)
                try:
                    # If this field is a manager, grab all the managed objects.
                    field_data = list(field_data.all())
                except AttributeError:
                    pass
                data[f.name] = field_data
    return data


def log_compat(obj):
    """
    Convert the given object to a string that's compatible with the logger output.
    """
    # If obj isn't already a string, convert it to one. We skip strings because we want "string", and not "u'string'".
    if not isinstance(obj, str):
        obj = repr(obj)
    return obj


def log_model_changes(logger, original, new):
    """
    Logs the changes made from the original instance to new instance to the specified logger.
    """
    original_dict = model_to_dict(original, exclude_passwords=True)
    new_dict = model_to_dict(new, exclude_passwords=True)

    changes = {}
    for field_name, original_value in original_dict.items():
        new_value = new_dict.get(field_name)
        try:
            if original_value != new_value:
                changes[field_name] = '"{}" -> "{}"'.format(original_value, new_value)
        except TypeError:
            # Some fields (e.g. dates) can potentially trigger this kind of error when being compared. If that happens,
            # there's not much we can do about it, so we just skip that field.
            pass
    if changes:
        if original._meta.label.endswith(('CAPUser', '.User')):
            if 'last_login' in changes and len(changes) == 1:
                # Don't log changes that are only to the "last_login" field on a User model.
                # That field gets changed every time the user logs in, and we already log logins.
                return
            if 'password' in changes:
                # Don't log the new password hash
                changes['password'] = "__NEW_PASSWORD__"
        # Don't let the "model" keyword that we set manually on info() conflict with the "changes" dict, which can
        # happen when renaming a model in a migration.
        if 'model' in changes:
            changes['other_model'] = changes.pop('model')
        logger.info('model.update', model=original._meta.label, pk=original.pk, **changes)


def log_model_m2m_changes(logger, instance, action, model, pk_set):
    """
    Logs the changes made to an object's many-to-many fields to the specified logger.
    """
    # The post_add and post_remove signals get sent even if no changes are actually made by their respective actions
    # (e.g. when add()'ing an object that's already in the m2m relationship).
    # Since there are no changes, there's nothing to log.
    if not pk_set:
        return

    if action == "post_remove":
        removed_objects = model.objects.filter(pk__in=pk_set)
        logger.info(
            'model.m2m.delete',
            model=instance._meta.label,
            objects=", ".join(log_compat(obj) for obj in removed_objects),
            instance=log_compat(instance)
        )
    elif action == "post_add":
        added_objects = model.objects.filter(pk__in=pk_set)
        logger.info(
            'model.m2m.add',
            model=instance._meta.label,
            objects=", ".join(log_compat(obj) for obj in added_objects),
            instance=log_compat(instance)
        )


def log_new_model(logger, instance):
    """
    Logs the field values set on a newly-saved model instance to the specified logger.
    """
    kwargs = model_to_dict(instance, exclude_passwords=True)
    if 'model' not in kwargs:
        kwargs['model'] = instance._meta.label
    if 'event' in kwargs:
        # The first argument to logger.info() here is technically a kwarg called
        # 'event', so if kwargs also has a key in it called 'event', our
        # logger.info() call will raise an exception about duplicate keyword args
        kwargs['event_obj'] = kwargs['event']
        del kwargs['event']
    logger.info('model.create', instance=log_compat(instance), **kwargs)


def log_model_deletion(logger, instance):
    """
    Logs the deletion of this model instance to the specified logger.
    """
    kwargs = model_to_dict(instance, exclude_passwords=True)
    if 'event' in kwargs:
        # The first argument to logger.info() here is technically a kwarg called
        # 'event', so if kwargs also has a key in it called 'event', our
        # logger.info() call will raise an exception about duplicate keyword args
        kwargs['event_obj'] = kwargs['event']
        del kwargs['event']
    if 'model' in kwargs:
        # Some models have a "model" keyword, which needs to be removed for the same reason as 'event'.
        kwargs['model_obj'] = kwargs['model']
        del kwargs['model']
    logger.info('model.delete', model=instance._meta.label, instance=log_compat(instance), **kwargs)
