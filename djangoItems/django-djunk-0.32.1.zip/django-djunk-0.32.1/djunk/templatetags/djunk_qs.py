from django import template
from django.utils.encoding import iri_to_uri

from djunk.utils import reverse_with_qs

register = template.Library()


@register.simple_tag()
def url_qs(name, **kwargs):
    return iri_to_uri(reverse_with_qs(name, **kwargs))
