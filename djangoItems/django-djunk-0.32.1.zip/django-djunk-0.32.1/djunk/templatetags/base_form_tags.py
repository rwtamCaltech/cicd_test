from django import template

register = template.Library()


@register.simple_tag()
def field_classes(field):
    """
    Sets up the base field classes, error/required, and other useful classes (like input type).
    """
    classes = ['field', field.html_name, field.field.widget.__class__.__name__]
    if field.errors:
        classes.append('error')
    if field.field.required:
        classes.append('required')

    return ' '.join(classes)
