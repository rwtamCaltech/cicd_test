from django import template

from djunk.middleware import get_current_request as middleware_get_current_request

register = template.Library()


@register.simple_tag()
def get_current_request():
    """
    Use this tag with the "{% get_current_request as var_name %}" syntax to add the current request object to the
    template context.
    """
    return middleware_get_current_request()
