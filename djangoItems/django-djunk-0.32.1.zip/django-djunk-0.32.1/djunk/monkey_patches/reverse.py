"""
Import this file in your wsgi.py before importing any other django modules::

    import djunk.monkey_patches.reverse

Then define `PATCHED_QUERY_STRING_URL_NAMESPACES` in your settings.py, and list any URL namespaces you have
patched to accept query strings parameters as view arguments instead of restful path parts.
"""

from urllib.parse import urlencode

from django.conf import settings
import django.urls
import django.urls.base
import django.urls.exceptions

orig_reverse = django.urls.base.reverse

def patched_reverse(viewname, urlconf=None, args=None, kwargs=None, current_app=None):  # noqa: E302
    """
    Our query param based URLs have no parameters in the URL itself -- instead we extract them out of the query string.
    But, we still want to accept args and kwargs for those URLs so we can render them as::

        /the/url/?param1=value1&param2=value2

    Real django reverse() only knows restful, parameterized URLs, which register their parameters with the url resolver.
    Thus when trying to `reverse()` our URLs,  we'll get NoReverseMatch if someone passed args or kwargs.  Thus, here,
    we catch NoReverseMatch, try retreiving the bare url (no args or kwargs), and then use any args and kwargs to build
    the query string, instead.

    We'll try to do that for any url that starts with a prefix in settings.PATCHED_QUERY_STRING_URL_NAMESPACES.

    The default for settings.PATCHED_QUERY_STRING_URL_NAMESPACES is ['admin'], so if all you want is a query string
    enabled version of django.contrib.admin, you don't need to define anything in your settings.

    .. note::

        We only have to do this for code that is not ours, and we're doing this so that we don't have to patch or
        subclass a bunch of 3rd party code, especially view code (which may call reverse) and templates (which may
        use the {% url %} template tag, which calls `reverse()`.

        You do still need to patch the `urlpatterns` for the 3rd party code, and wrap the view calls such that query
        parameters get unpacked into view args and kwargs, but you don't ne

        We don't need this for our own code, because we have `core.utils.reverse_qs`,
        `core.utils.QueryStringKwargsViewMixin` and `core.templatetags.core.url_qs` to do all the proper work for this.

    """
    try:
        return orig_reverse(viewname, urlconf=urlconf, args=args, kwargs=kwargs, current_app=current_app)
    except django.urls.exceptions.NoReverseMatch:
        prefixes = getattr(settings, 'PATCHED_QUERY_STRING_URL_NAMESPACES', ['admin'])
        prefixes = list(set(prefixes))
        if any([viewname.startswith(prefix + ':') for prefix in prefixes]):
            url = orig_reverse(viewname, urlconf=urlconf, current_app=current_app)
            kwargs = kwargs or {}
            args = args or []
            for i, arg in enumerate(args):
                # If someone passed args, set them as special query params that can be unpacked
                # later by the view wrapper
                kwargs['__arg{}'.format(i)] = arg
            if kwargs:
                url = url + "?" + urlencode(kwargs)
            return url
        else:
            raise
django.urls.base.reverse = patched_reverse  # noqa: E305
django.urls.reverse = patched_reverse  # noqa: E305

