"""
This patches django.contrib.admin so that anyone using it gets the query string enabled code from djunk.admin instead
of the usual RESTful path versions.  This patch:

    * replaces the default django admin site object with a QueryStringAdminSite instance
    * replaces the AdminSite class with QueryStringAdminSite
    * replaces ModelAdmin with QueryStringModelAdmin
    * patches reverse() to supply the appropriate query parameters when rendering 'admin' namespace urls

To apply, import this file in your wsgi.py before importing any other django modules::

    import djunk.monkey_patches.admin_site_qs

"""

import djunk.monkey_patches.reverse
import django.contrib.admin
import django.contrib.admin.sites
import django.contrib.admin.options

from djunk.admin import site, QueryStringModelAdmin, QueryStringAdminSite

django.contrib.admin.site = site
django.contrib.admin.sites.site = site

django.contrib.admin.AdminSite = QueryStringAdminSite
django.contrib.admin.sites.AdminSite = QueryStringAdminSite

django.contrib.admin.ModelAdmin = QueryStringModelAdmin
django.contrib.admin.options.ModelAdmin = QueryStringModelAdmin
