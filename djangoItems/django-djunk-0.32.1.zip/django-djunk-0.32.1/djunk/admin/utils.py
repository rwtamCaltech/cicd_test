import re

from django.urls.converters import get_converter
from django.core.exceptions import ImproperlyConfigured
from django.urls.resolvers import _PATH_PARAMETER_COMPONENT_RE


def compile_query_param_converters(view, params):
    """
    Given a list of path parameters of the form `<CONVERTER:PARAM_NAME>`, where converter is one
    of the converters defined on https://docs.djangoproject.com/en/3.0/topics/http/urls/#path-converters
    and PARAM_NAME is the list of parameter names, return a dict of `{ PARAM_NAME: converter.regex }`.

    :param view: A view class or function.
    :param params list(string): a list of path parameters

    :rtype: dict(str, regex)
    """
    params = params or []
    # first confirm we got the right format for the parameters
    param_dict = {}
    for param in params:
        match = _PATH_PARAMETER_COMPONENT_RE.match(param)
        if not _PATH_PARAMETER_COMPONENT_RE.match(param):
            raise ImproperlyConfigured(
                "Query String enabled view '{}' uses invalid parameter spec {}s.".format(
                    str(view),
                    param
                )
            )
        # This next bit is lifted from django.urls.resolvers._route_to_regex()
        parameter = match.group('parameter')
        raw_converter = match.group('converter')
        if raw_converter is None:
            # If a converter isn't specified, the default is `str`.
            raw_converter = 'str'
        try:
            converter = get_converter(raw_converter)
        except KeyError as e:
            raise ImproperlyConfigured(
                "Query String enabled view '{}' uses invalid parameter converter {}.".format(
                    str(view),
                    e
                )
            )
        param_dict[parameter] = re.compile(converter.regex)
    return param_dict
