from functools import update_wrapper

from django.contrib.admin.options import ModelAdmin
from django.http import HttpResponseBadRequest

from .utils import compile_query_param_converters


class QueryStringModelAdmin(ModelAdmin):

    """
    This subclass of ModelAdmin registers non-RESTful URLs for all of its views.  This is so we can force
    the Django Admin to use query parameters for all of its views instead of URL parts.

    This is important for CIT_AUTH, because the URLs in CAPAuthorizationURL cannot have variable parts.

    To fully use this, use `djunk.admin.sites.site` as your admin site, and add::

        import djunk.monkey_patches.reverse

    to your wsgi.py before any django imports.
    """

    def get_urls(self):
        from django.urls import path

        def wrap_qs(view, query_params=None):
            """
            `query_params` is a list of django path parameters: e.g. "<int:pk>", "<slug:slug>", etc.

            We will convert each of those to a query parameter of the same name for which values
            will be validated according to its type.

            Look through the query parameters that were passed to us, extract any that
            match any our `query_params`, and pass those into the view as `kwargs`.

            Additionally, look through the query parameters for any that match the pattern
            `__arg[0-9]+`: these were passed to `reverse()` as positional parameters.  Extract
            their values and pass them into the view as the associated kwarg.

            If validation on any parameter fails, return 400 Bad Request.
            """
            query_params = query_params or []
            # first confirm we got the right format for the parameters
            param_dict = compile_query_param_converters(view, query_params)

            def wrapper(*args, **kwargs):
                request = args[0]
                for i, param in enumerate(param_dict.keys()):
                    if param in kwargs:
                        raise KeyError(
                            'Param {} is already in kwargs'.format(param)
                        )
                    # first try to get ``param`` directly
                    value = request.GET.get(param, None)
                    # Now try to get it as a "positional" argument
                    if not value:
                        value = request.GET.get('__arg{}'.format(i), None)
                    # Validate that the value conforms to our converter regex
                    kwargs[param] = value
                    if not param_dict[param].match(value):
                        return HttpResponseBadRequest(
                            'Invalid value for {}.'.format(param),
                            status=400
                        )
                return self.admin_site.admin_view(view)(*args, **kwargs)
            wrapper.admin_site = self
            return update_wrapper(wrapper, view)

        info = self.model._meta.app_label, self.model._meta.model_name

        urlpatterns = [
            path('', wrap_qs(self.changelist_view), name='%s_%s_changelist' % info),
            path('add/', wrap_qs(self.add_view), name='%s_%s_add' % info),
            path('autocomplete/', wrap_qs(self.autocomplete_view), name='%s_%s_autocomplete' % info),
            path('history/', wrap_qs(self.history_view, query_params=['<int:object_id>']), name='%s_%s_history' % info),
            path('delete/', wrap_qs(self.delete_view, query_params=['<int:object_id>']), name='%s_%s_delete' % info),
            path('change/', wrap_qs(self.change_view, query_params=['<int:object_id>']), name='%s_%s_change' % info),
        ]
        return urlpatterns
