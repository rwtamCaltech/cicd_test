from functools import update_wrapper

from django.contrib.admin.sites import AdminSite

from django.http import HttpResponseBadRequest

from .utils import compile_query_param_converters


class QueryStringAdminSite(AdminSite):
    """
    This subclass of AdminSite registers non-RESTful URLs for all of its views.  This is so we can force
    the Django Admin to use query parameters for all of its views instead of URL parts.

    This is important for CIT_AUTH, because the URLs in CAPAuthorizationURL cannot have variable parts.

    To fully use this, use `djunk.admin.options.QueryStringModelAdmin` wherever you would use
    `django.contrib.admin.ModelAdmin`, and add::

        import djunk.monkey_patches.reverse

    to your wsgi.py before any django imports.
    """

    def get_urls(self):
        from django.urls import include, path, re_path
        # Since this module gets imported in the application's root package,
        # it cannot import models from other applications at the module level,
        # and django.contrib.contenttypes.views imports ContentType.
        from django.contrib.contenttypes import views as contenttype_views

        def wrap(view, cacheable=False):
            def wrapper(*args, **kwargs):
                return self.admin_view(view, cacheable)(*args, **kwargs)
            wrapper.admin_site = self
            return update_wrapper(wrapper, view)

        def wrap_qs(view, cacheable=False, query_params=None):
            """
            `query_params` is a list of django path parameters: e.g. "<int:pk>", "<slug:slug>", etc.

            We will convert each of those to a query parameter of the same name for which values
            will be validated according to its type.

            Look through the query parameters that were passed to us, extract any that
            match any our `query_params`, and pass those into the view as `kwargs`.

            Additionally, look through the query parameters for any that match the pattern
            `__arg[0-9]+`: these were passed to `reverse()` as positional parameters.  Extract
            their values and pass them into the view as the associated kwarg.

            If validation on any parameter fails, return 400 Bad Request.

            """
            query_params = query_params or []
            # first confirm we got the right format for the parameters
            param_dict = compile_query_param_converters(view, query_params)

            def wrapper(*args, **kwargs):
                request = args[0]
                for i, param in enumerate(param_dict.keys()):
                    if param in kwargs:
                        raise KeyError(
                            'Param {} is already in kwargs'.format(param)
                        )
                    # first try to get ``param`` directly
                    value = request.GET.get(param, None)
                    # Now try to get it as a "positional" argument
                    if not value:
                        value = request.GET.get('__arg{}'.format(i), None)
                    # Validate that the value conforms to our converter regex
                    kwargs[param] = value
                    if not param_dict[param].match(value):
                        return HttpResponseBadRequest(
                            'Invalid value for {}.'.format(param),
                            status=400
                        )
                return self.admin_view(view, cacheable)(*args, **kwargs)
            wrapper.admin_site = self
            return update_wrapper(wrapper, view)

        # Admin-site-wide views.
        urlpatterns = [
            path('', wrap(self.index), name='index'),
            path('login/', self.login, name='login'),
            path('logout/', wrap(self.logout), name='logout'),
            path('password_change/', wrap(self.password_change, cacheable=True), name='password_change'),
            path(
                'password_change/done/',
                wrap(self.password_change_done, cacheable=True),
                name='password_change_done',
            ),
            path('jsi18n/', wrap(self.i18n_javascript, cacheable=True), name='jsi18n'),
            path(
                'view_on_site/',
                wrap_qs(contenttype_views.shortcut, ['<int:content_type_id>', '<int:object_id>']),
                name='view_on_site',
            ),
        ]

        # Add in each model's views, and create a list of valid URLS for the
        # app_index
        valid_app_labels = []
        for model, model_admin in self._registry.items():
            urlpatterns += [
                path('%s/%s/' % (model._meta.app_label, model._meta.model_name), include(model_admin.urls)),
            ]
            if model._meta.app_label not in valid_app_labels:
                valid_app_labels.append(model._meta.app_label)

        # If there were ModelAdmins registered, we should have a list of app
        # labels for which we need to allow access to the app_index view,
        if valid_app_labels:
            regex = r'^(?P<app_label>' + '|'.join(valid_app_labels) + ')/$'
            urlpatterns += [
                re_path(regex, wrap(self.app_index), name='app_list'),
            ]
        return urlpatterns

# --------------------------------------------------------

# This global object represents the default admin site, for the common case.
# You can instantiate AdminSite in your own code to create a custom admin site.
site = QueryStringAdminSite()
