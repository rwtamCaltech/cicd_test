import logging
from unidecode import unidecode

MINUTE = 60


def get_cache_tags_for_request(
    request, kwarg_name_for_key=None, kwarg_location='view', default_kwarg_value=None, object_name=None
):
    """
    Returns the cache-tagging tags which should be applied to the given request.

    args:
      kwarg_name_for_key - REQUIRED. The name of the view kwarg that holds the key to use as part of a cache tag.
      kwarg_location - IF the kwarg you want to use as the key vlue isn't in the view's kwargs, specify 'GET' or 'POST'
        here to have it pulled from either of those parts of the request.
      default_kwarg_value - If the named kwarg can potentially be unset, specify the default value here.
      object_name - Specify to increase cache tag granularity. Could be the name of the model whose detail page is
        being cached, or anything else.

    This function sends a DEBUG-level log message to the "caching" logger, recording which tags got applied to the
    output of which view.
    """
    tags = ['all']

    try:
        # Grab the app_name and view_name for later.
        app_name = request.view_data['app_name']
        view_name = request.view_data['view_name']
    except AttributeError:
        # If request.view_data doesn't exists, BindViewDataToRequestMiddleware isn't installed.
        pass
    else:
        tags.append(app_name)
        tags.append('{0}.{1}'.format(app_name, view_name))

    if kwarg_name_for_key:
        if kwarg_location == 'view':
            # Grab the view kwarg which holds the key.
            pk = request.view_data['kwargs'].get(kwarg_name_for_key, default_kwarg_value)
        elif kwarg_location == 'GET':
            # Grab the GET argument which holds the key.
            pk = request.GET.get(kwarg_name_for_key, default_kwarg_value)
        else:
            # Grab the POST argument which holds the key.
            pk = request.POST.get(kwarg_name_for_key, default_kwarg_value)
        # The cache-dependencies library, which is generally what these tags get sent to, sometimes crashes on non-
        # ascii-compatible text. unideocde() performs a "best effort" conversion of unicode to equivalent ascii.
        # Can't send None to unidecode. It'll crash.
        if pk is not None:
            pk = unidecode(pk)

    # Build the cache tags for each level of granularity.
    if kwarg_name_for_key:
        tags.append('{0}.{1}:id={2}'.format(app_name, view_name, pk))
    if object_name:
        tags.append('{0}.{1}.{2}'.format(app_name, view_name, object_name))
        if kwarg_name_for_key:
            tags.append('{0}.{1}.{2}:id={3}'.format(app_name, view_name, object_name, pk))

    logging.getLogger('caching').debug('Caching view output from {0} with the following tags: {1}'.format(
        request.resolver_match.view_name, ', '.join(tags))
    )
    return tags
