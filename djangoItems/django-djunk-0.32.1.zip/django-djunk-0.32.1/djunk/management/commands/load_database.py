import os
from django.core.management import call_command
from django.core.management.base import BaseCommand


class Command(BaseCommand):

    def handle(self, *args, **options):
        # Import the contents of the file "db_dump.json" from the current working directory.
        path = os.path.abspath(os.getcwd())
        filename = os.path.join(path, "db_dump.json")

        self.stdout.write("LOADING DATABASE FROM THE FOLLOWING FILE:")
        self.stdout.write("\t{0}".format(filename))

        call_command('loaddata', filename)
