import os
from django.core.management.base import BaseCommand
from django.contrib.staticfiles import storage
from django.conf import settings


class Command(BaseCommand):

    def __init__(self, *args, **kwargs):
        super(Command, self).__init__(*args, **kwargs)
        self.storage = storage.staticfiles_storage

    def handle(self, *args, **options):
        self.stdout.write("Deleting the contents of the STATIC_ROOT directory {0} ...".format(settings.STATIC_ROOT))
        self.clear_dir(settings.STATIC_ROOT, top_level=True)
        self.stdout.write("The collected static files have been deleted.")

    def clear_dir(self, path, top_level=False):
        """
        Deletes the given relative path using the destination storage backend.
        The top_level directory is not deleted, but all subdirectories are.
        """
        dirs, files = self.storage.listdir(path)
        for f in files:
            fpath = os.path.join(path, f)
            self.storage.delete(fpath)
            self.delete_if_symlink(fpath)
        for d in dirs:
            self.clear_dir(os.path.join(path, d))

        # Only attempt to delete non-top_level directories that actually exist (directories don't exist on S3).
        if not top_level and self.storage.exists(path):
            try:
                self.storage.delete(path)
            except OSError:
                # If the filesystem doesn't support calling os.remove() on directories (FileSystemStorage doesn't),
                # try os.rmdir().
                try:
                    os.rmdir(path)
                except:
                    # In case os.rmdir() doesn't work, report the error and move on.
                    self.stderr.write("Unable to delete the directory: {0}".format(path))

    def is_local_storage(self):
        from django.utils.functional import LazyObject
        from django.core.files.storage import FileSystemStorage
        # This is copied django's collectstatic. It might be useful in the future, if we ever need to use clearstatic
        # on a non-local filesystem.
        if issubclass(self.storage.__class__, LazyObject):
            storage = self.storage._wrapped
        else:
            storage = self.storage
        return isinstance(storage, FileSystemStorage)

    def delete_if_symlink(self, path):
        # Symlinks to non-existent paths are skipped by self.storage.delete(), so we need to detect those
        # and delete them ourselves. os.readlink() throws OSError if 'path' is not a symlink.
        try:
            os.readlink(path)
        except OSError:
            pass
        else:
            os.remove(path)
