import os
from django.core.management import call_command
from django.core.management.base import BaseCommand
from django.conf import settings


class Command(BaseCommand):

    def handle(self, *args, **options):
        self.stdout.write("DUMPING DATABASE FOR THE FOLLOWING APPS:")
        self.stdout.write("\t" + " ".join(settings.DB_DUMP_APPS))

        # Export the database contents to the file "db_dump.json" in the current working directory.
        path = os.path.abspath(os.getcwd())
        filename = os.path.join(path, "db_dump.json")

        with open(filename, "w+") as f:
            call_command('dumpdata', *settings.DB_DUMP_APPS, stdout=f, indent=2)

        self.stdout.write("Data dumped to {0}".format(filename))
