import re
import threading
from collections import defaultdict
from django.conf import settings
from django.contrib.auth.middleware import PersistentRemoteUserMiddleware
from django.core.exceptions import MiddlewareNotUsed
from django.http.response import HttpResponsePermanentRedirect
from django.middleware.locale import LocaleMiddleware
from django.utils import translation
from django.utils.http import urlencode
from crequest.middleware import CrequestMiddleware

from .utils import get_client_ip, getenv

try:
    from django.utils.deprecation import MiddlewareMixin
except ImportError:
    MiddlewareMixin = object


class NoCurrentRequestException(Exception):
    pass


def get_current_request(default=None, silent=True, label='__DEFAULT_LABEL__'):
    """
    Returns the current request. This is a more robust form of get_current_request, but it's not backwards compatible,
    so we gave it a different name.

    You can optonally use ``default`` to pass in a dummy request object to act as the default if there is no current
    request, e.g. when ``get_current_request()`` is called during a manage.py command.

    2019-09-24 rrollins: This version of get_current_request is backwards compatible with the old version, while
    offering the exception raising functionality of multitnent's get_current_request2() when passed silent=False.

    :param default: (optional) a dummy request object
    :type default: an object that emulates a Django request object

    :param silent: If ``False``, raise an exception if CRequestMiddleware can't get us a request object.  Default: True
    :type silent: boolean

    :param label: If ``silent`` is ``False``, put this label in our exception message
    :type label: string

    :rtype: a Django request object
    """
    request = CrequestMiddleware.get_request(default)
    if request is None and not silent:
        raise NoCurrentRequestException(
            "{} failed because there is no current request. Try using djunk.utils.FakeCurrentRequest.".format(label)
        )
    return request


def get_current_user(default=None):
    """
    Returns the user responsible for the current request.

    You can optonally use ``default`` to pass in a dummy request object to act as the default if there is no current
    request, e.g. when ``get_current_user()`` is called during a manage.py command.

    :param default: (optional) a dummy request object
    :type default: an object that emulates a Django request object

    :rtype: a settings.AUTH_USER_MODEL type object
    """
    try:
        return get_current_request().user
    except AttributeError:
        # There's no current request to grab a user from.
        return default


class BindViewDataToRequestMiddleware(MiddlewareMixin):
    """
    Binds data about the view being served by this request into the request object.
    Useful for cache tagging.

    USEAGE NOTE: Always add this as the very first middleware in the MIDDLEWARE_CLASSES array. Otherwise,
    request.view_data['view_name'] will not be set correctly.
    """

    def process_view(self, request, view, view_args, view_kwargs):
        request.view_data = {
            'callback': view,
            'args': view_args,
            'kwargs': view_kwargs,
            'view_name': view.func_name,
            # Since we name our namepsaces the same as our apps, we can use it as the app name if app_name isn't set.
            'app_name': request.resolver_match.app_name or request.resolver_match.namespace,
        }


class SlashMiddleware(MiddlewareMixin):
    """
    SlashMiddleware reads from the SLASHED_PATHS setting to determine which URLs to redirect from e.g. /page/ to /page
    (for aesthetics), and which to redirect from e.g. /admin to /admin/ (for hardcoded URLs that require end-slashes).

    SLASHED_PATHS must be a list of strings that start with a slash but DON'T end with one, e.g. '/admin'.

    This middleware must go first in the MIDDLEWARE_CLASSES setting. You should remove
    django.middleware.common.CommonMiddleware, as its functionality conflicts with SlashMiddleware.

    You must also set:
    APPEND_SLASH = False
    WAGTAIL_APPEND_SLASH = False
    They will conflict with SlashMiddleware if they are left with their default values.
    """

    def process_request(self, request):
        """
        Redirects all unslashed paths that match the SLASHED_PATHS setting to their slashed version.
        Redirects all slashed paths that don't match the SLASHED_PATHS setting to their slashless version.
        """
        # For some dumb reason, str.startswith() ONLY accepts tuples of strings.
        # Thus, we cast to tuple to allow our users to use any sequence type for SLASHED_PATHS.
        slashed_paths = tuple(getattr(settings, 'SLASHED_PATHS', []))

        if request.path.startswith(slashed_paths) and not request.path.endswith('/'):
            # Redirect to slashed versions.
            url = request.path + '/'
            if request.GET:
                url += '?{}'.format(urlencode(request.GET, True))
            return HttpResponsePermanentRedirect(url)
        elif (not request.path.startswith(slashed_paths) and request.path.endswith('/') and not request.path == '/'):
            # Redirect to unslashed versions.
            url = request.path[:-1]
            if request.GET:
                url += '?{}'.format(urlencode(request.GET, True))
            return HttpResponsePermanentRedirect(url)


class OnCampusMiddleware(MiddlewareMixin):
    """
    Middleware sets ON_CAMPUS session variable to True if the request
    came from an campus IP or if the user is authenticated.
    """

    CAMPUS_ADDRESSES = [
        r'131\.215\.\d{1,3}\.\d{1,3}',
        r'134\.4\.\d{1,3}\.\d{1,3}',
        r'137\.79\.\d{1,3}\.\d{1,3}',
        r'137\.78\.\d{1,3}\.\d{1,3}',
        r'192\.138\.101\.\d{1,3}',
        r'192\.107\.192\.\d{1,3}',
        r'192\.100\.16\.\d{1,3}',
        r'192\.76\.121\.\d{1,3}',
        r'192\.74\.212\.\d{1,3}',
        r'192\.12\.19\.\d{1,3}',
        r'128\.171\.86\.\d{1,3}',
        r'128\.171\.85\.\d{1,3}',
        r'128\.171\.71\.\d{1,3}',
        r'128\.149\.\d{1,3}\.\d{1,3}',
        r'127\.0\.0\.1',
    ]

    def check_ip(self, request):
        client_ip = get_client_ip(request)

        if client_ip:
            for ip_regex in self.CAMPUS_ADDRESSES:
                if re.match(ip_regex, client_ip):
                    return True
        return False

    def process_request(self, request):
        # A user is considered "on campus" if they are visiting from a campus IP, or are logged in to the site.
        request.session['ON_CAMPUS'] = request.user.is_authenticated or self.check_ip(request)
        return None
# 2020-01-29 rrollins: This used to be called RestrictedContentMiddleWare, a name made obsolete by changes made to
# the code long ago. This alias exists to allow django-djunk to remain backwards compatible with old software.
RestrictedContentMiddleWare = OnCampusMiddleware


class AccessCaltechOnCampusMiddleware(OnCampusMiddleware):
    """
    A version of OnCampusMiddleware that works under the authentication system used by access.caltech apps.
    """

    def check_access_caltech(self, request):
        """
        Django converts all headers from the client into HTTP_* headers
        """
        user = request.META.get("HTTP_USER")
        caltechuid = request.META.get("HTTP_CAPCALTECHUID")
        fullname = request.META.get("HTTP_USER_CN")
        mail = request.META.get("HTTP_USER_MAIL")
        return user and caltechuid and fullname and mail

    def process_request(self, request):
        request.session['ON_CAMPUS'] = self.check_ip(request) or self.check_access_caltech(request)
        return None
# 2020-01-29 rrollins: This alias exists to allow django-djunk to remain backwards compatible with old software.
AccessCaltechRestrictedContentMiddleWare = AccessCaltechOnCampusMiddleware


class MiddlewareIterationCounter(object):
    """
    This middleware exists to prevent PydevMiddleware from being loaded more than once.

    By counting the interations of the middleware chain, we can subclass or rewrite problematic middleware to make them
    exclude themselves from internal executions of the middleware chain.
    """

    _iterations = defaultdict(int)

    def __init__(self, get_response=None):
        self.get_response = get_response

    def __call__(self, request):
        current_thread = threading.current_thread()
        # Increment the current thread's interation counter on ingress.
        self._iterations[current_thread] += 1
        response = self.get_response(request)
        # Decrement the current thread's interation counter on egress.
        self._iterations[current_thread] -= 1
        # If we're down to 0 interations, delete the counter to avoid a memory leak.
        if self._iterations[current_thread] == 0:
            del self._iterations[current_thread]
        return response

    @classmethod
    def get_iteration_count(cls):
        """
        Returns the iteration count for the current thread.
        Since cls._iterations is a defaultdict, this can safely be called before the first increment, which returns 0.
        """
        return cls._iterations[threading.current_thread()]


class PydevMiddleware:
    """
    Allows for straightforward debugging via a pydevd-based remote debugging server, as configured via env vars.
    This middleware must be placed _first_ in the MIDDLEWARE list, so that debugging is enabled before the rest of the
    middleware are executed.

    This code deals with all the esoteric hassles that can plague remote debugging, so you (Robert) don't have to.
    """

    def __init__(self, get_response):
        self.get_response = get_response

        if not getenv('REMOTE_DEBUG_ENABLED', False):
            # Don't enable this middleware if REMOTE_DEBUG_ENABLED isn't True.
            raise MiddlewareNotUsed

        # Skip this middleware if the middleware chain has already run at least once.
        # This prevents pydevd.stoptrace() from being called too early during preview requests.
        if MiddlewareIterationCounter.get_iteration_count() >= 1:
            # DEV NOTE: Paradoxically, this middleware must go in MIDDLEWARE before MiddlewareIterationCounter, even
            # though it uses get_iteration_count(), because otherwise we couldn't debug MiddlewareIterationCounter
            # itself. This means that the above call to get_iteration_count() will in fact _create_ the entry in
            # MiddlewareIterationCounter._iterations (with a value of 0), due to it being a defaultdict. This is mind-
            # bendy, but it's exactly why MiddlewareIterationCounter._iterations is a defaultdict, rather than a dict.
            raise MiddlewareNotUsed

        self.host = getenv('REMOTE_DEBUG_HOST', None)
        self.port = getenv('REMOTE_DEBUG_PORT', None)
        print(f'DEBUGGING ENABLED. Ensure that a PyCharm/PyDev debug server is running at {self.host}:{self.port}')
        # We do this import after the REMOTE_DEBUG_ENABLED check because simply performing the import slows down the
        # process, even if we don't call settrace().
        import pydevd
        # This is how the scoping issue that originally prevented this middleware from being class-based is solved.
        # Since modules are objects, we can assign pydevd as an attribute on this instance of PydevMiddleware, which
        # lets the __call__() method retrieve the module to use its functions.
        self.pydevd = pydevd

    def __call__(self, request):
        # Before the request, we hook into the debug server. Unless this is a static resource request.
        if not request.path.startswith('/static/'):
            print('Begining debuggable request...')
            try:
                self.pydevd.settrace(host=self.host, port=self.port, suspend=False, trace_only_current_thread=True)
            except (AttributeError, ConnectionRefusedError):
                print('Debugger was unable to connect to the debug server.')

        # Pass the request on to the next middleware in the chain.
        response = self.get_response(request)

        # Once the request is done, we disconnect from the debug server. This prevents the connection from being idle
        # between requests, avoiding difficult-to-diagnose annoyances caused by anything that kills idle TCP
        # connections (*cough* Docker for Mac) and also allowing manage.py commands to be debugged more easily.
        if not request.path.startswith('/static/'):
            self.pydevd.stoptrace()

        return response


class AccessCaltechUserMiddleware(PersistentRemoteUserMiddleware):
    """
    Note: Use of this middleware means that you mustn't use the @login_required decorator on your views. That decorator
    will redirect users to the login page if they aren't logged it, but it does that BEFORE this middleware has a
    chance to "log them in" based on the HTTP_USER header.
    """
    header = "HTTP_USER"


class AccessCaltechLocaleMiddleware(LocaleMiddleware):
    """
    Due to the way access.caltech authentication works, and the fact that we can't authorize django's usual multilingual
    URLs through CIT_AUTH, the regular LocaleMiddleware is not quite sufficient for our needs.

    Instead, we base language preference on the 'lang' query arg. This middleware ensures that if the user issues
    any request with the ?lang=es query, their language preference will be set to Spanish, and that pref will persist
    through subsequent requests, until they perform a request with ?lang=en to set their preference back to English.

    If the app should NOT persist language preference across requests, set PERSIST_LANGUAGE_PREF=False in settings.py.

    Note that this middleware will reject any attempt to set a language code that's not in LANGUAGES in settings.py.

    2020-02-25 rrollins: This doesn't quite work right as of Django 3.0. Since Django no longer allows you to set
    language preference in the session, our "persist" mechanism is busted.
    I think, ultimately, that we'll abandon this middleware in favor of django's usual LocaleMiddleware, and use
    cookies to set the language code, instead of GET args.
    """

    def process_request(self, request):
        # Do the default request processing from LocaleMiddleware.
        super().process_request(request)
        # If the user specified a supported language code with the 'lang' query arg, override what LocaleMiddleware
        # did with the language code specified in the query.
        user_language_code = request.GET.get('lang')
        if self._lang_code_is_supported(user_language_code):
            translation.activate(user_language_code)
            request.LANGUAGE_CODE = translation.get_language()
            # Persist the language preference into the session unless PERSIST_LANGUAGE_PREF=False, so that subsequent
            # requests need not necessarily use the 'lang' query. Storing it in the session means that it won't get
            # re-used by a different user on the same shared computer.
            if getattr(settings, 'PERSIST_LANGUAGE_PREF', True):
                request.session[translation.LANGUAGE_SESSION_KEY] = user_language_code

    def process_response(self, request, response):
        response = super().process_response(request, response)
        user_language_code = request.GET.get('lang')
        response.set_cookie(settings.LANGUAGE_COOKIE_NAME, user_language_code)
        return response

    def _lang_code_is_supported(self, code):
        """
        Don't allow malicious actors to set an unsupported language code, which is important because we print that code
        into the <html> tag.
        """
        return code in (lang_tuple[0] for lang_tuple in settings.LANGUAGES)
