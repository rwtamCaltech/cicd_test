
def fix_django_form_css_classes():
    """
    For some stupid reason, django assumes you *don't want* classes for your required fields and form errors. So you
    have to add them manually to each and every form class you create. This is ridiculous, so I wrote this function.

    Execute this function to monkey-patch the django.forms.BaseForm class so that it has appropriate default css classes
    for required fields and form errors.

    Call this function from your project's root URLconf, since that always runs once, earlier than any form code.
    """
    from django import forms
    forms.BaseForm.required_css_class = 'required'
    forms.BaseForm.error_css_class = 'error'
