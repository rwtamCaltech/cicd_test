from functools import wraps
from django.core.exceptions import PermissionDenied


def restrict_to_campus(fn):
    """
    When using djunk.middleware.OnCampusMiddleware, use this decorator to restrict a django view to on-campus or
    logged-in users.
    """
    @wraps(fn)
    def wrapper(request, *args, **kwargs):
        if not request.session.get('ON_CAMPUS'):
            raise PermissionDenied
        return fn(request, *args, **kwargs)
    return wrapper


