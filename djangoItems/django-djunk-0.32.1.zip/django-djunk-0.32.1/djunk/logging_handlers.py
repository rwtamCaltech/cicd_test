from __future__ import print_function, unicode_literals
import re
import sys
import socket
import traceback
import structlog
from six import StringIO, text_type
from logging.handlers import SysLogHandler

from structlog.dev import (_MISSING, _ColorfulStyles, _PlainStyles)

try:
    import colorama
except ImportError:
    colorama = None


djunk_logger = structlog.get_logger('django-djunk')


def print_stacktrace(file=sys.stdout, logger=None, action=None):
    """
    Mind-bogglingly enough, the Python standard library does not have anything that prints the complete stacktrace
    that you would get if you were to allow the exception to propogate to the top. This function does just that,
    printing the tracetrace to the specified file (sys.stdout by default).
    """
    exp_type, exp, trace = sys.exc_info()
    exception_list = traceback.format_stack()
    exception_list = exception_list[:-2]
    exception_list.extend(traceback.format_tb(trace))
    exception_list.extend(traceback.format_exception_only(exp_type, exp))

    exception_str = "Traceback (most recent call last):\n"
    exception_str += "".join(exception_list)
    # Remove the extra newline at the end before printing.
    exception_str = exception_str[:-1]

    if logger and action:
        # If a logger was specified, use it instead of printing.
        getattr(logger, action)(exception_str)
    else:
        print(exception_str, file=file, end='')


# Must inherit from object here because the ultimate baseclase for SysLogHandler in Python 2.6 is an old-style class,
# which breaks super().
class DjangoSysLogHandler(SysLogHandler, object):
    MAX_LEN = 1800

    def emit(self, record):
        """
        Emit a record.

        The record is formatted, and then sent to the syslog server. If exception information is present, it is NOT
        sent to the server.

        rrollins: Our solution of catching the "[Errno 40] message too long" exception doesn't work on every server,
        because some just silently truncate the message. So we need to do our manual line-splitting and character
        limiting in both emit() and handleError().
        """
        formatted_message = self.format(record)
        prio = b'<%d>' % self.encodePriority(self.facility, self.mapPriority(record.levelname))

        # Split the output into sets of lines, then combine them into messages that are shorter than MAX_LEN.
        lines = formatted_message.splitlines()
        messages = []
        current_message = ''
        for line in lines:
            if len(current_message) + len(line + '\n') < self.MAX_LEN:
                current_message += line + '\n'
            else:
                messages.append(current_message)
                current_message = '\n{0}\n'.format(line)
        messages.append(current_message)

        for msg in messages:
            msg = msg + '\000'
            # Convert unicode messages to bytes, as required by RFC 5424.
            if isinstance(msg, text_type):
                msg = msg.encode('utf-8')
            msg = prio + msg
            try:
                if self.unixsocket:
                    try:
                        self.socket.send(msg)
                    except socket.error:
                        self.socket.close()  # See issue 17981
                        self._connect_unixsocket(self.address)
                        self.socket.send(msg)
                elif self.socktype == socket.SOCK_DGRAM:
                    self.socket.sendto(msg, self.address)
                else:
                    self.socket.sendall(msg)
            except (KeyboardInterrupt, SystemExit):
                raise
            except:  # noqa
                self.handleError(record)

    def handleError(self, record, trace=None):
        """
        On OSX (and apparently all BSD-based unix systems), there is a hard limit on the number of
        characters that that can be sent to the syslog on a single line.  If a message is sent that is
        too long, an "[Errno 40] message too long" exception will be thrown.

        This function deals with that error by re-emitting the original message after manually splitting it
        into chunks that are smaller than the character limit.
        """
        # If this isn't "[Errno 40] message too long", just pass it on to the default error handler
        exc_info = sys.exc_info()
        if not hasattr(exc_info[1], 'errno') or exc_info[1].errno != 40:
            sys.stderr.write("An error has occured during logging, but this error has not been propagated to your app. It is printed below for informational purposes only:\n")  # noqa
            print_stacktrace(sys.stderr)

        prio = b'<%d>' % self.encodePriority(self.facility, self.mapPriority(record.levelname))
        # Split the output into sets of lines, and combine them into messages that are less than MAX_LEN characters each
        formatted_message = self.format(record)
        lines = formatted_message.splitlines()
        messages = []
        current_message = '\n'
        if len(lines) > 1:
            for line in lines:
                if len(current_message) + len(line + '\n') < self.MAX_LEN:
                    current_message += line + '\n'
                else:
                    messages.append(current_message)
                    current_message = '\n{0}\n'.format(line)
            messages.append(current_message)
        else:
            # This is a very long message that's all on a single line (as opposed to be a large traceback), so
            # it needs a different type of processing.
            while formatted_message:
                messages.append(formatted_message[:self.MAX_LEN])
                formatted_message = formatted_message[self.MAX_LEN:]

        try:
            for msg in messages:
                # Convert unicode messages to bytes, as required by RFC 5424.
                if isinstance(msg, text_type):
                    msg = msg.encode('utf-8')
                msg = prio + msg
                self.socket.send(msg)
        except (KeyboardInterrupt, SystemExit):
            raise
        except:  # noqa
            sys.stderr.write("An error has occured during logging, but this error has not been propagated to your app. It is printed below for informational purposes only:\n")  # noqa
            print_stacktrace(sys.stderr)


class ConsoleRenderer(object):
    """
    ..note::

        I copied this from ``structlog.dev.ConsoleRenderer`` and changed it
        because I didn't like the way it formatted the log messages, and it offers
        no way to customize it. -- CPM

    Render `event_dict`, possibly in colors, and ordered.
    :param bool colors: Use colors for a nicer output.
    :param bool repr_native_str: When ``True``, :func:`repr()` is also applied
        to native strings (i.e. str on Python 3 and unicode on Python 2).
        Setting this to ``False`` is useful if you want to have human-readable
        non-ASCII output on Python 2.  The `event` key is *never*
        :func:`repr()` -ed.
    :param bool newlines: if ``False``, replace newlines with "``|||``"
    Requires the colorama_ package if *colors* is ``True``.
    .. _colorama: https://pypi.org/project/colorama/
    """
    def __init__(self, colors=False, repr_native_str=False, newlines=True):
        if colors is True:
            if colorama is None:
                raise SystemError(
                    _MISSING.format(
                        who=self.__class__.__name__ + " with `colors=True`",
                        package="colorama"
                    )
                )

            colorama.init()
            styles = _ColorfulStyles
        else:
            styles = _PlainStyles

        self.newlines = newlines
        self._styles = styles
        self._level_to_color = {
            "critical": styles.level_critical,
            "exception": styles.level_exception,
            "error": styles.level_error,
            "warn": styles.level_warn,
            "warning": styles.level_warn,
            "info": styles.level_info,
            "debug": styles.level_debug,
            "notset": styles.level_notset,
        }

        for key in self._level_to_color.keys():
            self._level_to_color[key] += styles.bright

        if repr_native_str is True:
            self._repr = repr
        else:
            def _repr(inst):
                if isinstance(inst, text_type):
                    return inst
                else:
                    return repr(inst)
            self._repr = _repr

    def color(self, msg, color):
        color_str = getattr(self._styles, color, None)
        if color_str is None:
            color_str = color
        return "{}{}{}".format(color_str, msg, self._styles.reset)

    def __call__(self, _, __, event_dict):
        sio = StringIO()

        # Format the timestamp directly into the log string.
        ts = event_dict.pop('timestamp', None)
        if ts:
            sio.write(self.color('{} '.format(ts), 'timestamp'))

        # Format the log level directly into the log string.
        level = event_dict.pop('level', None)
        if level:
            # Ensure that level is the same type of string as the keys in self._level_to_color.
            sio.write('[{}] '.format(self.color(level.upper(), self._level_to_color[level])))

        # Format the logger name directly into the log string.
        logger_name = event_dict.pop('logger', None)
        if logger_name:
            sio.write('{}: '.format(self.color(logger_name, 'bright')))

        # Format the event name into the log string, adding a space only if there is data from the event left to log.
        event = event_dict.pop('event')
        event = self.color(event, 'bright')
        if event_dict:
            event = event + " "
        sio.write(event)

        # Pull the strack trace and exception info out of the event_dict, so we can format them into the log string
        # later, if they're relevant.
        stack = event_dict.pop('stack', None)
        exc = event_dict.pop('exception', None)

        if stack is not None:
            sio.write('\n' + stack)
            if exc is not None:
                sio.write('\n\n' + '=' * 79 + '\n')
        if exc is not None:
            sio.write('\n' + exc)

        # Add the remainder of the event data to the log string as key=value chunks.
        sio.write(' '.join(
            '{}={}'.format(self.color(key, 'kv_key'), self.color(event_dict[key], 'kv_value'))
            for key in sorted(event_dict.keys())
        ))

        if not self.newlines:
            msg = re.sub('\n', '|||', sio.getvalue())
        else:
            msg = sio.getvalue()
        return msg
