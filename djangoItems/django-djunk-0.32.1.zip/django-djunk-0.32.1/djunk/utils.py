import logging
import os
import sys
import traceback
import warnings
from ast import literal_eval
from crequest.middleware import CrequestMiddleware
from django.core.exceptions import MiddlewareNotUsed
from django.db.models.constants import LOOKUP_SEP
from django.urls import reverse, reverse_lazy

CRASH_DEFAULT = 'crash-if-env-var-is-not-set'


class UnsetEnvironmentVariable(NameError):
    pass


def get_or_generate(model_class, defaults=None, **kwargs):
    """
    This function does the same thing as QuerySet.get_or_create(), except that it doesn't save() the model.
    This is useful for when you know an identifier for the object, but don't yet know the data that will fill in that
    object's non-null fields at the time that you want to create it.
    """
    defaults = defaults or {}
    lookup = kwargs.copy()
    for f in model_class._meta.fields:
        if f.attname in lookup:
            lookup[f.name] = lookup.pop(f.attname)
    params = {k: v for k, v in kwargs.items() if LOOKUP_SEP not in k}
    params.update(defaults)

    try:
        obj = model_class.objects.get(**lookup)
        created = False
    except model_class.DoesNotExist:
        obj = model_class(**params)
        created = True

    return obj, created


def install_if_available(INSTALLED_APPS, app_name):
    """
    Add the specific app to INSTALLED_APPS, if it's actually available.
    """
    if app_name:
        try:
            __import__(app_name)
            INSTALLED_APPS.append(app_name)
        except ImportError:
            pass


def getenv(var_name, default=CRASH_DEFAULT):
    """
    Returns the environment variable with the specified name. If that env var is not set, and the 'default' argument
    has not been specified, this function raises UnsetEnvironmentVariable.

    This function automatically converts 'False' and 'True' to booleans and integers values to ints.
    """
    value = os.getenv(var_name, default)
    if value == CRASH_DEFAULT:
        raise UnsetEnvironmentVariable(
            "The '{}' environment variable is not set, and no default was provided.".format(var_name)
        )

    # Convert the string value of the env var to a literal. e.g. 'False' to False, '45' to 45, etc.
    try:
        return literal_eval(value)
    except (ValueError, SyntaxError):
        # If literal_eval() throws ValueError, it could not convert value to a python literal. If that happens, we
        # just return value itself, because it might be something like 'test' or None, which are valid values.
        return value


def get_x_forwarded_for(request):
    """
    Parses the X-Forwarded-For header from the given django request object, returning a list of IP strings.
    If no X-Forwarded-For header exists, this returns an empty list.
    """
    header = request.META.get('HTTP_X_FORWARDED_FOR')
    return [ip.strip() for ip in header.split(',')] if header else []


def get_client_ip(request):
    """
    Returns the client's real IP, based on the combination of the X-Forwarded-For and Remote-Addr headers.
    Returns None if no IP can be determined.
    """
    forwarded_for = get_x_forwarded_for(request)
    return forwarded_for[0] if forwarded_for else request.META.get('REMOTE_ADDR')


def enable_database_logging():
    """
    Call this function in debugging code to enable django's db query logging.
    It returns the previous logging level of the django.db.backends logger.

    DO NOT CALL THIS FUNCTION IN PRODUCTUON CODE!!!
    """
    logger = logging.getLogger('django.db.backends')
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    return old_level


def disable_database_logging(log_level=logging.INFO):
    """
    Call this function after you're done logging db queries in your development code. It sets the django.db.backends
    logger back to normal.
    Pass in the log level value returned from enable_database_logging() to be more accurate about what "normal" means.

    DO NOT CALL THIS FUNCTION IN PRODUCTUON CODE!!!
    """
    logger = logging.getLogger('django.db.backends')
    logger.level = log_level


def set_fake_current_request(site=None, user=None, request=None, **kwargs):
    """
    Sets the current request to either a specified request object or a FakeRequest object built from the given Site
    and/or User. Any additional keyword args are added as attributes on the FakeRequest.
    """
    if request is None:
        # If the caller didn't provide a request object, create the "FakeRequest" class in-place and instantiate it.
        # Include empty GET and POST params, so that code which expects request.GET to exist won't crash. Callers can
        # override these values, if they want to, using GET and/or POST kwargs.
        attrs = {'site': site, 'user': user, 'GET': {}, 'POST': {}}
        attrs.update(kwargs)
        request = type('FakeRequest', (object,), attrs)()
    CrequestMiddleware.set_request(request)
    return request


class FakeCurrentRequest():
    """
    Implements set_fake_current_request() as a context manager. Use like this:
    with FakeCurrentRequest(some_site, some_user):
        // .. do stuff
    OR
    with FakeCurrentRequest(request=some_request):
        // .. do stuff

    When the context manager exits, the current request will be automatically reverted to its previous state.
    """
    NO_CURRENT_REQUEST = 'no_current_request'

    def __init__(self, site=None, user=None, request=None, **kwargs):
        self.site = site
        self.user = user
        self.request = request
        self.kwargs = kwargs

    def __enter__(self):
        # Store a copy of the original current request, so we can restore it when the context manager exits.
        self.old_request = CrequestMiddleware.get_request(default=self.NO_CURRENT_REQUEST)
        return set_fake_current_request(self.site, self.user, self.request, **self.kwargs)

    def __exit__(self, *args):
        if self.old_request == self.NO_CURRENT_REQUEST:
            # If there wasn't a current request when we entered the contact manager, remove the current request.
            CrequestMiddleware.del_request()
        else:
            # Otherwise, set the current request back to whatever it was when we entered.
            CrequestMiddleware.set_request(self.old_request)


def warn_with_traceback(message, category, filename, lineno, file=None, line=None):
    """
    Import 'warnings' and then replace warnings.showwarning with this function to make all warnings print a traceback.
    This is useful because warnings often trigger in someone ELSE'S code when your code does something wrong.

    Also be aware that by default, when a particular warning is triggered, it will not be shown again if it happens a
    second time in the same execution. Since the same warning might be triggered by multiple different parts of your
    code, try using this line alongside the one that replaces warnings.showwarning:
    warnings.simplefilter('always')
    """
    log = file if hasattr(file, 'write') else sys.stderr
    traceback.print_stack(file=log)
    log.write(warnings.formatwarning(message, category, filename, lineno, line))


class QueryInspectContextManager():
    """
    Code within this context manager will be profiled by django-queryinspect.
    django-queryinspect usually only works within requests, because it's implemented as a Django middleware.
    I figured out how to convert it into a Context Manager, for use in management commands and other non-request code.

    The ENABLE_QUERYINSPECT env var must be True for this context manager to work.

    TODO: I re-imepleneted this a little more elegantly inside django-queryinspect itself. If the owner accepts my pull
     request (https://github.com/dobarkod/django-queryinspect/pull/29), we can use that version, instead.
    """

    def __init__(self):
        try:
            # For unknown reasons, we can't import QueryInspectMiddleware at the top of the file. It seems to cause a
            # circular import or something. Importing it here also makes it a little easier to handle non-installation.
            from qinspect.middleware import QueryInspectMiddleware
            self.inspector = QueryInspectMiddleware()
        except (MiddlewareNotUsed, ImportError):
            # If ENABLE_QUERYINSPECT is false or django-queryinspect isn't installed, we can't do anything.
            self.inspector = None

    def __enter__(self):
        if self.inspector:
            # QueryInspectMiddleware doesn't actually use the request at all, so we can send a dummy value.
            self.inspector.process_request(None)
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        if self.inspector:
            # QueryInspectMiddleware.process_response() only adds keys to the response, so we can send a dummy dict.
            self.inspector.process_response(None, {})

def reverse_with_qs(name, **kwargs):
    return "{}?{}".format(reverse(name), "&".join(["{}={}".format(k, v) for k, v in kwargs.items()]))


def reverse_lazy_with_qs(name, **kwargs):
    return "{}?{}".format(reverse_lazy(name), "&".join(["{}={}".format(k, v) for k, v in kwargs.items()]))
