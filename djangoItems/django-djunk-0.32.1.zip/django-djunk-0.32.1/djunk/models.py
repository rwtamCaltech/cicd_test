from django.db import models
from django.contrib.auth.models import AbstractUser


class AbstractCAPUser(AbstractUser):
    """
    Abstract base class for all access.caltech-backed User models. Use this as the superclass for your app's custom
    User model, and it'll work with AccessCaltechAutoUserBackend and AccessCaltechUserMiddleware.
    """

    fullname = models.CharField(max_length=256)

    class Meta:
        abstract = True

    def get_full_name(self):
        """
        Overrides AbstractUser's get_full_name(), which normally concatenates first_name and last_name.
        """
        return self.fullname
