class QueryStringKwargsMixin:

    """
    Extract keys and values from our query string and pass them into
    self.dispatch() as extra kwargs.   This so that we can use query args as
    parameters for our views instead of having to use URL parts.

    This is important for CIT_AUTH, because the URLs in CAPAuthorizationURL
    cannot have variable parts.
    """

    def dispatch(self, request, *args, **kwargs):
        for k, v in request.GET.items():
            self.kwargs[k] = v
        return super().dispatch(request, *args, **kwargs)


class RestQueryStringKwargsMixin:

    """
    Django REST framework saves self.kwargs for the first time in
    dispatch(), while Django saves self.kwargs in as_view(), so
    we need a slightly different mixin for Django REST Framework
    based views.
    """

    def dispatch(self, request, *args, **kwargs):
        for k, v in request.GET.items():
            kwargs[k] = v
        return super().dispatch(request, *args, **kwargs)
