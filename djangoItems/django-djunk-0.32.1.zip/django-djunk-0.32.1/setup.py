#!/usr/bin/env python
from djunk import __version__
from setuptools import setup, find_packages

setup(
    name='django-djunk',
    version=__version__,
    description='Django Djunk - General-use django enhancements.',
    long_description=open('README.md', 'rt').read(),
    author="IMSS ADS",
    author_email="imss-ads-staff@caltech.edu",
    url='https://bitbucket.org/caltech-imss-ads/django-djunk',
    packages=find_packages(exclude=['bin']),
    include_package_data=True,
    install_requires=[
        "six",
        "structlog",
        "django-crequest",
        "unidecode"
    ]
)
