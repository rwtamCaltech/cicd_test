# django-djunk #

This repo contains various generalized plugins and classes for use in our django projects.
Currently, this includes:


`DjangoSysLogHandler` - This is an enhanced version of the python built-in `SysLogHandler` that adds additiona
functionality that helps improve the syslog output of the projects. It is especially helpful for logging tracebacks.
Install this handler by adding a LOGGING array like this one to `common.py`:

```
# Syslogs all errors. Sends email to the site admins on error when DEBUG=False.
from djunk.logging_handlers import DjangoSysLogHandler
import sys
if sys.platform == 'darwin':
    syslog_file = '/var/run/syslog'
elif sys.platform in ['linux2', 'linux']:
    syslog_file = '/dev/log'
else:
    syslog_file = ''

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        }
    },
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'filters': ['require_debug_false'],
            'class': 'django.utils.log.AdminEmailHandler'
        },
        'console':{
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
        },
        'syslog': {
            'level': 'INFO',
            'class': 'djunk.logging_handlers.DjangoSysLogHandler',
            'formatter': 'syslog_fmt',
            'facility': DjangoSysLogHandler.LOG_LOCAL0,
            'address': syslog_file,
        },
        'null': {
            'level': 'DEBUG',
            'class': 'django.utils.log.NullHandler',
        },
    },
    'loggers': {
        '': {
            # Set up the root logger to print to syslog using our DjangoSysLogHandler class.
            'handlers': ['syslog'],
            'level': 'INFO',
        },
        'django.request': {
            # Configure the 'django.request' logger to email the admins about 500 errors, and also propogate the errors
            # to the root logger.
            'handlers': ['mail_admins'],
            'level': 'ERROR',
            'propagate': True,
        },
        'django.security.DisallowedHost': {
            # Don't log attempts to access the site with a spoofed HTTP-HOST header. It massively clutters the logs,
            # and we really don't care about this error.
            'handlers': ['null'],
            'propagate': False,
        },
    },
    'formatters': {
        'syslog_fmt': {
            'format': '%(levelname)s %(name)s: %(message)s'
        },
    },
}
```


`GlobalRequestMiddleware` - A middleware that makes the current `request` object available from any context,
through the global `get_current_request()` function. Install this middleware by adding
'djunk.middleware.GlobalRequestMiddleware' to the `MIDDLEWARE_CLASSES` array in `common.py`.


`djunk/messages.tpl` - Include this template in the part of the page where you want flash messages to appear.
django_bootstrap has the CSS rules (`ul.messages`) to theme these messages consistently with our other django sites.


`manage.py` commands - The `dump_database` and `load_database` manage.py commands are included here. To use these
commands, you must define `settings.DB_DUMP_APPS` as an array of strings much like `settings.INSTALLED_APPS`. The
contents of the array should be the list of apps whose models you want to export with `dump_database`. The export will
be done to the `db_dump.json` file in the current working directory, so you should add that to .gitignore.


`djunk.context_processors.add_DEBUG_to_templates` - Add this to your `TEMPLATE_CONTEXT_PROCESSORS` list to give your
templates access to the `DEBUG` setting.


Javascript: django-djunk includes a copy of jquery and modernizer. Add them to your `base.html` template using:

`<script src="{% static 'djunk/js/modernizr-2.6.2.min.js' %}"></script>` in `<head>`, and
```
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
  <script>
    window.jQuery || document.write("<script src=\"{% static 'djunk/js/jquery-1.9.1.min.js' %}\"><\/script>")
  </script>
```
after the page content markup.


# Restricting access by IP address

## Middleware

A common request is to restrict certain content to access from the
Caltech / JPL networks. The OnCampusMiddleware will set
request.session['ON_CAMPUS'] to true if the request was made from a
campus IP address OR the user was logged in. To make this information
available in your application, add OnCampusMiddleware to
MIDDLEWARE in your Django settings file.

```
#!python
MIDDLEWARE = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'djunk.middleware.OnCampusMiddleware',
)
```

To use it, you may either query request.session['ON_CAMPUS'] and act
accordingly. If you want to restrict access to a view, there is a
convenient dectorator `restrict_to_campus`. For example:

```
#!python
from djunk.decorators import restrict_to_campus

@restrict_to_campus
def sekret_stuff(request)
    # get some secrets
    return render(request, 'foo/sekrets.tpl', {'shhhh': secrets})

```
