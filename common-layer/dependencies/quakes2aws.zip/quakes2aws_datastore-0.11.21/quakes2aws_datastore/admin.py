from django.contrib import admin


class DatastoreAdminSite(admin.AdminSite):

    site_header = 'Quakes2AWS: Datastore'
    site_title = 'Quakes2AWS: Datastore Admin'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.custom_views = []

    def regsiter_view(self, path):
        self.custom_views.append(path)

    def get_urls(self):
        urls = super().get_urls()
        urls.extend(self.custom_views)
        return urls
