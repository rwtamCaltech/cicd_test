from django.db import migrations


def apply_migration(apps, schema_editor):
    db_alias = schema_editor.connection.alias
    Group = apps.get_model("auth", "Group")
    Group.objects.using(db_alias).bulk_create(
        [Group(name="API Users")]
    )
    api_users_group = Group.objects.using(db_alias).get(name="API Users")
    User = apps.get_model("users", "User")
    users = User.objects.filter(username__startswith="api-")
    api_users_group.user_set.add(*users)


def revert_migration(apps, schema_editor):
    Group = apps.get_model("auth", "Group")
    Group.objects.filter(name="API Users").delete()


class Migration(migrations.Migration):
    dependencies = [('users', '0001_initial')]
    operations = [migrations.RunPython(apply_migration, revert_migration)]
