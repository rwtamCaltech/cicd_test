from django.apps import AppConfig


class UsersConfig(AppConfig):
    name = 'quakes2aws_datastore.users'
    label = 'users'
