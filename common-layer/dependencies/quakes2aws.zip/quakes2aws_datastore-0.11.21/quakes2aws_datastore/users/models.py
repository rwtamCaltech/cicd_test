from django.contrib.auth.models import AbstractUser, Group, UserManager
from django.db.models.signals import post_save
from django.dispatch import receiver

from rest_framework.authtoken.models import Token


class User(AbstractUser):
    """
    We don't need anything that isn't provided by AbstractUser, but we do need to define the Meta class, since those
    don't get inherited from model superclasses.
    """

    class Meta:
        verbose_name = 'user'
        verbose_name_plural = 'users'


# ------------------------------------
# Proxy models for Django Admin
# ------------------------------------

# API-only users
# -----------------------

class APIUserManager(UserManager):

    def get_queryset(self):
        return User.objects.filter(groups__name='API Users')


class APIUser(User):
    """
    These are API specific users -- they get no access to the django admin console, and they have API tokens.
    """

    objects = APIUserManager()

    def clean(self):
        if not self.username.startswith('api-'):
            self.username = "api-" + self.username

    class Meta:
        proxy = True
        verbose_name = 'API User'
        verbose_name_plural = 'API Users'


@receiver(post_save, sender=APIUser)
def finalize_api_user(sender, instance, created, **kwargs):
    if created:
        g = Group.objects.get(name='API Users')
        g.user_set.add(instance)
        Token.objects.get_or_create(user=instance)


# Admin site only users
# -----------------------

class AdminSiteUserManager(UserManager):

    def get_queryset(self):
        return User.objects.filter(groups__name='Admin Site Users')


class AdminSiteUser(User):
    """
    These are API specific users -- they get no access to the django admin console, and they have API tokens.
    """

    objects = AdminSiteUserManager()

    class Meta:
        proxy = True
        verbose_name = 'Admin Site User'
        verbose_name_plural = 'Admin Site Users'
