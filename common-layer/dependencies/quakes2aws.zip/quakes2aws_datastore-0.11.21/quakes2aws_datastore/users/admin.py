from django.contrib import admin
from rest_framework.authtoken.models import Token

from .models import AdminSiteUser, APIUser


class APIUserAdmin(admin.ModelAdmin):

    view_on_site = False
    ordering = ['username']
    list_select_related = ('auth_token',)
    list_display = [
        'username',
        'first_name',
        'last_name',
        'email',
        'auth_token'
    ]
    readonly_fields = [
        'view_auth_token'
    ]
    fields = (
        'username',
        'view_auth_token',
        ('first_name', 'last_name'),
        'email',
    )
    actions = ['regenerate_tokens']

    def view_auth_token(self, obj):
        return str(obj.auth_token)
    view_auth_token.empty_value_display = "-- no token --"
    view_auth_token.short_description = "API Token"

    def regenerate_tokens(self, request, queryset):
        users = queryset.all()
        Token.objects.filter(user__in=users).delete()
        for user in users:
            Token.objects.get_or_create(user=user)
        if len(users) == 1:
            message_bit = "1 token was"
        else:
            message_bit = "{} tokens were".format(len(users))
        self.message_user(request, "{} successfully regenerated.".format(message_bit))


class AdminSiteUserAdmin(admin.ModelAdmin):

    view_on_site = False
    ordering = ['username']
    list_display = [
        'username',
        'first_name',
        'last_name',
        'email',
        'last_login',
    ]
    fields = (
        'username',
        ('first_name', 'last_name'),
        'email',
    )


admin.site.register(APIUser, APIUserAdmin)
admin.site.register(AdminSiteUser, AdminSiteUserAdmin)
