import os
import sys
import json
import traceback
import pandas as pd
import torch
import obspy.core as oc
import numpy as np
import traceback

#all paths are relative to components/datastore
from model_processor.model_utils import model_utilities
from event_processor.event_utils import model_predictor
from datetime import datetime

# import quakes2aws_datastore.s3 as s3
from contexttimer import Timer
from quakes2aws_datastore.logging import logger



# def setup_for_prediction(query_df,samprate,starting_format, params, model, device, result_queue): #we take in the samprate as 100
def setup_for_prediction(query_df,samprate,starting_format, result_queue): #we take in the samprate as 100
    list_dict_picks=[]
    random_num=np.random.randint(5)

    try:
        #Attributes we need to set up the model
        overlap_frac = 1.00

        gpd_config_file='gpd_PS.json' #put in the components/datastore path

        #Model-related items: setting parameters, loading model
        with open(gpd_config_file, "r") as f:
            params = json.load(f)

        with Timer() as load_model_time:
            device = torch.device("cpu")
            model = model_utilities().load_trained_model(params['model_file'], device)

        n_win = int(params['half_dur']/params['delta'])
        n_feat = 2*n_win
        n_shift = int(overlap_frac * n_feat)

        # model_class = model_predictor(n_feat,n_shift,model,device,output_file,params)
        event_class = model_predictor(n_feat,n_shift,model,device,params)

        #Creates folder in quakes2aws/components/datastore path
        if not os.path.exists('GPD_PickLog'):
            os.makedirs('GPD_PickLog')
        
        #Creates folder in quakes2aws/components/datastore path
        if not os.path.exists('GPD_Visualizations'):
            os.makedirs('GPD_Visualizations')

        now = datetime.now() # current date and time
        time_str = now.strftime("%Y_%m_%d")
        output_file='GPD_PickLog/'+time_str+'_GPDpicksFound.txt'

        df_candidates_two = query_df[['station','network','channel']].drop_duplicates()

        #also set up a stream that stacks up the concat'd data we retrieve, so we can predict on it
        stream = oc.Stream()
        trace_channel_list=[]

        with Timer() as construct_stream_time:
            for _, row in df_candidates_two.iterrows():
                df_specificchannels=query_df[(query_df['station']==row['station']) & (query_df['network']==row['network']) & (query_df['channel']==row['channel'])]
                '''
                This is the sort of data we have (we iterate across 16-17 seconds of data depending for one specific channel)
                quakes2aws-datastore    |       station network channel        startt
                quakes2aws-datastore    | 631       RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 6372      RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 12434     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 18500     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 24536     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 30596     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 36811     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 42122     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 47830     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 53545     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 59252     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 64956     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 70651     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 76379     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 82071     RHR      CI     HHE  1.624435e+09
                quakes2aws-datastore    | 88159     RHR      CI     HHE  1.624435e+09
                '''

                starttime=min(df_specificchannels['startt'].tolist())
                endtime=max(df_specificchannels['endt'].tolist())

                stacked_data=[]
                for _, row in df_specificchannels.iterrows():
                    # data_used=json.loads(row['data']) #otherwise just a string, now a list
                    data_used=row['data'] #apparently already a list
                    stacked_data.extend(data_used) #add the data to the list

                # print(len(stacked_data)) #should be 300 if we are doing 4 seconds(we can add a try/except if it is not--should not process otherwise). We'll fix a few things here
                data_channels=np.array(stacked_data)

                #from inferTwo.py, line 191
                #https://docs.obspy.org/packages/autogen/obspy.core.trace.Trace.html (trace takes dict of header fields)
                header = {
                    'sampling_rate': samprate,
                    'delta': 1.0 / samprate,
                    'starttime': oc.utcdatetime.UTCDateTime(starttime),
                    'endtime': oc.utcdatetime.UTCDateTime(endtime),
                    'channel': df_specificchannels.iloc[0]['channel'] #should all be the same channel, take the first one
                }
                trace = oc.Trace(data=data_channels, header=header)
                # print(trace.stats.channel) #will print HHE, HHN and HHZ. 
                trace_channel_list.append(trace.stats.channel)
                stream.append(trace)

        keycode=df_specificchannels.iloc[0]['station']+'.'+df_specificchannels.iloc[0]['network']+'.'+df_specificchannels.iloc[0]['channel'][:-1]

        with Timer() as preprocess_predict_time:
            prediction_items=event_class.predict(stream,trace_channel_list,keycode,output_file,starting_format,random_num)
        
        construct_stream_time_elapsed=round(construct_stream_time.elapsed,3)
        preprocess_predict_time_elapsed=round(preprocess_predict_time.elapsed,3)

        if prediction_items!=0: #found predictions
            with Timer() as find_picks_time:
                list_dict_picks=event_class.retrieve_picks(prediction_items,keycode)
            
            find_picks_time_elapsed=round(find_picks_time.elapsed,3)

            if random_num>=4:
                logger.info(
                    'prediction.subset.results',
                    construct_stream_time=construct_stream_time_elapsed,
                    preprocess_predict_time=preprocess_predict_time_elapsed
                )

            #BELOW WORKS FOR VALIDATION, But use only for validation purposes, otherwise slows it down
            # prediction_items=event_class.generate_visualizations(prediction_items,keycode)

        result_queue.put([list_dict_picks])
        # return list_dict_picks
    except Exception as e:
        print("Setup for prediction error encountered")
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_exception(exc_type, exc_value, exc_traceback,
                                limit=2, file=sys.stdout)
        result_queue.put([list_dict_picks])
        # return list_dict_picks

