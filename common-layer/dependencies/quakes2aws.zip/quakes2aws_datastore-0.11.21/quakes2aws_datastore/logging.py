from six import string_types

import structlog
try:
    import colorama
except ImportError:
    colorama = None

logger = structlog.get_logger('quakes2aws::datastore')


def request_context_logging_processor(_, __, event_dict):
    """
    Adds extra runtime event info to our log messages based on the current request.

      ``username``: (string) the username of the logged in user, if user is logged in.
      ``site``: (string) the hostname of the current Site. Logs as 'celery/manage.py' when there's no current request.
      ``remote_ip``: the REMOTE_ADDR address. django-xff will handle properly setting this if we're behind a proxy
      ``superuser``: True if the current User is a superuser

    Does not overwrite any event info that's already been set in the logging call.
    """
    # This is imported here to avoid a circular import which is triggered during the docker image build by the
    # imports in middleware.py
    from djunk.middleware import get_current_request
    request = get_current_request()

    if request is not None:
        try:
            # django-xff will set this appropriately to the actual client IP when
            # we are behind a proxy
            client_ip = request.META['REMOTE_ADDR']
        except AttributeError:
            # Sometimes there will be a current request, but it's not a real request (during tests). If we can't get
            # the real client ip, just use a placeholder.
            client_ip = 'fake IP'
        event_dict.setdefault('remote_ip', client_ip)
        event_dict.setdefault('username', request.user.username or 'AnonymousUser')
        event_dict.setdefault('superuser', request.user.is_superuser)
    return event_dict


def censor_password_processor(_, __, event_dict):
    """
    Automatically censors any logging context key called "password", "password1", or "password2".
    """
    for password_key_name in ('password', 'password1', 'password2'):
        if password_key_name in event_dict:
            event_dict[password_key_name] = '*CENSORED*'
    return event_dict


def log_compat(obj):
    """
    Convert the given object to a string that's compatible with the logger output.
    """
    # If obj isn't already a string, convert it to one.
    if not isinstance(obj, string_types):
        obj = repr(obj)
    return obj
