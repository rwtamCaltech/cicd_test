from rest_framework_expandable.fields import ExpandableHyperlinkedRelatedField
from quakes2aws_datastore.core.models import (
    Channel,
    Instrument,
    Station,
)


class InstrumentRelatedField(ExpandableHyperlinkedRelatedField):
    queryset = Instrument.objects.all()
    lookup_field = 'pk'
    view_name = 'api:instrument-detail'
    expand_settings = {
        'comparison_fields': ['id'],
        'serializers': [
            {
                'paths': [
                    'station.instruments',
                    'channel.instrument'
                ],
                'serializer': 'quakes2aws.api.serializers.InstrumentSerializer',
            }
        ]
    }


class StationRelatedField(ExpandableHyperlinkedRelatedField):
    queryset = Station.objects.all()
    lookup_field = 'pk'
    view_name = 'api:station-detail'
    expand_settings = {
        'comparison_fields': ['id'],
        'serializers': [
            {
                'paths': [
                    'instrument.station',
                    'channel.instrument.station'
                ],
                'serializer': 'quakes2aws.api.serializers.StationSerializer',
            }
        ]
    }


class ChannelRelatedField(ExpandableHyperlinkedRelatedField):
    queryset = Channel.objects.all()
    lookup_field = 'pk'
    view_name = 'api:channel-detail'
    expand_settings = {
        'comparison_fields': ['id'],
        'serializers': [
            {
                'paths': [
                    'instrument.channels',
                ],
                'serializer': 'quakes2aws.api.serializers.ChannelSerializer',
            }
        ]
    }
