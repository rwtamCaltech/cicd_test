from django.urls import include, path
from rest_framework import routers

from .views import (
    ChannelViewSet,
    InstrumentViewSet,
    StationViewSet,
    SnapshotView,
)

# These URLs are loaded by exeter_api/urls.py.
app_name = 'api'
router = routers.DefaultRouter()

router.register(r'stations', StationViewSet)
router.register(r'instruments', InstrumentViewSet)
router.register(r'channels', ChannelViewSet)

# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.
urlpatterns = [
    path('', include(router.urls)),
    path('snapshots/', SnapshotView.as_view())
]
