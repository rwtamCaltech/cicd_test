import json
import re

from contexttimer import Timer
from django_filters import rest_framework as filters
from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_extensions.cache.mixins import CacheResponseMixin


from quakes2aws_datastore.core.models import (
    Channel,
    Instrument,
    Station
)
from quakes2aws_datastore.logging import logger

from .serializers import (
    StationSerializer,
    InstrumentSerializer,
    ChannelSerializer,
    SnapshotSerializer
)


def simple_params(query_params):
    params = {}
    for k, v in query_params.items():
        if isinstance(v, list):
            params[k] = ','.join(v)
        else:
            params[k] = v
    return params


class ApiLoggerMixin:

    def retrieve(self, request, *args, **kwargs):
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
        pk = self.kwargs[lookup_url_kwarg]
        view_name = re.sub(' ', ':', self.get_view_name()).lower()
        query_params = getattr(self.request, "query_params", getattr(self.request, "GET", {}))
        params = simple_params(query_params)
        logger.info(
            view_name,
            pk=pk,
            **params
        )
        return super().retrieve(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        view_name = re.sub(' ', ':', self.get_view_name()).lower()
        query_params = getattr(self.request, "query_params", getattr(self.request, "GET", {}))
        params = simple_params(query_params)
        logger.info(
            view_name,
            **params
        )
        return super().list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        view_name = re.sub(' ', ':', self.get_view_name()).lower()
        logger.info(view_name)
        return super().post(request, *args, **kwargs)


# ---------------
# Station
# ---------------

class StationFilter(filters.FilterSet):
    station = filters.CharFilter(field_name='station', lookup_expr='iexact')
    network = filters.CharFilter(field_name='network', lookup_expr='iexact')
    location = filters.CharFilter(field_name='location', lookup_expr='iexact')
    station_id = filters.CharFilter(field_name='station_id', lookup_expr='icontains')
    instrument_id = filters.CharFilter(field_name='instruments__instrument_id', lookup_expr='iexact', distinct=True)
    samprate = filters.NumberFilter(field_name='instruments__samprate', lookup_expr='exact', distinct=True)

    class Meta:
        model = Station
        fields = [
            'station',
            'network',
            'location',
            'station_id',
            'instrument_id',
            'samprate',
        ]


class StationViewSet(ApiLoggerMixin, CacheResponseMixin, viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = StationSerializer
    queryset = Station.objects.all()
    filterset_class = StationFilter


# ---------------
# Instrument
# ---------------

class InstrumentFilter(filters.FilterSet):
    station = filters.CharFilter(field_name='station__station', lookup_expr='iexact')
    network = filters.CharFilter(field_name='station__network', lookup_expr='iexact')
    location = filters.CharFilter(field_name='station__location', lookup_expr='iexact')
    station_id = filters.CharFilter(field_name='station__station_id', lookup_expr='icontains')
    instrument_id = filters.CharFilter(field_name='instrument_id', lookup_expr='iexact', distinct=True)
    samprate = filters.NumberFilter(field_name='samprate', lookup_expr='exact', distinct=True)

    class Meta:
        model = Instrument
        fields = [
            'station',
            'network',
            'location',
            'station_id',
            'instrument_id',
            'samprate',
        ]


class InstrumentViewSet(ApiLoggerMixin, CacheResponseMixin, viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = InstrumentSerializer
    queryset = Instrument.objects.all()
    filterset_class = InstrumentFilter


# ---------------
# Channel
# ---------------

class ChannelFilter(filters.FilterSet):
    channel_id = filters.CharFilter(field_name='channel_id', lookup_expr='iexact')
    station = filters.CharFilter(field_name='instrument__station__station', lookup_expr='iexact')
    network = filters.CharFilter(field_name='instrument__station__network', lookup_expr='iexact')
    location = filters.CharFilter(field_name='instrument__station__location', lookup_expr='iexact')
    station_id = filters.CharFilter(field_name='instrument__station__station_id', lookup_expr='icontains')
    instrument_id = filters.CharFilter(field_name='instrument__instrument_id', lookup_expr='iexact', distinct=True)
    samprate = filters.NumberFilter(field_name='instrument__samprate', lookup_expr='exact', distinct=True)

    class Meta:
        model = Channel
        fields = [
            'channel_id',
            'station',
            'network',
            'location',
            'station_id',
            'instrument_id',
            'samprate',
        ]


class ChannelViewSet(ApiLoggerMixin, CacheResponseMixin, viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ChannelSerializer
    queryset = Channel.objects.all()
    filterset_class = ChannelFilter


# ---------------
# Snapshot
# ---------------

class SnapshotView(ApiLoggerMixin, APIView):
    """
    This is the view used to submit pick jobs.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, format=None):
        # CPM: seems like I should not have to do this
        data = request.data
        if isinstance(request.data, str):
            data = json.loads(request.data)
        serializer = SnapshotSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
        else:
            logger.error("api.snapshot.create.deserialize.failed", errors=serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        return Response(status=status.HTTP_202_ACCEPTED)
