import datetime

from django.db import transaction

from contexttimer import Timer
import pytz
from rest_framework_expandable.serializers import ExpandableHyperlinkedModelSerializer
from rest_framework_helpers.mixins import SkippedFieldsMixin
from rest_framework import serializers

from quakes2aws_datastore.logging import logger
from quakes2aws_datastore.core.models import (
    Channel,
    Instrument,
    Station,
    SampleSet,
    ChannelDirectory
)

from .fields import (
    ChannelRelatedField,
    InstrumentRelatedField,
    StationRelatedField
)


class StationSerializer(SkippedFieldsMixin, ExpandableHyperlinkedModelSerializer):

    instruments = InstrumentRelatedField(many=True)

    class Meta:
        model = Station
        fields = (
            'url',
            'id',
            'station_id',
            'station',
            'network',
            'location',
            'latitude',
            'longitude',
            'elevation',
            'created_at',
            'last_seen_at',
        )
        extra_kwargs = {
            'url': {'view_name': 'api:station-detail', 'lookup_field': 'pk'}
        }


class InstrumentSerializer(SkippedFieldsMixin, ExpandableHyperlinkedModelSerializer):

    station = StationRelatedField(many=True)
    channels = ChannelRelatedField(many=True)

    class Meta:
        model = Instrument
        fields = (
            'url',
            'id',
            'instrument_id',
            'samprate',
            'created_at',
        )
        extra_kwargs = {
            'url': {'view_name': 'api:station-detail', 'lookup_field': 'pk'}
        }


class ChannelSerializer(SkippedFieldsMixin, ExpandableHyperlinkedModelSerializer):

    instrument = InstrumentRelatedField(many=True)

    class Meta:
        model = Channel
        fields = (
            'url',
            'id',
            'channel_id'
        )
        extra_kwargs = {
            'url': {'view_name': 'api:channel-detail', 'lookup_field': 'pk'}
        }


class SnapshotSampleSetSerializer(serializers.Serializer):
    """
    Expected structure::

        {
            'endttime': 1564769785.958393,
            'starttime': 1564769784.968393,
            'samples': [-195, -190, ... -87],
        }
    """

    starttime = serializers.FloatField()
    endtime = serializers.FloatField()
    samples = serializers.ListField(
        child=serializers.IntegerField()
    )


class SnapshotChannelSerializer(serializers.Serializer):
    """
    Expected structure::

        {
            'channel_id': 'HHE',
            'sets': [
                {
                    'endttime': 1564769785.958393,
                    'starttime': 1564769784.968393,
                    'nsamples': 100,
                    'samples': [-195, -190, ... -87],
                },

                [...]
            ]
        }
    """
    channel_id = serializers.CharField(max_length=4)
    sets = SnapshotSampleSetSerializer(many=True)


class SnapshotInstrumentSerializer(serializers.Serializer):
    """
    Expected structure::

        {
            'instrument_id': 'HH',
            'samprate': 100.0,
            'channels': [
                {
                    'channel_id': 'HHE',
                    'sets': [
                        [...]
                    ]
                },
                [...]
            ]
        }
    """
    instrument_id = serializers.CharField(max_length=3)
    samprate = serializers.FloatField()
    channels = SnapshotChannelSerializer(many=True)


class SnapshotStationSerializer(serializers.Serializer):
    """
    Expected structure::

        {
            'station_id': 'STA.NET.LOC',
            'instruments': [
                {
                    'instrument_id': 'HH',
                    'samprate': 100.0,
                    'starttime': 1564769784.968393,
                    'endtime': 1564769785.958393,
                    'channels': [
                        [...]
                    ]
                },
                [...]
            ]
        }
    """
    station_id = serializers.CharField(max_length=30)
    instruments = SnapshotInstrumentSerializer(many=True)


class SnapshotSerializer(serializers.Serializer):
    """
    Expected structure::

        {
            'timestamp': 1564769784.968393,
            'stations': [
                {
                    'station_id': 'STA.NET.LOC',
                    'instruments': [
                        {
                            'instrument_id': 'HH',
                            'samprate': 100.0,
                            'channels': [
                                {
                                    'channel_id': 'HHE',
                                    'sets': [
                                        {
                                            'endttime': 1564769785.958393,
                                            'starttime': 1564769784.968393,
                                            'samples': [-195, -190, ... -87],
                                        },

                                        [...]
                                    ]
                                },
                                {
                                    'channel_id': 'HHN',
                                    [...]
                                },
                                {
                                    'channel_id': 'HHZ',
                                    [...]
                                },
                            ]
                    ]
            ]
        }
    """

    timestamp = serializers.FloatField()
    stations = SnapshotStationSerializer(many=True)

    def save(self):
        station_ids = []
        sets = []
        n_channels = 0
        n_instruments = 0
        channel_directory = ChannelDirectory()
        with Timer() as load_time:
            for sta in self.validated_data['stations']:
                station_ids.append(sta['station_id'])
                for inst in sta['instruments']:
                    n_instruments += 1
                    for cha in inst['channels']:
                        chan_id = channel_directory.get(
                            sta['station_id'],
                            inst['instrument_id'],
                            cha['channel_id'],
                            inst['samprate']
                        )
                        n_channels += 1
                        for s in cha['sets']:
                            sampset = SampleSet()
                            sampset.channel_id = chan_id
                            sampset.channel_name = cha['channel_id']
                            sampset.instrument_name = f"{sta['station_id']}.{inst['instrument_id']}"
                            sampset.starttime = s['starttime']
                            sampset.endtime = s['endtime']
                            sampset.samprate = inst['samprate']
                            sampset.samples = s['samples']
                            sampset.nsamples = len(s['samples'])
                            sets.append(sampset)
        with Timer() as station_update_time:
            last_seen_at = datetime.datetime.fromtimestamp(self.validated_data['timestamp'])
            last_seen_at = last_seen_at.astimezone(pytz.utc)
            with transaction.atomic():
                Station.objects.filter(station_id__in=station_ids).update(last_seen_at=last_seen_at)
        with Timer() as insert_sets_time:
            SampleSet.objects.bulk_create(sets)
        logger.info(
            'api.snapshot.save.timing',
            stations=len(station_ids),
            instruments=n_instruments,
            channels=n_channels,
            sets=len(sets),
            load=load_time.elapsed,
            station_update=station_update_time.elapsed,
            insert_sets=insert_sets_time.elapsed
        )
        return sets
