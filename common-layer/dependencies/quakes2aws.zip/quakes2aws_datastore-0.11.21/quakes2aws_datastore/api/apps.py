from django.apps import AppConfig


class ApiConfig(AppConfig):
    name = 'quakes2aws_datastore.api'
    label = 'api'
