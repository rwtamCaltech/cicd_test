import boto3
from django.conf import settings

s3_client = boto3.client('s3')

def upload_to_s3(src_path, dest_s3_key):
    """ 
    Uploads object to the designated S3 bucket specified in config.json.

    Parameters:
    src_path (string): Absolute path to the object you want to be uploaded to S3.
    bucket (string): Bucket name.
    dest_s3_key (string): Key of where the object will be uploaded to within the bucket.
    """
    bucket = settings.BUCKET_USED
    s3_client.upload_file(src_path, bucket, dest_s3_key)