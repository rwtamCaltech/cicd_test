from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0002_samples_v'),
    ]

    operations = [
        migrations.RunSQL(
            sql=[
                """
DROP VIEW samples_v;
CREATE VIEW seismic_data_v AS
SELECT
    ss.id AS sampleset_id,
    ss.starttime AS sampleset_starttime,
    ss.endtime AS sampleset_endtime,
    ss.channel_id AS channel_id,
    ss.instrument_name AS instrument_name,
    ch.instrument_id AS instrument_id,
    generate_series(0, ss.nsamples-1) as index,
    unnest(ss.samples) as sample,
    ss.starttime + (
      (
         generate_series(0, (ss.nsamples-1))::float4 / ((ss.nsamples)::float4 - 1)
      ) * (ss.endtime - ss.starttime)
    ) as timestamp
FROM sample_set ss
INNER JOIN channel ch on ss.channel_id=ch.id;
                """
            ],
            reverse_sql=[
                """
DROP VIEW seismic_data_v;
CREATE VIEW samples_v AS
SELECT
    ss.id as sampleset_id,
    ss.channel_id as channel_id,
    generate_series(0, ss.nsamples-1) as index,
    unnest(ss.samples) as sample,
    ss.starttime + (
      (
         generate_series(0, (ss.nsamples-1))::float4 / ((ss.nsamples)::float4 - 1)
      ) * (ss.endtime - ss.starttime)
    ) as timestamp
FROM sample_set ss;
                """
            ]
        )
    ]
