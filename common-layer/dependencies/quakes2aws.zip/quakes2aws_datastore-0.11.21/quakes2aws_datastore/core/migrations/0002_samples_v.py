from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.RunSQL(
            sql=[
                """
CREATE VIEW samples_v AS
SELECT
    ss.id as sampleset_id,
    ss.channel_id as channel_id,
    generate_series(0, ss.nsamples-1) as index,
    unnest(ss.samples) as sample,
    ss.starttime + (
      (
         generate_series(0, (ss.nsamples-1))::float4 / ((ss.nsamples)::float4 - 1)
      ) * (ss.endtime - ss.starttime)
    ) as timestamp
FROM sample_set ss;
                """
            ],
            reverse_sql=[
                """
DROP VIEW samples_v;
                """
            ]
        )
    ]
