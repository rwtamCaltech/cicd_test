from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0003_seismic_data_v'),
    ]

    operations = [
        migrations.RunSQL(
            sql=[
                """
CREATE VIEW timeshifted_sample_set_v AS
SELECT
    sso.id,
    sso.delay,
    sso.starttime AS starttime_orig,
    (sso.starttime + sso.delay) as starttime,
    sso.endtime AS endtime_orig,
    (sso.endtime + sso.delay) as endtime,
    sso.samples,
    sso.samprate,
    sso.channel_id,
    sso.nsamples,
    sso.channel_name,
    sso.instrument_name,
    sso.is_processed,
    sso.created_at
FROM (
    SELECT
        (extract(epoch from now()) - max(ss.endtime) over (partition by ss.channel_id)) as delay,
        ss.id,
        ss.starttime,
        ss.endtime,
        ss.samples,
        ss.samprate,
        ss.channel_id,
        ss.nsamples,
        ss.channel_name,
        ss.instrument_name,
        ss.is_processed,
        ss.created_at
    FROM sample_set AS ss
) as sso;
                """
            ],
            reverse_sql=[
                """
DROP VIEW timeshifted_sample_set_v;
                """
            ]
        )
    ]
