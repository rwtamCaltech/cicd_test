from datetime import datetime

from django.contrib import admin

import quakes2aws_datastore.admin  # noqa:F401
from .models import (
    Channel,
    Instrument,
    SampleSet,
    Station,
)


@admin.register(Station)
class StationAdmin(admin.ModelAdmin):

    list_display = (
        'station_id',
        'network',
        'location',
        'latitude',
        'longitude',
        'elevation',
        'num_instruments',
        'last_seen_at',
        'created_at',
    )
    ordering = ('station_id',)
    readonly_fields = ('station_id',)
    list_filter = ('network',)


@admin.register(Instrument)
class InstrumentAdmin(admin.ModelAdmin):

    def num_channels(self, obj):
        return obj.channels.count()
    num_channels.short_description = "Number of channels"

    def instrument_name(self, obj):
        return f"{obj.station.station_id}.{obj.instrument_id}"

    list_display = ('instrument_name', 'num_channels', 'starttime', 'endtime')
    ordering = ('station__station_id', 'instrument_id')
    readonly_fields = ('station', 'instrument_id')
    list_filter = ('station__network',)


@admin.register(Channel)
class ChannelAdmin(admin.ModelAdmin):

    list_display = ('channel_path', 'num_samples', 'starttime', 'endtime')
    list_select_related = ('instrument', 'instrument__station')
    ordering = ('instrument__station__station_id', 'instrument__instrument_id', 'channel_id',)
    readonly_fields = ('instrument', 'channel_id')
    list_filter = ('instrument__station__network',)


@admin.register(SampleSet)
class SampleSetAdmin(admin.ModelAdmin):

    def endtime_view(self, obj):
        return datetime.fromtimestamp(obj.endtime)
    endtime_view.short_description = "Endtime"

    def starttime_view(self, obj):
        return datetime.fromtimestamp(obj.starttime)
    starttime_view.short_description = "Starttime"

    def num_samples(self, obj):
        return obj.sample_sets.count()

    list_display = (
        'instrument_name',
        'channel_name',
        'samprate',
        'starttime_view',
        'endtime_view'
    )
    list_select_related = ('channel',)
    ordering = ('channel_id', 'starttime')
