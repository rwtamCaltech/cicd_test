from contexttimer import Timer

from django.apps import apps
from django.db import models, transaction
from django.utils import timezone
from django.contrib.postgres.fields import ArrayField

# from quakes2aws.utils.models import (
#     DataSnapshot as BaseDataSnapshot,
#     Instrument as BaseInstrument,
#     Station as BaseStation,
#     Channel as BaseChannel
# )


#THIS IS THE CORRECT models.py to use to ingest
#but it doesn't have the State (live) parameter defined. We need that to make preds continuously. 

# I have this as well (WE NEED TO USE THIS)
from quakes2aws_datastore.utils.models import (
    DataSnapshot as BaseDataSnapshot,
    Instrument as BaseInstrument,
    Station as BaseStation,
    Channel as BaseChannel,
)

# from quakes2aws.logging import logger
from quakes2aws_datastore.logging import logger




# --------------
# Django Managers
# --------------

class ChannelManager(models.Manager):

    def contiguous(self, starttime, seconds=16):
        Chan = apps.get_model('core', 'Channel')
        return (
            Chan.objects.filter(
                sample_sets__starttime__gte=starttime,
                sample_sets__endtime__lte=starttime + seconds + 0.5,
                instrument__samprate=100,
                channel_id__regex="[EH]H[ENZ]"
            ).annotate(nsets=models.Count('sample_sets'))
        ).filter(nsets__gte=seconds)


class SampleSetManager(models.Manager):

    def contiguous(self, starttime, seconds=16, samprate=100, channel_filter=None):
        if not channel_filter:
            channel_filter = "[EH]H[ENZ]"
        with Timer() as set_time:
            sets = SampleSet.objects.filter(
                starttime__gte=starttime,
                endtime__lte=starttime + seconds + 0.5,
                samprate=samprate,
                channel_name__regex=channel_filter
            )
        logger.info('sampleset.contiguous', set_time=set_time)
        return sets


class InstrumentManager(models.Manager):

    def pick_eligible(self):
        """
        Instruments eligible for the picker:

            * have 3 channels
            * have samprate of 100
            * Are either EH or HH
        """
        instruments = (Instrument.objects
            .annotate(channel_count=models.Count('channels'))
            .filter(
                channel_count=3,
                samprate=100,
                instrument_id_regex="[EH]H"
            )
        )
        return instruments


# --------------
# Django Models
# --------------

class Station(models.Model):

    last_tail_endtime = models.FloatField(
        'Last Tail Endtime',
        null=True,
        help_text='When we last did a tail, endtime of that tail was this.  We use this to detect late '
                  'arrriving packets; new packets with starttime before this timestamp will be '
                  'discarded.'
    )

    station_id = models.CharField(
        verbose_name='Station ID',
        max_length=15,
        unique=True,
        db_index=True
    )

    station = models.CharField(verbose_name='Station', max_length=10, null=True)
    network = models.CharField(verbose_name='Network', max_length=10, null=True)
    location = models.CharField(verbose_name='Location', max_length=10, null=True)

    latitude = models.FloatField(verbose_name="Latitude", null=True)
    longitude = models.FloatField(verbose_name="Latitude", null=True)
    elevation = models.FloatField(verbose_name="Elevation", null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    last_seen_at = models.DateTimeField(
        'Last Seen',
        help_text='The last time we received a sample for this station.',
        null=True
    )

    @property
    def instrument_ids(self):
        """
        Return a list of the names of all the channels we have.

        :rtype: list of strings
        """
        return [i.instrument_id for i in self.instruments.all().order_by('instrument_id')]

    @property
    def starttimes(self):
        """
        Return a dict of starttimes, where the keys are channel ids and the values are the startimes of the associated
        channel.
        """
        d = {}
        for i in self.instruments.all().order_by('instrument_id'):
            try:
                starttime = i.starttime
            except ValueError:
                starttime = None
            d[i.instrument_id] = starttime
        return d

    @property
    def starttime(self):
        """
        Return the starttime of the oldest sample across all our instruments.
        """
        starttimes = []
        for i in self.instrument.all():
            try:
                starttimes.append(i.starttime)
            except ValueError:
                pass
        if not starttimes:
            return None
        return min(starttimes)

    @property
    def endtimes(self):
        """
        Return a dict of endtimes, where the keys are instrument ids and the values are the endimes of the associated
        instrument.
        """
        d = {}
        for i in self.instruments.all().order_by('instrument_id'):
            try:
                endtime = i.endtime
            except ValueError:
                endtime = None
            d[i.instrument_id] = endtime
        return d

    @property
    def endtime(self):
        """
        Return the endtime of the newest sample across all our channels.
        """
        endtimes = []
        for i in self.instrument.all():
            try:
                endtimes.append(i.endtime)
            except ValueError:
                pass
        if not endtimes:
            return None
        return max(endtimes)

    @property
    def is_empty(self):
        return set(self.starttimes.values()) == set([None])

    def empty(self):
        """
        Purge data from all of our channels.
        """
        for instrument in self.instrument.all():
            instrument.empty()
        logger.info('station.empty.success', station_id=self.station_id)

    def num_instruments(self):
        return self.instruments.count()

    def trim(self):
        """
        Make all of our instrument channels start at the same time.

        .. note::

            I assume here that all channels on the same station have (a) the same samprate and
            (b) start recording sample sets simultaneously.

            The thing to check here is when a Station has 2 different sensors (big motion and normal, e.g.),
            do those two sensors operate in tandem?
        """
        max_starttime = max(self.starttimes.values())
        for i in self.instruments.all():
            i.trim(max_starttime)

    def is_complete(self, seconds):
        """
        Return True if all of our instruments have ``seconds`` worth of data.

        :param seconds float: (Optional) If not 0, return True if all channels start at the same time and all have
                              ``seconds`` worth of data

        :rtype: boolean
        """
        full_instruments = [i.is_complete(seconds) for i in self.instruments.all()].count(True)
        return full_instruments == self.num_instruments

    def tail(self, seconds, purge=False):
        """
        Return a new quakes2aws.utils.models.Station object containing the oldest ``seconds`` seconds worth of data from
        this station.

        Also update our ``self.last_tail_endtime`` with the endtime of the tail so that we can use it to later detect
        late-arriving samples.

        Raise ``ValueError`` if any of the stations doesn't have that much data.

        :param seconds float: return this many seconds worth of sample sets
        :param purge bool:  (Optional) if ``True``, remove the matching sample sets from the database.  Default:
                            ``False``.

        :rtype: quakes2aws.utils.models.Station
        """
        # FIXME: have an option to not wait until complete; just give me what you have now
        if not self.is_complete(seconds):
            raise ValueError('The oldest {} seconds of instrument data in {} is not complete'.format(repr(self)))
        tailed_station = BaseStation()
        tailed_station.station_id = self.station_id
        # FIXME: we're doing n_channels + 1 queries here.   Can we do it in one?
        for i in self.instruments.all():
            tailed_station.instruments[i.channel_id] = i.tail(seconds, purge=purge)
        # update the channel with the endtime of the tailed station
        self.last_tail_endtime = tailed_station.endtime
        self.save()
        return tailed_station

    def json(self):
        d = {}
        d['station_id'] = self.station_id
        d['station'] = self.station
        d['network'] = self.network
        d['location'] = self.location
        d['longitude'] = self.longitude
        d['latitude'] = self.latitude
        d['elevation'] = self.elevation
        d['created_at'] = self.created_at
        d['instruments'] = {}
        for i in self.instruments.all():
            d['instruments'][i.instrument_id] = i.json()
        return d

    class Meta:
        db_table = "station"
        verbose_name = "Station"
        verbose_name_plural = "Stations"
        ordering = ['station_id']


class Instrument(models.Model):

    instrument_id = models.CharField(
        verbose_name='Instrument ID',
        max_length=2,
        db_index=True
    )

    description = models.CharField(
        verbose_name='Instrument Description',
        max_length=256,
        db_index=True,
        null=True
    )

    station = models.ForeignKey(
        Station,
        verbose_name='Station',
        on_delete=models.CASCADE,
        null=True,
        help_text='The station to which this instrument belongs',
        related_name='instruments'
    )

    samprate = models.FloatField(
        verbose_name='Sampling Rate',
        help_text='Sampling rate in Hz for this instrument',
        editable=False,
        null=True
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def instrument_path(self):
        return f'{self.station.station_id}.{self.instrument_id}'

    @property
    def channel_ids(self):
        """
        Return a list of the names of all the channels we have.

        :rtype: list of strings
        """
        return [ch.channel_id for ch in self.channels.all().order_by('channel_id')]

    @property
    def starttimes(self):
        """
        Return a dict of starttimes, where the keys are channel ids and the values are the startimes of the associated
        channel.
        """
        d = {}
        for ch in self.channels.all().order_by('channel_id'):
            try:
                starttime = ch.starttime
            except ValueError:
                starttime = None
            d[ch.channel_id] = starttime
        return d

    @property
    def starttime(self):
        """
        Return the starttime of the oldest sample across all our channels.
        """
        starttimes = []
        for ch in self.channels.all():
            starttime = ch.starttime
            if starttime is not None:
                starttimes.append(starttime)
        if not starttimes:
            return 0
        return min(starttimes)

    @property
    def endtimes(self):
        """
        Return a dict of endtimes, where the keys are channel ids and the values are the endimes of the associated
        channel.
        """
        d = {}
        for ch in self.channels.all().order_by('channel_id'):
            try:
                endtime = ch.endtime
            except ValueError:
                endtime = None
            d[ch.channel_id] = endtime
        return d

    @property
    def endtime(self):
        """
        Return the endtime of the newest sample across all our channels.
        """
        endtimes = []
        for ch in self.channels.all():
            endtime = ch.endtime
            if endtime is not None:
                endtimes.append(ch.endtime)
        if not endtimes:
            return 0
        return max(endtimes)

    @property
    def is_empty(self):
        return set(self.starttimes.values()) == set([None])

    def empty(self):
        """
        Purge data from all of our channels.
        """
        for channel in self.channels.all():
            channel.empty()
        logger.info('station.empty.success', station_id=self.station_id)

    def num_channels(self):
        return self.channels.count()

    def is_complete(self, seconds):
        """
        Return True if at least half of our channels has ``seconds`` worth of data.   We do "at least half" to handle
        missing packets at the beginning or end of a few channels.

        If we have an empty station with 6 channels, and we gather data from the Kinesis stream but end up missing a
        starting or ending packet from one of the channels, we don't want that to prevent us from doing a tail().  A
        common way this might happen is if we're just starting up a stream with new data -- the front edge of that data
        may be ragged.

        :param seconds float: (Optional) If not 0, return True if all channels start at the same time and all have
                              ``seconds`` worth of data

        :rtype: boolean
        """
        full_channels = [c.duration >= seconds for c in self.channels.all()].count(True)
        return full_channels >= self.channels.count() / 2.0

    def trim(self):
        """
        Make all of our channels start at the same time.

        .. note::

            I assume here that all channels on the same instrument have (a) the same samprate and
            (b) start recording sample sets simultaneously.
        """
        max_starttime = max(self.starttimes.values())
        for ch in self.channels.all():
            ch.trim(max_starttime)

    def tail(self, seconds, purge=False):
        """
        Return a new quakes2aws.utils.models.Instrument object containing the oldest ``seconds`` seconds worth of data
        from this instrument.

        Raise ``ValueError`` if any of the channels doesn't have that much data.

        :param seconds float: return this many seconds worth of sample sets for each channel
        :param purge bool:  (Optional) if ``True``, remove the matching sample sets from the database.  Default:
                            ``False``.

        :rtype: quakes2aws.utils.models.Instrument
        """
        # FIXME: have an option to not wait until complete; just give me what you have now
        if not self.is_complete(seconds):
            raise ValueError('The oldest {} seconds of channel data in {} is not complete'.format(repr(self)))
        tailed_instrument = BaseInstrument()
        tailed_instrument.station_id = self.station_id
        tailed_instrument.instrument_id = self.instrument_id
        # FIXME: we're doing n_channels + 1 queries here.   Can we do it in one?
        for ch in self.channels.all():
            tailed_instrument.channels[ch.channel_id] = ch.tail(seconds, purge=purge)
        self.save()

    def json(self):
        d = {}
        d['station_id'] = self.station.station_id
        d['instrument_id'] = self.instrument_id
        d['description'] = self.description
        d['channels'] = {}
        for ch in self.channels.all():
            d['channels'][ch.channel_id] = ch.json()
        return d

    def __unicode__(self):
        return self.instrument_path

    class Meta:
        db_table = "instrument"
        verbose_name = "Instrument"
        verbose_name_plural = "Instruments"
        ordering = ['instrument_id']
        unique_together = ['station', 'instrument_id']
        index_together = [('station', 'instrument_id')]


class Channel(models.Model):

    objects = ChannelManager()

    channel_id = models.CharField(
        verbose_name='Channel ID',
        max_length=3,
        db_index=True
    )

    instrument = models.ForeignKey(
        Instrument,
        verbose_name='Instrument',
        on_delete=models.CASCADE,
        null=True,
        help_text='The instrument to which this channel belongs',
        related_name='channels'
    )

    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def num_samples(self):
        return self.sample_sets.count()

    @property
    def channel_path(self):
        return f'{self.instrument.station.station_id}.{self.instrument.instrument_id}.{self.channel_id}'

    @property
    def is_empty(self):
        return not self.sample_sets.exists()

    @property
    def starttime(self):
        if not self.is_empty:
            starttime = self.sample_sets.all().aggregate(models.Min('starttime'))['starttime__min']
        else:
            return None
        return starttime

    @property
    def endtime(self):
        if not self.is_empty:
            endtime = self.sample_sets.all().aggregate(models.Max('endtime'))['endtime__max']
        else:
            return None
        return endtime

    @property
    def duration(self):
        if not self.is_empty:
            bounds = self.sample_sets.all().aggregate(models.Min('starttime'), models.Max('endtime'))
        else:
            return None
        return bounds['endtime__max'] - bounds['starttime__min']

    def empty(self):
        """
        Purge all our sample_sets.
        """
        self.sample_sets.all().delete()

    def is_contiguous(self, seconds=0):
        """
        Return True if the sample sets in this channel are contiguous (no gaps), False otherwise.

        :param seconds float: if not 0, return True only if the oldest ``seconds`` worth of samples are contiguous.

        :rtype: boolean
        """
        if not self.is_empty:
            query = self.sample_sets
            if seconds:
                end = self.starttime + seconds + 0.5
                query = query.filter(endtime__lt=end)
            sorted_sets = query.order_by('starttime').values_list('starttime', 'endtime')
            diffs = []
            # compute the diff between the starttime of a set and the endtime of the previous set
            for i in range(1, len(sorted_sets)):
                diffs.append(sorted_sets[i][0] - sorted_sets[i - 1][1])
                if seconds:
                    if (sorted_sets[i][0] - sorted_sets[0][1]) >= seconds:
                        break
            # we have contiguous sample sets if the max of all the diffs is < 2.0 * our sampling rate
            return max(diffs) < (2.0 / float(self.sets[0]['samprate']))
        else:
            return True

    def trim(self, starttime=None):
        """
        Purge any of our sample sets that have starttime < ``starttime``.
        """
        self.sample_sets.filter(starttime__lt=starttime).delete()

    def tail(self, seconds, purge=False):
        """
        Return a ``quakes2aws.utils.models.Channel`` object of the oldest ``seconds`` worth of sample sets in this
        channel.

        If we don't have ``seconds`` seconds worth of data, raise ``ValueError``.

        :param seconds float: return this many seconds worth of sample sets
        :param purge bool:  (Optional) if ``True``, remove the matching sample sets from the database.  Default:
                            ``False``.

        :rtype: quakes2aws.utils.models.Channel
        """
        if self.is_empty or self.duration < seconds:
            logger.info(
                'channel.tail.not_complete',
                station_id=self.station.station_id,
                channel_id=self.channel_id,
                starttime=self.starttime,
                endtime=self.endtime,
                duration=self.duration,
                seconds=seconds
            )
            raise ValueError
        tailed_channel = BaseChannel(self.instrument.station.station_id, self.instrument_id)
        tailed_channel.channel_id = self.channel_id
        end = self.starttime + seconds + 0.5  # add half second fudge factor
        sets = self.sample_sets.filter(endtime__lt=end).order_by('starttime')
        for s in sets:
            tailed_channel.add_set(s.json())
        if purge:
            self.sample_sets.filter(endtime__lt=end).delete()
        return tailed_channel

    def __unicode__(self):
        return self.channel_id

    def json(self):
        d = {}
        d['station_id'] = self.instrument.station.station_id
        d['instrument_id'] = self.instrument.instrument_id
        d['channel_id'] = self.channel_id
        d['sets'] = [s.json() for s in self.sample_sets.all()]
        d['starttime'] = self.starttime
        d['endtime'] = self.endtime
        d['samprate'] = self.samprate
        return d

    class Meta:
        db_table = "channel"
        verbose_name = "Channel"
        verbose_name_plural = "Channels"
        ordering = ['channel_id']
        unique_together = ['instrument', 'channel_id']
        index_together = [('instrument', 'channel_id')]


class SampleSet(models.Model):

    objects = SampleSetManager()

    id = models.BigAutoField(primary_key=True)

    instrument_name = models.CharField(
        verbose_name='Instrument Name',
        max_length=36,
        null=True,
        db_index=True
    )

    channel_name = models.CharField(
        verbose_name='Channel Name',
        max_length=3,
        null=True,
        db_index=True
    )

    starttime = models.FloatField(
        verbose_name='Start Time',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False,
        db_index=True
    )

    endtime = models.FloatField(
        verbose_name='End Time',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False,
        db_index=True
    )

    samprate = models.FloatField(
        verbose_name='Sampling Rate',
        help_text='Sampling rate in Hz for this sample set',
        editable=False
    )

    samples = ArrayField(
        models.IntegerField(),
        verbose_name='Samples',
        help_text='List of integer samples stored as an integer array',
        editable=False
    )

    nsamples = models.IntegerField(
        verbose_name='Number of Samples',
        help_text='Number of samples stored in samples',
        editable=False
    )

    is_processed = models.BooleanField(
        verbose_name='Processed?',
        help_text='Has this sample set been processed by the picker?',
        default=False,
        editable=False
    )

    channel = models.ForeignKey(
        Channel,
        verbose_name='Channel',
        on_delete=models.CASCADE,
        null=True,
        help_text='The channel to which this sample set belongs',
        related_name='sample_sets'
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def json(self):
        return {
            'starttime': self.starttime,
            'endtime': self.endtime,
            'samprate': self.samprate,
            'samples': self.samples,
        }

    class Meta:
        db_table = "sample_set"
        verbose_name = "Sample Set"
        verbose_name_plural = "Sample Sets"
        ordering = ['starttime']
        index_together = [('starttime', 'endtime')]

    def __str__(self):
        return f'SampleSet(starttime={self.starttime}, endtime={self.endtime}, samprate={self.samprate})'


class TimeshiftedSampleSet(models.Model):

    objects = SampleSetManager()

    instrument_name = models.CharField(
        verbose_name='Instrument Name',
        max_length=36,
        null=True,
    )

    channel_name = models.CharField(
        verbose_name='Channel Name',
        max_length=3,
        null=True,
    )

    delay = models.FloatField(
        verbose_name='Delay (s)',
        help_text="Difference in seconds between this sample's endtime and now",
        editable=False
    )

    starttime_orig = models.FloatField(
        verbose_name='Start Time (unshifted)',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False
    )

    starttime = models.FloatField(
        verbose_name='Start Time (shifted)',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False
    )

    endtime_orig = models.FloatField(
        verbose_name='End Time (unshifted)',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False
    )

    endtime = models.FloatField(
        verbose_name='End Time (shifted)',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False
    )

    samprate = models.FloatField(
        verbose_name='Sampling Rate',
        help_text='Sampling rate in Hz for this sample set',
        editable=False
    )

    samples = ArrayField(
        models.IntegerField(),
        verbose_name='Samples',
        help_text='List of integer samples stored as an integer array',
        editable=False
    )

    nsamples = models.IntegerField(
        verbose_name='Number of Samples',
        help_text='Number of samples stored in samples',
        editable=False
    )

    is_processed = models.BooleanField(
        verbose_name='Processed?',
        help_text='Has this sample set been processed by the picker?',
        default=False,
        editable=False
    )

    channel = models.ForeignKey(
        Channel,
        verbose_name='Channel',
        on_delete=models.DO_NOTHING,
        null=True,
        help_text='The channel to which this sample set belongs',
        related_name='timeshifted_sample_sets'
    )

    created_at = models.DateTimeField()

    class Meta:
        db_table = "timeshifted_sample_set_v"
        verbose_name = "Timeshifted Sample Set"
        verbose_name_plural = "Timeshifted Sample Sets"
        ordering = ['starttime']
        managed = False

    def __str__(self):
        return f'SampleSet(starttime={self.starttime}, endtime={self.endtime}, samprate={self.samprate})'


# class State:

#     #I added this just to see what if it responds. 
#     def __init__(self, live=True):
#         if live:
#             self.model = TimeshiftedSampleSet
#         else:
#             self.model = SampleSet

#     @property
#     def stations(self):
#         return Station.objects.all().order_by('station_id')

#     @property
#     def networks(self):
#         return sorted(list(Station.objects.order_by().values_list('network', flat=True).distinct()))

#     @property
#     def station_ids(self):
#         return [sta.station_id for sta in self.stations]

#     @property
#     def is_empty(self):
#         return not SampleSet.objects.exists()

#     @property
#     def starttime(self):
#         """
#         Return the starttime of the earliest sample set we have, in epoch seconds.

#         :rtype: float
#         """
#         if not self.is_empty:
#             return TimeshiftedSampleSet.objects.aggregate(models.Min('starttime'))['starttime__min']
#         else:
#             return None

#     @property
#     def starttimes(self):
#         """
#         Return a dict of ``{ station_id: startime }`` for all stations, where ``starttime``
#         is the starttime of the earliest sample set in that station.

#         :rtype: dict(str) -> float
#         """

#         if not self.is_empty:
#             data = (
#                 Station.objects.values('station_id', 'instruments__instrument_id')
#                                .annotate(starttime=models.Min('instruments__channels__timeshifted_sample_sets__starttime'))
#                                .order_by('station_id')
#             )
#             return {d['station_id']: d['starttime'] for d in data}
#         else:
#             return {}

#     @property
#     def endttimes(self):
#         """
#         Return a dict of ``{ station_id: startime }`` for all stations, where ``starttime``
#         is the starttime of the earliest sample set in that station.

#         :rtype: dict(str) -> float
#         """

#         if not self.is_empty:
#             data = (
#                 Station.objects.values('station_id', 'instruments__instrument_id')
#                                .annotate(starttime=models.Min('instruments__channels__sample_sets__starttime'))
#                                .order_by('station_id')
#             )
#             return {d['station_id']: d['starttime'] for d in data}
#         else:
#             return {}

#     @property
#     def endtime(self):
#         """
#         Return the endtime of the latest sample set we have, in epoch seconds.

#         :rtype: float
#         """
#         if not self.is_empty:
#             return TimeshiftedSampleSet.objects.aggregate(models.Max('endtime'))['endtime__max']
#         else:
#             return None

#     @property
#     def duration(self):
#         """
#         Return the time span in seconds between the starttime of our earliest sampleset and
#         the endtime of our latest.

#         :rtype: int
#         """
#         if not self.is_empty:
#             return self.endtime - self.starttime

#     def empty(self):
#         """
#         Purge all sample sets in all channels of all stations.
#         """
#         logger.info(
#             'state.empty.start',
#         )
#         SampleSet.objects.all().delete()
#         logger.info(
#             'state.empty.end',
#         )

#     def trim(self, horizon, set_ids=None):
#         """
#         Drop any sample sets older than ``horizon``.

#         :param horizon float: an epoch timestamp
#         """
#         SampleSet.objects.filter(endtime_lte=horizon).delete()



#     # def __full_instruments(self, sets, seconds):
#     #     counts = {}
#     #     total = 0
#     #     for s in sets:
#     #         #It appears some of the data is being predicted, others are not.
#     #         # print("Set values")
#     #         # print(type(s)) #<class 'quakes2aws_datastore.core.models.TimeshiftedSampleSet'>
#     #         # print(s.values()) #SampleSet(starttime=1623990851.59698, endtime=1623990852.58698, samprate=100.0)


#     #         if s.instrument_name not in counts:
#     #             counts[s.instrument_name] = {}
#     #         if s.channel_name not in counts[s.instrument_name]:
#     #             counts[s.instrument_name][s.channel_name] = 0
#     #         counts[s.instrument_name][s.channel_name] += 1
#     #         total += 1
#     #     good = []
#     #     for i in counts:
#     #         if len(counts[i]) == 3 and all([v >= seconds for v in counts[i].values()]):
#     #             good.append(i)
#     #     return good, total




#     def mark_sets_as_processed(self, set_ids):
#         SampleSet.objects.filter(id__in=set_ids).update(is_processed=True)



#     def tail(self, starttime, samprate=100, seconds=16, channel_filter=None):
#         """
#         Return TimeShiftedSampleSets for all channels that have

#         * Sampling rate of ``samprate``
#         * Start time between ``starttime`` and ``starttime + seconds + 1``.
#         * Channel name matching the regular expression ``channel_filter``.

#         :param starttime float: start at this epoch timestamp
#         :param seconds int: return this many seconds worth of samples for each channel
#         :param samprate int: return data only for channels with this sampling rate
#         :param channel_filter str: return data only for channels whose channel_id matches this regular
#                                    expression.  Default: "[EH]H[ENZ]"

#         :rtype: dict(str)
#         """
#         if not channel_filter:
#             channel_filter = "[EH]H[ENZ]"
#         if not self.is_empty:
#             sets = self.model.objects.filter(
#                 starttime__gte=starttime,
#                 endtime__lte=starttime + seconds + 1,
#                 samprate=samprate,
#                 channel_name__regex=channel_filter,
#                 is_processed=False
#             )

#             # sets=sets.exclude(channel__instrument__station__location__isnull=True)

#             return sets
#         return []


#     # def tail(self, starttime, seconds=16):
#     #     """
#     #     Return data for all channels that have ``seconds`` seconds worth of contiguous data starting after
#     #     ``starttime``.  Filter the channels to only those with sampling rate ``samprate``.

#     #     If ``channel_filter`` is not ``None``, also filter channels to only those whose Earthworm channel ID (e.g. EHZ)
#     #     matches ``channel_filter``, a regular expression.

#     #     Data returned will be a dict that organizes channel data by instrument, and has this structure:

#     #         {
#     #             'ADO.CI.--.EH': {
#     #                 'EHE': {
#     #                     'starttime': 123455664.00,
#     #                     'endtime': 123455680.00,
#     #                     'samprate': 100.0,
#     #                     'samples': [
#     #                         12355,
#     #                         12344,
#     #                         ...
#     #                         12312
#     #                     ]
#     #                 },
#     #                 'EHN': {
#     #                     ...
#     #                 },
#     #                 'EHZ': {
#     #                     ...
#     #                 }
#     #             }
#     #             ...
#     #         }

#     #     Where `ADO.CS.--.EH` is an instrument, and ['EHE', 'EHN', 'EHZ'] are channels on that instrument.

#     #     .. note::

#     #         The picker is cannot handle channels with sampling rate of other than 100Hz and cannot handle big motion
#     #         sensors (HN*), so we need to filter such channels out before returning out data.

#     #     :param starttime float: start at this epoch timestamp
#     #     :param seconds int: return this many seconds worth of samples for each channel
#     #     :param samprate int: return data only for channels with this sampling rate
#     #     :param channel_filter str: return data only for channels whose channel_id matches this regular expression

#     #     :rtype: dict(str)
#     #     """
#     #     stats = {
#     #         'starttime': starttime,
#     #     }
#     #     set_ids = []
#     #     data = {}
#     #     if not self.is_empty:
#     #         with Timer() as query_time:
#     #             sets = TimeshiftedSampleSet.objects.filter(
#     #                 starttime__gte=starttime,
#     #                 endtime__lte=starttime + seconds + 1,
#     #                 samprate=100,
#     #                 channel_name__regex="[EH]H[ENZ]",
#     #                 is_processed=False
#     #             )
#     #             good_instruments, total = self.__full_instruments(sets, seconds)
#     #             stats['n_samplesets_loaded'] = total
#     #         with Timer() as convert_time:
#     #             for s in sets:
#     #                 if s.instrument_name in good_instruments:
#     #                     set_ids.append(s.id)
#     #                     key = s.instrument_name
#     #                     if key not in data:
#     #                         data[key] = {}
#     #                     if s.channel_name not in data[key]:
#     #                         data[key][s.channel_name] = {
#     #                             'starttime': s.starttime_orig,
#     #                             'endtime': s.endtime_orig,
#     #                             'samprate': s.samprate,
#     #                             'samples': []
#     #                         }
#     #                     d = data[key][s.channel_name]
#     #                     d['endtime'] = s.endtime_orig
#     #                     d['samples'].extend(s.samples)

#     #         stats['n_samplesets_filtered'] = len(set_ids)
#     #         stats['query_time'] = query_time.elapsed
#     #         stats['convert_time'] = convert_time.elapsed
#     #         stats['instruments'] = len(data)
#     #         logger.info('state.tail', **stats)
#     #     return data, set_ids, stats


class StationDirectory:

    __shared_state = {'stations': {}}

    def __init__(self):
        self.__dict__ = self.__shared_state
        if not self.stations:
            self.load()

    def get(self, station):
        """
        Get the Django id of the Station object with Earthworm Station ID ``station.station_id``.  If the station
        doesn't exist, create it.

        :param station quakes2aws.utils.models.Station object: The station we want to load from the database

        :rtype: int
        """
        try:
            station_id = self.stations[station.station_id]
        except KeyError:
            with transaction.atomic():
                # Somebody may already have created this station while we were working on this
                # batch, so do a get_or_create
                station, created = Station.objects.get_or_create(
                    station_id=station.station_id,
                    network=station.network,
                    station=station.station,
                    location=station.location
                )
                if created:
                    station.save()
                    logger.info(
                        'StationDirectory.station.created',
                        station_id=station.station_id
                    )
            self.stations[station.station_id] = station.id
            station_id = station.id
        return station_id

    def load(self):
        self.stations = {sta.station_id: sta.id for sta in Station.objects.all()}
        logger.info('StationDirectory.load.success', stations=len(self.stations))


class InstrumentDirectory:

    __shared_state = {'instruments': {}}

    def __init__(self):
        self.__dict__ = self.__shared_state
        if not self.instruments:
            self.load()

    def get(self, station, channel, instrument_label):
        """
        Get the Django id of the Instrument object with Earthworm Station ID ``station.station_id`` and instrument ID
        ``instrument ID`` If the instrument doesn't exist, create it.

        If we create a new instrument, set its sampling rate based on the samprate of ``channel``.

        :param station quakes2aws.utils.models.Station: the Earthworm Station object
        :param station quakes2aws.utils.models.Channel: the Earthworm Channel object
        :param instrument_label string: the Instrument ID, e.g. "HN"

        :rtype: int
        """
        try:
            instrument_id = self.instruments[(station.station_id, instrument_label)]
        except KeyError:
            with transaction.atomic():
                # Somebody may already have created this station while we were working on this
                # batch, so do a get_or_create
                station_id = StationDirectory().get(station)
                instrument, created = Instrument.objects.get_or_create(
                    station_id=station_id,
                    instrument_id=instrument_label
                )
                if created:
                    instrument.samprate = channel.samprate
                    instrument.save()
                    logger.info(
                        'InstrumentDirectory.instrument.created',
                        station_id=station.station_id,
                        instrument_id=instrument_label
                    )
            self.instruments[(station.station_id, instrument_label)] = instrument.id
            instrument_id = instrument.id
        return instrument_id

    def load(self):
        self.instruments = {(i.station.station_id, i.instrument_id): i.id for i in Instrument.objects.all()}
        logger.info('InstrumentDirectory.load.success', instruments=len(self.instruments))


class ReadonlyInstrumentDirectory:

    __shared_state = {'instruments': {}}

    def __init__(self):
        self.__dict__ = self.__shared_state
        if not self.instruments:
            self.load()

    def get(self, station_id, instrument_label):
        """
        Get the Django id of the Instrument object with Earthworm Station ID ``station.station_id`` and instrument ID
        ``instrument ID`` If the instrument doesn't exist, create it.

        :param station_id str: the Earthworm Station id: ABC.CI.--
        :param instrument_id str: the Earthworm Instrument id: EH

        :rtype: int
        """
        try:
            instrument_id = self.instruments[(station_id, instrument_label)]
        except KeyError:
            try:
                # Somebody may already have created this station while we were working on this
                # batch, so do a get_or_create
                instrument, created = Instrument.objects.get(
                    station_id=station_id,
                    instrument_id=instrument_label
                )
            except Instrument.DoesNotExist:
                raise KeyError(f'No such instrument as {station_id}.{instrument_label}')
            self.instruments[(station_id, instrument_label)] = instrument.id
            instrument_id = instrument.id
        return instrument_id

    def load(self):
        self.instruments = {(i.station.station_id, i.instrument_id): i.id for i in Instrument.objects.all()}
        logger.info('ReadonlyInstrumentDirectory.load.success', instruments=len(self.instruments))


class ChannelDirectory:

    __shared_state = {'channels': {}}

    def __init__(self):
        self.__dict__ = self.__shared_state
        if not self.channels:
            self.load()

    def get(self, station, channel):
        """
        Get the Django id of the Channel object with Earthworm Station ID ``station.station_id`` and Earthworm
        Channel ID ``channel.channel_id``.  If the channel doesn't exist, create it.

        :param station quakes2aws.utils.models.Station: the Earthworm Station object
        :param station quakes2aws.utils.models.Channel: the Earthworm Channel object

        :rtype: int
        """
        instrument_label = BaseInstrument.instrument_id(channel.channel_id)
        try:
            channel_id = self.channels[(station.station_id, instrument_label, channel.channel_id)]
        except KeyError:
            id = InstrumentDirectory()
            with transaction.atomic():
                # Somebody may already have created this station while we were working on this
                # batch, so do a .get_or_create() instead of just .create()
                channel, created = Channel.objects.get_or_create(
                    instrument_id=id.get(station, channel, instrument_label),
                    channel_id=channel.channel_id
                )
                if created:
                    channel.save()
                    logger.info(
                        'ChannelDirectory.channel.created',
                        channel_id=channel.channel_id,
                        instrument_id=instrument_label,
                        station_id=station.station_id
                    )
            self.channels[(station.station_id, instrument_label, channel.channel_id)] = channel.id
            channel_id = channel.id
        return channel_id

    def load(self):
        self.channels = {
            (ch.instrument.station.station_id, ch.instrument.instrument_id, ch.channel_id): ch.id
            for ch in Channel.objects.all()
        }
        logger.info('ChannelDirectory.load.success', channels=len(self.channels))


# --------
# Mixins
# --------

class DjangoDataSnapshotMixin:

    def save(self, *args, **kwargs):
        """
        Save all of our new sample sets to the database.  We may also be creating new stations and channels here.
        """
        station_directory = StationDirectory()
        channel_directory = ChannelDirectory()
        sets = []
        stations = []
        n_channels = 0
        with Timer() as load_time:
            for sta in self.stations.values():
                # Note: We're making this a list here sho that we can update last_seen time for each station
                stations.append(station_directory.get(sta))
                for instrument_id in sta.instrument_ids:
                    instrument = sta.instrument(instrument_id)
                    for channel_id in instrument.channel_ids:
                        cha = instrument.channel(channel_id)
                        channel_id = channel_directory.get(sta, cha)
                        n_channels += 1
                        for s in cha.sets:
                            sampset = SampleSet()
                            sampset.channel_id = channel_id
                            sampset.channel_name = cha.channel_id
                            sampset.instrument_name = f'{sta.station_id}.{instrument.instrument_id}'
                            sampset.starttime = s['starttime']
                            sampset.endtime = s['endtime']
                            sampset.samprate = s['samprate']
                            sampset.samples = s['samples']
                            sampset.nsamples = len(s['samples'])
                            sets.append(sampset)
        with Timer() as station_update_time:
            with transaction.atomic():
                Station.objects.filter(id__in=stations).update(last_seen_at=timezone.now())
        with Timer() as insert_sets_time:
            SampleSet.objects.bulk_create(sets)
        logger.info(
            'snapshot.save.timing',
            stations=len(stations),
            channels=n_channels,
            sets=len(sets),
            load=load_time.elapsed,
            station_update=station_update_time.elapsed,
            insert_sets=insert_sets_time.elapsed
        )


class DataSnapshot(DjangoDataSnapshotMixin, BaseDataSnapshot):
    pass






# from contexttimer import Timer

# from django.apps import apps
# from django.core.cache import cache
# from django.db import models, transaction
# from django.utils import timezone
# from django.utils.functional import cached_property
# from django.contrib.postgres.fields import ArrayField

# # from quakes2aws.models import (
# #     DataSnapshot as BaseDataSnapshot,
# #     Instrument as BaseInstrument,
# #     Station as BaseStation,
# #     Channel as BaseChannel
# # )


# #I CHANGED THIS PART TO REFERENCE THE quakes2aws_datastore utils
# from quakes2aws_datastore.utils.models import (
#     DataSnapshot as BaseDataSnapshot,
#     Instrument as BaseInstrument,
#     Station as BaseStation,
#     Channel as BaseChannel,
#     DataSnapshot
# )

# from quakes2aws_datastore.logging import logger


# # --------------
# # Django Models
# # --------------

# class Station(models.Model):

#     last_tail_endtime = models.FloatField(
#         'Last Tail Endtime',
#         null=True,
#         help_text='When we last did a tail, endtime of that tail was this.  We use this to detect late '
#                   'arrriving packets; new packets with starttime before this timestamp will be '
#                   'discarded.'
#     )

#     station_id = models.CharField(
#         verbose_name='Station ID',
#         max_length=15,
#         unique=True,
#         db_index=True
#     )

#     station = models.CharField(verbose_name='Station', max_length=10, null=True)
#     network = models.CharField(verbose_name='Network', max_length=10, null=True)
#     location = models.CharField(verbose_name='Location', max_length=10, null=True)

#     latitude = models.FloatField(verbose_name="Latitude", null=True)
#     longitude = models.FloatField(verbose_name="Latitude", null=True)
#     elevation = models.FloatField(verbose_name="Elevation", null=True)

#     created_at = models.DateTimeField(auto_now_add=True)
#     last_seen_at = models.DateTimeField(
#         'Last Seen',
#         help_text='The last time we received a sample for this station.',
#         null=True
#     )

#     @property
#     def instrument_ids(self):
#         """
#         Return a list of the names of all the channels we have.

#         :rtype: list of strings
#         """
#         return [i.instrument_id for i in self.instruments.all().order_by('instrument_id')]

#     @property
#     def starttimes(self):
#         """
#         Return a dict of starttimes, where the keys are channel ids and the values are the startimes of the associated
#         channel.
#         """
#         d = {}
#         for i in self.instruments.all().order_by('instrument_id'):
#             try:
#                 starttime = i.starttime
#             except ValueError:
#                 starttime = None
#             d[i.instrument_id] = starttime
#         return d

#     @property
#     def starttime(self):
#         """
#         Return the starttime of the oldest sample across all our instruments.
#         """
#         starttimes = []
#         for i in self.instrument.all():
#             try:
#                 starttimes.append(i.starttime)
#             except ValueError:
#                 pass
#         if not starttimes:
#             return None
#         return min(starttimes)

#     @property
#     def endtimes(self):
#         """
#         Return a dict of endtimes, where the keys are instrument ids and the values are the endimes of the associated
#         instrument.
#         """
#         d = {}
#         for i in self.instruments.all().order_by('instrument_id'):
#             try:
#                 endtime = i.endtime
#             except ValueError:
#                 endtime = None
#             d[i.instrument_id] = endtime
#         return d

#     @property
#     def endtime(self):
#         """
#         Return the endtime of the newest sample across all our channels.
#         """
#         endtimes = []
#         for i in self.instrument.all():
#             try:
#                 endtimes.append(i.endtime)
#             except ValueError:
#                 pass
#         if not endtimes:
#             return None
#         return max(endtimes)

#     @property
#     def is_empty(self):
#         return set(self.starttimes.values()) == set([None])

#     def empty(self):
#         """
#         Purge data from all of our channels.
#         """
#         for instrument in self.instrument.all():
#             instrument.empty()
#         logger.info('station.empty.success', station_id=self.station_id)

#     def num_instruments(self):
#         return self.instruments.count()

#     def trim(self):
#         """
#         Make all of our instrument channels start at the same time.

#         .. note::

#             I assume here that all channels on the same station have (a) the same samprate and
#             (b) start recording sample sets simultaneously.

#             The thing to check here is when a Station has 2 different sensors (big motion and normal, e.g.),
#             do those two sensors operate in tandem?
#         """
#         max_starttime = max(self.starttimes.values())
#         for i in self.instruments.all():
#             i.trim(max_starttime)

#     class Meta:
#         db_table = "station"
#         verbose_name = "Station"
#         verbose_name_plural = "Stations"
#         ordering = ['station_id']


# class Instrument(models.Model):

#     instrument_id = models.CharField(
#         verbose_name='Instrument ID',
#         max_length=2,
#         db_index=True
#     )

#     description = models.CharField(
#         verbose_name='Instrument Description',
#         max_length=256,
#         db_index=True,
#         null=True
#     )

#     station = models.ForeignKey(
#         Station,
#         verbose_name='Station',
#         on_delete=models.CASCADE,
#         null=True,
#         help_text='The station to which this instrument belongs',
#         related_name='instruments'
#     )

#     samprate = models.FloatField(
#         verbose_name='Sampling Rate',
#         help_text='Sampling rate in Hz for this instrument',
#         editable=False,
#         null=True
#     )

#     created_at = models.DateTimeField(auto_now_add=True)

#     def instrument_path(self):
#         return f'{self.station.station_id}.{self.instrument_id}'

#     @property
#     def channel_ids(self):
#         """
#         Return a list of the names of all the channels we have.

#         :rtype: list of strings
#         """
#         return [ch.channel_id for ch in self.channels.all().order_by('channel_id')]

#     @property
#     def starttimes(self):
#         """
#         Return a dict of starttimes, where the keys are channel ids and the values are the startimes of the associated
#         channel.
#         """
#         d = {}
#         for ch in self.channels.all().order_by('channel_id'):
#             try:
#                 starttime = ch.starttime
#             except ValueError:
#                 starttime = None
#             d[ch.channel_id] = starttime
#         return d

#     @property
#     def starttime(self):
#         """
#         Return the starttime of the oldest sample across all our channels.
#         """
#         starttimes = []
#         for ch in self.channels.all():
#             starttime = ch.starttime
#             if starttime is not None:
#                 starttimes.append(starttime)
#         if not starttimes:
#             return 0
#         return min(starttimes)

#     @property
#     def endtimes(self):
#         """
#         Return a dict of endtimes, where the keys are channel ids and the values are the endimes of the associated
#         channel.
#         """
#         d = {}
#         for ch in self.channels.all().order_by('channel_id'):
#             try:
#                 endtime = ch.endtime
#             except ValueError:
#                 endtime = None
#             d[ch.channel_id] = endtime
#         return d

#     @property
#     def endtime(self):
#         """
#         Return the endtime of the newest sample across all our channels.
#         """
#         endtimes = []
#         for ch in self.channels.all():
#             endtime = ch.endtime
#             if endtime is not None:
#                 endtimes.append(ch.endtime)
#         if not endtimes:
#             return 0
#         return max(endtimes)

#     @property
#     def is_empty(self):
#         return set(self.starttimes.values()) == set([None])

#     def empty(self):
#         """
#         Purge data from all of our channels.
#         """
#         for channel in self.channels.all():
#             channel.empty()
#         logger.info('station.empty.success', station_id=self.station_id)

#     def num_channels(self):
#         return self.channels.count()

#     def trim(self):
#         """
#         Make all of our channels start at the same time.

#         .. note::

#             I assume here that all channels on the same instrument have (a) the same samprate and
#             (b) start recording sample sets simultaneously.
#         """
#         max_starttime = max(self.starttimes.values())
#         for ch in self.channels.all():
#             ch.trim(max_starttime)

#     def __unicode__(self):
#         return self.instrument_path

#     class Meta:
#         db_table = "instrument"
#         verbose_name = "Instrument"
#         verbose_name_plural = "Instruments"
#         ordering = ['instrument_id']
#         unique_together = ['station', 'instrument_id']
#         index_together = [('station', 'instrument_id')]


# class Channel(models.Model):

#     channel_id = models.CharField(
#         verbose_name='Channel ID',
#         max_length=3,
#         db_index=True
#     )

#     instrument = models.ForeignKey(
#         Instrument,
#         verbose_name='Instrument',
#         on_delete=models.CASCADE,
#         null=True,
#         help_text='The instrument to which this channel belongs',
#         related_name='channels'
#     )

#     created_at = models.DateTimeField(auto_now_add=True)

#     @property
#     def num_samples(self):
#         return self.sample_sets.count()

#     @property
#     def channel_path(self):
#         return f'{self.instrument.station.station_id}.{self.instrument.instrument_id}.{self.channel_id}'

#     @property
#     def is_empty(self):
#         return not self.sample_sets.exists()

#     @property
#     def starttime(self):
#         if not self.is_empty:
#             starttime = self.sample_sets.all().aggregate(models.Min('starttime'))['starttime__min']
#         else:
#             return None
#         return starttime

#     @property
#     def endtime(self):
#         if not self.is_empty:
#             endtime = self.sample_sets.all().aggregate(models.Max('endtime'))['endtime__max']
#         else:
#             return None
#         return endtime

#     @property
#     def duration(self):
#         if not self.is_empty:
#             bounds = self.sample_sets.all().aggregate(models.Min('starttime'), models.Max('endtime'))
#         else:
#             return None
#         return bounds['endtime__max'] - bounds['starttime__min']

#     def empty(self):
#         """
#         Purge all our sample_sets.
#         """
#         self.sample_sets.all().delete()

#     def trim(self, starttime=None):
#         """
#         Purge any of our sample sets that have starttime < ``starttime``.
#         """
#         self.sample_sets.filter(starttime__lt=starttime).delete()

#     def __unicode__(self):
#         return self.channel_id

#     class Meta:
#         db_table = "channel"
#         verbose_name = "Channel"
#         verbose_name_plural = "Channels"
#         ordering = ['channel_id']
#         unique_together = ['instrument', 'channel_id']
#         index_together = [('instrument', 'channel_id')]


# class SampleSet(models.Model):

#     instrument_name = models.CharField(
#         verbose_name='Instrument Name',
#         max_length=36,
#         null=True,
#         db_index=True
#     )

#     channel_name = models.CharField(
#         verbose_name='Channel Name',
#         max_length=3,
#         null=True,
#         db_index=True
#     )

#     starttime = models.FloatField(
#         verbose_name='Start Time',
#         help_text='Start time of sample set in epoch seconds, with usec',
#         editable=False,
#         db_index=True
#     )

#     endtime = models.FloatField(
#         verbose_name='End Time',
#         help_text='Start time of sample set in epoch seconds, with usec',
#         editable=False,
#         db_index=True
#     )

#     samprate = models.FloatField(
#         verbose_name='Sampling Rate',
#         help_text='Sampling rate in Hz for this sample set',
#         editable=False
#     )

#     samples = ArrayField(
#         models.IntegerField(),
#         verbose_name='Samples',
#         help_text='List of integer samples stored as an integer array',
#         editable=False
#     )

#     nsamples = models.IntegerField(
#         verbose_name='Number of Samples',
#         help_text='Number of samples stored in samples',
#         editable=False
#     )

#     is_processed = models.BooleanField(
#         verbose_name='Processed?',
#         help_text='Has this sample set been processed by the picker?',
#         default=False,
#         editable=False
#     )

#     channel = models.ForeignKey(
#         Channel,
#         verbose_name='Channel',
#         on_delete=models.CASCADE,
#         null=True,
#         help_text='The channel to which this sample set belongs',
#         related_name='sample_sets'
#     )

#     created_at = models.DateTimeField(auto_now_add=True)

#     class Meta:
#         db_table = "sample_set"
#         verbose_name = "Sample Set"
#         verbose_name_plural = "Sample Sets"
#         ordering = ['starttime']
#         index_together = [('starttime', 'endtime')]

#     def __str__(self):
#         return f'SampleSet(starttime={self.starttime}, endtime={self.endtime}, samprate={self.samprate})'


# class TimeshiftedSampleSet(models.Model):

#     instrument_name = models.CharField(
#         verbose_name='Instrument Name',
#         max_length=36,
#         null=True,
#     )

#     channel_name = models.CharField(
#         verbose_name='Channel Name',
#         max_length=3,
#         null=True,
#     )

#     delay = models.FloatField(
#         verbose_name='Delay (s)',
#         help_text="Difference in seconds between this sample's endtime and now",
#         editable=False
#     )

#     starttime_orig = models.FloatField(
#         verbose_name='Start Time (unshifted)',
#         help_text='Start time of sample set in epoch seconds, with usec',
#         editable=False
#     )

#     starttime = models.FloatField(
#         verbose_name='Start Time (shifted)',
#         help_text='Start time of sample set in epoch seconds, with usec',
#         editable=False
#     )

#     endtime_orig = models.FloatField(
#         verbose_name='End Time (unshifted)',
#         help_text='Start time of sample set in epoch seconds, with usec',
#         editable=False
#     )

#     endtime = models.FloatField(
#         verbose_name='End Time (shifted)',
#         help_text='Start time of sample set in epoch seconds, with usec',
#         editable=False
#     )

#     samprate = models.FloatField(
#         verbose_name='Sampling Rate',
#         help_text='Sampling rate in Hz for this sample set',
#         editable=False
#     )

#     samples = ArrayField(
#         models.IntegerField(),
#         verbose_name='Samples',
#         help_text='List of integer samples stored as an integer array',
#         editable=False
#     )

#     nsamples = models.IntegerField(
#         verbose_name='Number of Samples',
#         help_text='Number of samples stored in samples',
#         editable=False
#     )

#     is_processed = models.BooleanField(
#         verbose_name='Processed?',
#         help_text='Has this sample set been processed by the picker?',
#         default=False,
#         editable=False
#     )

#     channel = models.ForeignKey(
#         Channel,
#         verbose_name='Channel',
#         on_delete=models.DO_NOTHING,
#         null=True,
#         help_text='The channel to which this sample set belongs',
#         related_name='timeshifted_sample_sets'
#     )

#     created_at = models.DateTimeField()

#     class Meta:
#         db_table = "timeshifted_sample_set_v"
#         verbose_name = "Timeshifted Sample Set"
#         verbose_name_plural = "Timeshifted Sample Sets"
#         ordering = ['starttime']
#         managed = False

#     def __str__(self):
#         return f'SampleSet(starttime={self.starttime}, endtime={self.endtime}, samprate={self.samprate})'


class State:

    def __init__(self, live=True):
        if live:
            self.model = TimeshiftedSampleSet
        else:
            self.model = SampleSet

    @property
    def stations(self):
        return Station.objects.all().order_by('station_id')

    @property
    def networks(self):
        return sorted(list(Station.objects.order_by().values_list('network', flat=True).distinct()))

    @property
    def station_ids(self):
        return [sta.station_id for sta in self.stations]

    @property
    def is_empty(self):
        return not SampleSet.objects.exists()

    @property
    def starttime(self):
        """
        Return the starttime of the earliest sample set we have, in epoch seconds.

        :rtype: float
        """
        if not self.is_empty:
            return self.model.objects.aggregate(models.Min('starttime'))['starttime__min']
        else:
            return None

    @property
    def starttimes(self):
        """
        Return a dict of ``{ station_id: startime }`` for all stations, where ``starttime``
        is the starttime of the earliest sample set in that station.

        :rtype: dict(str) -> float
        """

        if not self.is_empty:
            data = (
                Station.objects
                .values('station_id', 'instruments__instrument_id')
                .annotate(
                    starttime=models.Min('instruments__channels__timeshifted_sample_sets__starttime')
                )
                .order_by('station_id')
            )
            return {d['station_id']: d['starttime'] for d in data}
        else:
            return {}

    @property
    def endttimes(self):
        """
        Return a dict of ``{ station_id: startime }`` for all stations, where ``starttime``
        is the starttime of the earliest sample set in that station.

        :rtype: dict(str) -> float
        """

        if not self.is_empty:
            data = (
                Station.objects
                .values('station_id', 'instruments__instrument_id')
                .annotate(starttime=models.Min('instruments__channels__sample_sets__starttime'))
                .order_by('station_id')
            )
            return {d['station_id']: d['starttime'] for d in data}
        else:
            return {}

    @property
    def endtime(self):
        """
        Return the endtime of the latest sample set we have, in epoch seconds.

        :rtype: float
        """
        if not self.is_empty:
            return self.model.objects.aggregate(models.Max('endtime'))['endtime__max']
        else:
            return None

    @property
    def duration(self):
        """
        Return the time span in seconds between the starttime of our earliest sampleset and
        the endtime of our latest.

        :rtype: int
        """
        if not self.is_empty:
            return self.endtime - self.starttime

    def empty(self):
        """
        Purge all sample sets in all channels of all stations.
        """
        logger.info(
            'state.empty.start',
        )
        SampleSet.objects.all().delete()
        logger.info(
            'state.empty.end',
        )

    def trim(self, horizon, set_ids=None):
        """
        Drop any sample sets older than ``horizon``.

        :param horizon float: an epoch timestamp
        """
        SampleSet.objects.filter(endtime_lte=horizon).delete()

    def mark_sets_as_processed(self, set_ids):
        SampleSet.objects.filter(id__in=set_ids).update(is_processed=True)

    def tail(self, starttime, samprate=100, seconds=16, channel_filter=None):
        """
        Return TimeShiftedSampleSets for all channels that have

        * Sampling rate of ``samprate``
        * Start time between ``starttime`` and ``starttime + seconds + 1``.
        * Channel name matching the regular expression ``channel_filter``.

        :param starttime float: start at this epoch timestamp
        :param seconds int: return this many seconds worth of samples for each channel
        :param samprate int: return data only for channels with this sampling rate
        :param channel_filter str: return data only for channels whose channel_id matches this regular
                                   expression.  Default: "[EH]H[ENZ]"

        :rtype: dict(str)
        """
        if not channel_filter:
            channel_filter = "[EH]H[ENZ]"
        if not self.is_empty:
            sets = self.model.objects.filter(
                starttime__gte=starttime,
                endtime__lte=starttime + seconds + 1,
                samprate=samprate,
                channel_name__regex=channel_filter,
                is_processed=False
            )
            return sets
        return []


# class StationDirectory:

#     __shared_state = {'stations': {}}

#     def __init__(self):
#         self.__dict__ = self.__shared_state
#         if not self.stations:
#             self.load()

#     def get(self, station_id):
#     # def get(self, station):
#         """
#         Get the Django id of the Station object with Earthworm Station ID ``station.station_id``.  If the station
#         doesn't exist, create it.

#         :param station quakes2aws.utils.models.Station object: The station we want to load from the database

#         :rtype: int
#         """
#         try:
#             sta_id = self.stations[station_id]
#             # sta_id = self.stations[station.station_id]

#         except KeyError:
#             with transaction.atomic():
#                 # Somebody may already have created this station while we were working on this
#                 # batch, so do a get_or_create


#                 #RYAN EDITED (this works for prediction side)
#                 station, network, location = station_id.split('.')
#                 station, created = Station.objects.get_or_create(
#                     station_id=station_id,
#                     network=network,
#                     station=station,
#                     location=location
#                 )

#                 # station, created = Station.objects.get_or_create(
#                 #     station_id=station.station_id,
#                 #     network=station.network,
#                 #     station=station.station,
#                 #     location=station.location
#                 # )



#                 if created:
#                     station.save()
#                     logger.info('StationDirectory.station.created', station_id=station_id)

#                 # if created:
#                 #     station.save()
#                 #     logger.info('StationDirectory.station.created', station_id=station.station_id)
#             self.stations[station_id] = station.id
#             # self.stations[station.station_id] = station.id

#             sta_id = station.id
#         return sta_id

#     def load(self):
#         self.stations = {sta.station_id: sta.id for sta in Station.objects.all()}
#         logger.info('StationDirectory.load.success', stations=len(self.stations))


# class InstrumentDirectory:

#     __shared_state = {'instruments': {}}

#     def __init__(self):
#         self.__dict__ = self.__shared_state
#         if not self.instruments:
#             self.load()

#     def get(self, station_id, instrument_id, samprate):
#         """
#         Get the Django id of the Instrument object with Earthworm Station ID ``station.station_id`` and instrument ID
#         ``instrument ID`` If the instrument doesn't exist, create it.

#         If we create a new instrument, set its sampling rate based on the samprate of ``channel``.

#         :param station quakes2aws.utils.models.Station: the Earthworm Station object
#         :param station quakes2aws.utils.models.Channel: the Earthworm Channel object
#         :param instrument_label string: the Instrument ID, e.g. "HN"

#         :rtype: int
#         """
#         try:
#             inst_id = self.instruments[(station_id, instrument_id)]
#         except KeyError:
#             with transaction.atomic():
#                 # Somebody may already have created this station while we were working on this
#                 # batch, so do a get_or_create
#                 station_id = StationDirectory().get(station_id=station_id)
#                 instrument, created = Instrument.objects.get_or_create(
#                     station_id=station_id,
#                     instrument_id=instrument_id
#                 )
#                 if created:
#                     instrument.samprate = samprate
#                     instrument.save()
#                     logger.info(
#                         'InstrumentDirectory.instrument.created',
#                         station_id=station_id,
#                         instrument_id=instrument_id
#                     )
#             self.instruments[(station_id, instrument_id)] = instrument.id
#             inst_id = instrument.id
#         return inst_id


#     def load(self):
#         self.instruments = {(i.station.station_id, i.instrument_id): i.id for i in Instrument.objects.all()}
#         logger.info('InstrumentDirectory.load.success', instruments=len(self.instruments))


# class ReadonlyInstrumentDirectory:

#     __shared_state = {'instruments': {}}

#     def __init__(self):
#         self.__dict__ = self.__shared_state
#         if not self.instruments:
#             self.load()

#     def get(self, station_id, instrument_label):
#         """
#         Get the Django id of the Instrument object with Earthworm Station ID ``station.station_id`` and instrument ID
#         ``instrument ID`` If the instrument doesn't exist, create it.

#         :param station_id str: the Earthworm Station id: ABC.CI.--
#         :param instrument_id str: the Earthworm Instrument id: EH

#         :rtype: int
#         """
#         try:
#             instrument_id = self.instruments[(station_id, instrument_label)]
#         except KeyError:
#             try:
#                 # Somebody may already have created this station while we were working on this
#                 # batch, so do a get_or_create
#                 instrument, created = Instrument.objects.get(
#                     station_id=station_id,
#                     instrument_id=instrument_label
#                 )
#             except Instrument.DoesNotExist:
#                 raise KeyError(f'No such instrument as {station_id}.{instrument_label}')
#             self.instruments[(station_id, instrument_label)] = instrument.id
#             instrument_id = instrument.id
#         return instrument_id

#     def load(self):
#         self.instruments = {(i.station.station_id, i.instrument_id): i.id for i in Instrument.objects.all()}
#         logger.info('ReadonlyInstrumentDirectory.load.success', instruments=len(self.instruments))


# class ChannelDirectory:

#     __shared_state = {'channels': {}}

#     def __init__(self):
#         self.__dict__ = self.__shared_state
#         if not self.channels:
#             self.load()

#     def get(self, station_id, instrument_id, channel_id, samprate):
#         """
#         Get the Django id of the Channel object with Earthworm Station ID ``station.station_id`` and Earthworm
#         Channel ID ``channel.channel_id``.  If the channel doesn't exist, create it.

#         :param station quakes2aws.utils.models.Station: the Earthworm Station object
#         :param station quakes2aws.utils.models.Channel: the Earthworm Channel object

#         :rtype: int
#         """
#         try:
#             channel_id = self.channels[(station_id, instrument_id, channel_id)]
#         except KeyError:
#             id = InstrumentDirectory()
#             with transaction.atomic():
#                 # Somebody may already have created this station while we were working on this
#                 # batch, so do a .get_or_create() instead of just .create()
#                 channel, created = Channel.objects.get_or_create(
#                     instrument_id=id.get(station_id, instrument_id, samprate),
#                     channel_id=channel_id
#                 )
#                 if created:
#                     channel.save()
#                     logger.info(
#                         'ChannelDirectory.channel.created',
#                         channel_id=channel.channel_id,
#                         instrument_id=instrument_id,
#                         station_id=station_id
#                     )
#             self.channels[(station_id, instrument_id, channel_id)] = channel.id
#             channel_id = channel.id
#         return channel_id

#     def load(self):
#         self.channels = {
#             (ch.instrument.station.station_id, ch.instrument.instrument_id, ch.channel_id): ch.id
#             for ch in Channel.objects.all()
#         }
#         logger.info('ChannelDirectory.load.success', channels=len(self.channels))
