from django.urls import path

from .views import HomeView

# These are loaded by quakes2aws/urls.py.
app_name = 'core'
urlpatterns = [
    path('', HomeView.as_view(), name='home'),
]
