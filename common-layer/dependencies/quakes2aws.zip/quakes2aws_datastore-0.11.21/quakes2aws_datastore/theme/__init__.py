default_app_config = 'quakes2aws_datastore.theme.apps.ThemeConfig'
