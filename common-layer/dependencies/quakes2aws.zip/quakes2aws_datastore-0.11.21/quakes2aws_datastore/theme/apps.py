from django.apps import AppConfig


class ThemeConfig(AppConfig):
    name = 'quakes2aws_datastore.theme'
    label = 'theme'
