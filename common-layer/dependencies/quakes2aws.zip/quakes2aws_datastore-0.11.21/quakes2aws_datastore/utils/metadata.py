import fcntl
import json
import os
import socket
import struct
import time

import requests


class EC2Metadata:
    """
    Class for querying metadata from EC2.
    """

    @staticmethod
    def valid():
        # This path is amazon linux 2 only
        if os.path.exists('/sys/devices/virtual/dmi/id/product_uuid'):
            with open('/sys/devices/virtual/dmi/id/product_uuid') as fd:
                key = fd.read()[0:3]
            if key == 'EC2':
                return True
        return False

    def __init__(self, addr='169.254.169.254', api='latest'):
        self.addr = addr
        self.api = api
        if not self._test_connectivity(self.addr, 80):
            raise Exception("could not establish connection to: {0}".format(self.addr))

    @staticmethod
    def _test_connectivity(addr, port):
        for i in range(6):
            s = socket.socket()
            try:
                s.connect((addr, port))
                s.close()
                return True
            except socket.error:
                time.sleep(1)
        return False

    def _get_ec2(self, uri):
        """
        Make the request to the metadata URL.
        """
        url = 'http://{}/{}/{}/'.format(self.addr, self.api, uri)
        response = requests.get(url)
        if "404 - Not Found" in response.text:
            return None
        return response.text

    def get(self, name):
        if name == 'availability-zone':
            return self._get_ec2('meta-data/placement/availability-zone')

        if name == 'public-keys':
            data = self._get_ec2('meta-data/public-keys')
            keyids = [line.split('=')[0] for line in data.splitlines()]
            public_keys = []
            for keyid in keyids:
                uri = 'meta-data/public-keys/%d/openssh-key' % int(keyid)
                public_keys.append(self._get_ec2(uri).rstrip())
            return public_keys

        if name == 'user-data':
            return self._get_ec2('user-data')

        if name == 'region':
            return json.loads(self._get_ec2('dynamic/instance-identity/document'))['region']

        return self._get_ec2('meta-data/' + name)


class ECSMetadata(EC2Metadata):

    ECS_METAOPTS = {
        'docker-id': (None, 'DockerId'),
        'name': (None, 'Name'),
        'image': (None, 'Image'),
        'image-id': (None, 'ImageID'),
        'docker-labels': (None, 'Labels'),
        'created-at': (None, 'CreatedAt'),
        'started-at': (None, 'StartedAt'),
        'cluster': ('task', 'Cluster'),
        'task-arn': ('task', 'TaskARN'),
        'task-revision-family': ('task', 'Family'),
        'availability-zone': ('task', 'AvailabilityZone')
    }

    @staticmethod
    def valid():
        return 'ECS_CONTAINER_METADATA_URI_V4' in os.environ

    def __init__(self, *args, **kwargs):
        self.url_base = os.environ['ECS_CONTAINER_METADATA_URI_V4']
        super().__init__(*args, **kwargs)

    def _get_ecs(self, suburl=None):
        """
        Make the request to the metadata URL.
        """
        if suburl:
            url = '{}/{}'.format(self.url_base, suburl)
        else:
            url = self.url_base
        response = requests.get(url)
        if "404 - Not Found" in response.text:
            return None
        return json.loads(response.text)

    def get(self, name):
        if name == 'local-hostname':
            network_mode = self.get('network-mode')
            if network_mode == 'awsvpc':
                return self._get_ecs()['Networks'][0]['PrivateDNSName']
            elif network_mode == 'host':
                return super().get('local-hostname')
            else:
                # bridge
                return self.get('docker-id')[0:12]
        elif name == 'local-ipv4':
            network_mode = self.get('network-mode')
            if network_mode in ['awsvpc', 'bridge']:
                return self._get_ecs()['Networks'][0]['IPv4Addresses'][0]
            else:
                # host networking
                return super().get('local-ipv4')
        elif name == 'network-mode':
            return self._get_ecs()['Networks'][0]['NetworkMode']
        else:
            try:
                suburl = self.ECS_METAOPTS[name][0]
                key = self.ECS_METAOPTS[name][1]
                return self._get_ecs(suburl=suburl)[key]
            except KeyError:
                return super().get(name)


class LinuxMetadata:

    def get_interface_ip(self, ifname):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        return socket.inet_ntoa(
            fcntl.ioctl(
                s.fileno(),
                0x8915,
                struct.pack('256s', ifname[:15])
            )[20:24]
        )

    def get_ipaddr(self):
        ip = socket.gethostbyname(socket.gethostname())
        if ip.startswith("127.") and os.name != "nt":
            interfaces = [
                "eth0",
                "eth1",
                "eth2",
                "eth3"
            ]
            for ifname in interfaces:
                try:
                    ip = self.get_interface_ip(ifname)
                    break
                except IOError:
                    pass
        return ip

    def get(self, name):
        if name == 'local-hostname':
            return socket.gethostbyaddr(socket.gethostname())[0]
        elif name == 'local-ipv4':
            return self.get_ipaddr()
        else:
            raise KeyError


class MetadataFactory:

    @staticmethod
    def new():
        if ECSMetadata.valid():
            return ECSMetadata()
        elif EC2Metadata.valid():
            return EC2Metadata()
        else:
            return LinuxMetadata()
