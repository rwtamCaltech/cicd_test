import json
import os

import boto3

from ..logging import logger
from .models import DataSnapshot as BaseDataSnapshot


# ========
# Mixins
# ========


class S3StorageMixin:

    BUCKET = os.environ['ARCHIVE_BUCKET_NAME']
    S3_ENDPOINT_URL = os.environ.get('S3_ENDPOINT_URL', None)

    def save(self, key):
        s3 = boto3.client('s3', endpoint_url=self.S3_ENDPOINT_URL)
        s3.put_object(
            Body=bytes(json.dumps(self.json()).encode('utf8')),
            ACL='private',
            Bucket=self.BUCKET,
            Key=key
        )
        logger.info(
            '{}.save'.format(self.__class__.__name__.lower()),
            filename=key,
            starttime=self.starttime,
            endtime=self.endtime,
            stations=len(self.stations)
        )


class S3StateStorageMixin:

    def __init__(self, *args, **kwargs):
        if 'function_name' in kwargs:
            function_name = kwargs.pop('function_name')
        super().__init__(*args, **kwargs)
        self.name = "state"
        self.last_saved = 0.0
        self.STATEFILE_NAME = f'{function_name}/state'
        self.BATCHES_FOLDER = f'{function_name}/batches'

    def __get_remote_last_modified(self):
        """
        Return the value of the LastModified tag on our remote state file.
        """
        s3 = boto3.client('s3', endpoint_url=self.S3_ENDPOINT_URL)
        last_modified = 0.0
        try:
            metadata = s3.head_object(Bucket=self.BUCKET, Key=self.STATEFILE_NAME)
        except s3.exceptions.NoSuchKey:
            logger.warning(
                'state.remote.last-modified.no-file',
                bucket=self.BUCKET,
                key=self.STATEFILE_NAME
            )
        except:  # noqa
            # Need to do better than this ... the s3 client should be raising NoSuchKey
            # when the key doesn't exist, but sometimes it raises MethodNotAllowed.  I
            # don't know how to catch that, so i'm using the catchall exception here
            logger.warning(
                'state.remote.last-modified.no-file',
                bucket=self.BUCKET,
                filename=self.STATEFILE_NAME
            )
        else:
            last_modified = metadata['LastModified'].timestamp()
        logger.debug(
            'State.__get_remote_last_modified',
            timestamp=last_modified
        )
        return last_modified

    def get_remote_state(self):
        """
        Download our cached statefile from S3 and return the data as decoded JSON.
        """
        s3 = boto3.client('s3', endpoint_url=self.S3_ENDPOINT_URL)
        try:
            response = s3.get_object(Bucket=self.BUCKET, Key=self.STATEFILE_NAME)
        except s3.exceptions.NoSuchKey:
            logger.warning('state.remote.get.no-file bucket={} key={}'.format(
                self.BUCKET,
                self.STATEFILE_NAME
            ))
            return DataSnapshot().json()
        data = json.loads(response['Body'].read().decode('utf8'))
        logger.info(
            'state.remote.get.success',
            bucket=self.BUCKET,
            key=self.STATEFILE_NAME,
            last_modified=response['LastModified'].timestamp()
        )
        return data

    def refresh(self):
        """
        Reload ourselves from our S3 remote state file if our LastModified timestamp is older
        than that on the remote state file.
        """
        remote_last_modified = self.__get_remote_last_modified()
        if self.last_modified < remote_last_modified:
            logger.info(
                'state.refresh.needed',
                my_last_modified=self.last_saved,
                remote_last_modifed=remote_last_modified
            )
            self.load(self.get_remote_state())
        else:
            logger.info(
                'state.refresh.not-needed',
                my_last_modified=self.last_modified,
                remote_last_modified=remote_last_modified
            )

    def tail(self, seconds):
        for tail in super().tail(seconds):
            filename = f'{self.BATCHES_FOLDER}/{tail.last_modified}'
            tail.save(filename)
            logger.info(
                'state.tail.saved',
                filename=filename,
                starttime=tail.starttime,
                endtime=tail.endtime,
                stations=len(tail.stations),
                secons=seconds
            )

    def save(self):
        super().save(key=self.STATEFILE_NAME)
        self.last_saved = self.__get_remote_last_modified()


# ========
# Models
# ========


class DataSnapshot(S3StorageMixin, BaseDataSnapshot):
    pass


class State(S3StateStorageMixin, DataSnapshot):
    pass

