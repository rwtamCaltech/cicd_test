from simple_rest_client.api import API
from simple_rest_client.resource import Resource


class SnapshotResource(Resource):

    actions = {
        "create": {"method": "POST", "url": "snapshots"},
    }

# class SCSNLatLongResource(Resource):
#     actions = {
#         "create": {"method": "POST", "url": "scnlatlong"},
#     }

class DatastoreAPI(API):

    def __init__(self, host, port, token, version="v1", ssl_verify=False):
        super().__init__(
            api_root_url=f"https://{host}:{port}/api/{version}/",
            headers={'Authorization': 'Token  {}'.format(token)},
            timeout=120,
            append_slash=True,
            ssl_verify=ssl_verify,
            json_encode_body=True
        )
        self.add_resource(resource_name='stations')
        self.add_resource(resource_name='instruments')
        self.add_resource(resource_name='channels')
        self.add_resource(
            resource_class=SnapshotResource,
            resource_name='snapshots'
        )   
        # self.add_resource(
        #     resource_class=SCSNLatLongResource,
        #     resource_name='scnlatlong'
        # )