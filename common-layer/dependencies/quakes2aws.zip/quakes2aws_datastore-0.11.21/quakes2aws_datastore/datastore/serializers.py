import re

from marshmallow import Schema, fields, pre_load, pre_dump


class SnapshotSampleSetSchema(Schema):
    """
    This converts between the SampleSet structure of ``quakes2aws.models.Channel().sets` and the stations part of the
    payload for the DatastoreAPI:snapshot endpoint.

    Expected structure::

        {
            'endttime': 1564769785.958393,
            'starttime': 1564769784.968393,
            'samples': [-195, -190, ... -87],
        }
    """

    starttime = fields.Float(required=True)
    endtime = fields.Float(required=True)
    samples = fields.List(fields.Integer, required=True)


class SnapshotChannelSchema(Schema):
    """
    This converts between a ``quakes2aws.models.Channel` object and the stations part of the payload for the
    DatastoreAPI:snapshot endpoint.

    Expected structure::

        {
            'channel_id': 'HHE',
            'sets': [
                {
                    'endttime': 1564769785.958393,
                    'starttime': 1564769784.968393,
                    'nsamples': 100,
                    'samples': [-195, -190, ... -87],
                },

                [...]
            ]
        }
    """
    channel_id = fields.String(required=True)
    sets = fields.Nested(SnapshotSampleSetSchema, many=True)

    @pre_dump(pass_many=False)
    def dump_preprocess(self, obj, many, **kwargs):
        data_out = {}
        data_out['channel_id'] = obj.channel_id
        data_out['sets'] = obj.sets
        return data_out


class SnapshotInstrumentSchema(Schema):
    """
    This converts between a ``quakes2aws.models.Instrument` object and the stations part of the payload for the
    DatastoreAPI:snapshot endpoint.

    Expected structure::

        {
            'instrument_id': 'HH',
            'samprate': 100.0,
            'channels': [
                {
                    'channel_id': 'HHE',
                    'sets': [
                        [...]
                    ]
                },
                [...]
            ]
        }
    """
    instrument_id = fields.String(required=True)
    samprate = fields.Float(required=True)
    channels = fields.Nested(SnapshotChannelSchema, many=True, required=True)

    @pre_dump(pass_many=False)
    def dump_preprocess(self, obj, many, **kwargs):
        data_out = {}
        data_out['instrument_id'] = obj.instrument_id
        data_out['samprate'] = obj.samprate
        data_out['channels'] = obj.channels.values()
        return data_out


class SnapshotStationSchema(Schema):
    """
    This converts between a ``quakes2aws.models.Station` object and the stations part of the payload for the
    DatastoreAPI:snapshot endpoint.

    Expected structure::

        {
            'station_id': 'STA.NET.LOC',
            'instruments': [
                {
                    'instrument_id': 'HH',
                    'samprate': 100.0,
                    'starttime': 1564769784.968393,
                    'endtime': 1564769785.958393,
                    'channels': [
                        [...]
                    ]
                },
                [...]
            ]
        }
    """
    station_id = fields.Str(max_length=30)
    instruments = fields.Nested(SnapshotInstrumentSchema, many=True)

    @pre_dump(pass_many=False)
    def dump_preprocess(self, obj, many, **kwargs):
        data_out = {}
        data_out['station_id'] = obj.station_id
        data_out['instruments'] = obj.instruments.values()
        return data_out


class SnapshotSchema(Schema):
    """
    This converts between a ``quakes2aws.models.DataSnaphot` object and the payload for the DatastoreAPI:snapshot
    endpoint.

    Expected structure::

        {
            'timestamp': 1564769784.968393,
            'stations': [
                {
                    'station_id': 'STA.NET.LOC',
                    'instruments': [
                        {
                            'instrument_id': 'HH',
                            'samprate': 100.0,
                            'channels': [
                                {
                                    'channel_id': 'HHE',
                                    'sets': [
                                        {
                                            'endttime': 1564769785.958393,
                                            'starttime': 1564769784.968393,
                                            'samples': [-195, -190, ... -87],
                                        },

                                        [...]
                                    ]
                                },
                                {
                                    'channel_id': 'HHN',
                                    [...]
                                },
                                {
                                    'channel_id': 'HHZ',
                                    [...]
                                },
                            ]
                    ]
            ]
        }
    """

    timestamp = fields.Float()
    stations = fields.Nested(SnapshotStationSchema, many=True)

    @pre_dump(pass_many=False)
    def dump_preprocess(self, obj, many, **kwargs):
        data_out = {}
        data_out['timestamp'] = obj.last_modified
        data_out['stations'] = obj.stations.values()
        return data_out
