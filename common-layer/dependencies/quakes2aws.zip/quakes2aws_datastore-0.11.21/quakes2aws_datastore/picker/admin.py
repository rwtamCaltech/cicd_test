from django.contrib import admin

from .models import PickEvent, PickProbabilityWaveform, PickRunStats


@admin.register(PickProbabilityWaveform)
class PickProbabilityWaveformAdmin(admin.ModelAdmin):

    list_filter = ('created_at', 'instrument')

    list_display = (
        'instrument',
        'starttime',
        'endtime',
        'samprate',
        'nsamples',
        'max_data_s',
        'max_data_p',
        'created_at',
    )
    ordering = ('-created_at', 'starttime')


@admin.register(PickEvent)
class PickEventAdmin(admin.ModelAdmin):

    list_filter = ('created_at', 'instrument')

    list_display = (
        'instrument',
        'timestamp',
        'threshold',
        'probability_waveform',
        'source',
        'created_at',
    )
    ordering = ('-created_at', 'timestamp')


@admin.register(PickRunStats)
class PickRunStatsAdmin(admin.ModelAdmin):

    list_filter = ('created_at', 'state')

    list_display = (
        'created_at',
        'state',
        'starttime',
        'binsize',
        'n_instruments_total',
        'n_instruments_good',
        'n_samplesets_loaded',
        'n_samplesets_filtered',
        'n_picks',
        'get_run_time_display',
        'get_tail_time_display',
        'get_tail_query_time_display',
        'get_tail_serialize_time_display',
        'get_infer_time_display',
        'get_save_time_display',
        'get_set_update_time_display',
        'cpu_percent',
        'load_1min',
    )
    ordering = ('-created_at', 'starttime')
