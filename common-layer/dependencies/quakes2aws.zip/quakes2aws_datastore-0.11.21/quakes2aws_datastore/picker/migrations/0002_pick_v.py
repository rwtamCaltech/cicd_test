from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('picker', '0001_initial'),
    ]

    operations = [
        migrations.RunSQL(
            sql=[
                """
CREATE VIEW pick_data_v AS
    SELECT
    p.starttime AS pick_starttime,
    p.endtime AS pick_endtime,
    p.created_at as pick_created_at,
    p.instrument_id as instrument_id,
    generate_series(0, (p.nsamples-1)) as index,
    unnest(p.data_p) as datum_p,
    unnest(p.data_s) as datum_s,
    p.starttime + (
      (
        generate_series(0, (nsamples-1))::float4 / ((nsamples)::float4 - 1)
      ) * (p.endtime - p.starttime)
    ) AS timestamp
FROM pick p
ORDER BY p.starttime;
                """
            ],
            reverse_sql=[
                """
DROP VIEW pick_data_v;
                """
            ]
        )
    ]
