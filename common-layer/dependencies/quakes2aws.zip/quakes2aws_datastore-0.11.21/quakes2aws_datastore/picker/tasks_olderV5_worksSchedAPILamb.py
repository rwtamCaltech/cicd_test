import json
from multiprocessing import Process, Queue
import psutil
import time
import schedule
import threading
import sys
#Ryan added
import pandas as pd
import traceback
import numpy as np
import os
import requests
from pytz import timezone

# from quakes2aws_datastore.pickprediction import setup_for_prediction
import quakes2aws_datastore.s3 as s3

# import torch
# from model_processor.model_utils import model_utilities
# import quakes2aws_datastore.s3 as s3

from aws_kinesis_agg.aggregator import RecordAggregator
import boto3
from contexttimer import Timer
from django.conf import settings
from datetime import datetime

from quakes2aws.picker.api import PickerAPI

from quakes2aws_datastore.logging import logger
from quakes2aws_datastore.core.models import State

from .models import PickRunStats
from .serializers import PickRunRequestSerializer, PickRunResultsSerializer

from quakes2aws_datastore.datastore.serializers import SnapshotSchema
from quakes2aws_datastore.api.serializers import SnapshotSerializer
from quakes2aws_datastore.models import DataSnapshot

def write_to_kinesis(kinesis_client, stream_name, agg_record):
    """
    Actually do a put_record to write some data to the Kinesis stream.
    """
    if agg_record is None:
        return

    num_records = agg_record.get_num_user_records()
    size_bytes = agg_record.get_size_bytes()
    partition_key, explicit_hash_key, raw_data = agg_record.get_contents()
    try:
        response = kinesis_client.put_record(
            StreamName=stream_name,
            Data=raw_data,
            PartitionKey=partition_key
        )
    except Exception as e:
        logger.exception('Transmission failed: {}'.format(e))
    else:
        logger.info(
            'push.kinesis_writer.put_record',
            kinesis_stream=stream_name,
            shard_id=response['ShardId'],
            partition_key=partition_key,
            num_records=num_records,
            size_bytes=size_bytes
        )


def run_threaded(job_func):
    job_thread = threading.Thread(target=job_func)
    job_thread.start()



class KinesisWriter:

    def __init__(self, stream_name, endpoint_url=None):
        self.kinesis_client = boto3.client(
            'kinesis',
            endpoint_url=endpoint_url
        )
        self.stream_name = stream_name
        self.kinesis_agg = RecordAggregator()
        self.kinesis_agg.on_record_complete(
            lambda agg_record: write_to_kinesis(self.kinesis_client, self.stream_name, agg_record)
        )

    def write(self, record):
        partition_key = "{}.{}".format(record['sta'], record['net'])
        self.kinesis_agg.add_user_record(
            partition_key,
            json.dumps(record),
        )

    def flush(self):
        """
        Flush the data we have aggregated so far to the kinesis stream, even if we haven't achieved optimal packet size
        yet.
        """
        logger.info('push.kinesis_writer.flush')
        write_to_kinesis(
            self.kinesis_client,
            self.stream_name,
            self.kinesis_agg.clear_and_get()
        )


class PickAPIWorker(Process):

    def __init__(self, thread_id, payload, result_queue):
        super().__init__()
        self.thread_id = thread_id
        self.payload = payload
        self.result_queue = result_queue

    def run(self):
        """
        Run our data through the PickerAPI.
        """
        logger.info(
            'picker.run.infer.start',
            instruments=len(self.payload['instruments']),
            thread_id=self.thread_id
        )
        with Timer() as compute_time:
            api = PickerAPI(
                host=settings.PICKER_API_HOST,
                port=settings.PICKER_API_PORT,
                token=settings.PICKER_API_TOKEN
            )
            response = api.pick.submit(body=self.payload)
        self.result_queue.put(json.dumps(response.body))
        logger.info(
            'picker.run.infer.done',
            compute_time=compute_time,
            thread_id=self.thread_id
        )


class PickRun:
    """
    Run a single pick iteration.
    """

    def __init__(self, state, starttime, binsize, samprate, kinesis_writer, present_time,mark_as_processed=True):
        self.state = state
        self.starttime = starttime
        self.binsize = binsize
        self.samprate = samprate
        self.kinesis_writer = kinesis_writer
        self.present_time=present_time
        self.mark_as_processed = mark_as_processed

    def __start(self):
        self.summary = PickRunStats()
        self.summary.binsize = self.binsize
        self.summary.starttime = self.starttime
        self.summary.samprate = self.samprate
        self.summary.state = 'start'
        self.summary.save()
        logger.info('picker.run.start', starttime=self.starttime, binsize=self.binsize)

    def __finish(self, state='done'):
        self.summary.cpu_percent = psutil.cpu_percent(interval=None)
        self.summary.load_1min = psutil.getloadavg()[0]
        self.summary.state = state
        self.summary.save()
        logger.info('picker.run.finish')



    def issue_request(self,complete_query_test_model, df_json_str, headers,result_queue):
        r = requests.post(complete_query_test_model, data=df_json_str, headers=headers)
        json_data_struct=r.json()
        print("Json struct")
        print(json_data_struct)
        message_used=json_data_struct['message']

        #Sometimes we get msg "Service unavailable which cannot be loaded into a list". If we can't load it, just treat it as an empty list item.
        try:
            message_list=json.loads(message_used) #<class 'list'> instead of string
        except:
            message_list=[]

        # if message_list:
            # print("Message")
            # print(message_list) #this works, recognizes the dictionary structure (of type string)

        result_queue.put([message_list])


    # def issue_request(self,complete_query_test_model, df_json_str, headers,result_queue):
    #     r = requests.post(complete_query_test_model, data=df_json_str, headers=headers)

    #     # print(r.json())
    #     json_data_struct=r.json()

    #     print("Json struct")
    #     print(json_data_struct)
    #     message_used=json_data_struct['message']
    #     '''
    #     There can be multiple picks in a list
    #     Message
    #     [{"sta": "RINB", "net": "CI", "loc": "--", "inst": "HN", "timestamp": 1622687413.318393, "type": "S"}]
    #     '''
    #     message_list=json.loads(message_used) #<class 'list'> instead of string

    #     if message_list:
    #         print("Message")
    #         print(message_list) #this works, recognizes the dictionary structure (of type string)

    #     result_queue.put([message_list])
    #     #put back this list in queue

    def batch(self):
        """
        Load data from the database.

        :rtype: QuerySet of TimeshiftedSampleSet

        7/6/21 RT UPDATE: In this iteration, we will get the head of the database (the last minute of data from the DB)
        """
        # with Timer() as query_time:
        #     data = self.state.tail(self.starttime, seconds=self.binsize)
        
        #First mod of head (but this wrt current traversal in DB)
        # with Timer() as query_time:
        #     data = self.state.head(self.starttime, seconds=self.binsize)
        
        #Second mod of head (but this wrt current traversal in DB)
        with Timer() as query_time:
            data = self.state.head(self.state.endtime, seconds=self.binsize)

        self.summary.query_time = query_time.elapsed
        self.summary.save()
        logger.info('picker.run.batch', query_time=query_time)
        return data

    def serialize_payload(self, sets):
        """
        Convert our TimeshiftedSampleSet data to a payload suitable for the PickerAPI.

        Returns a 2-tuple of (data, set_ids), where:

        * ``data`` is the payload for PickerAPI
        * ``set_ids`` is a list of TimeshiftedSampleSet object ids present in data

        :param sets QuerySet: a QuerySet of TimeshiftedSampleSets

        :rtype: tuple(dict, list(int))
        """
        with Timer() as serialize_time:
            stats = {}
            data = PickRunRequestSerializer((
                self.binsize,
                self.samprate,
                stats,
                sets
            )).data
            if (settings.PICKER_SPLIT_INSTRUMENTS > 1 and
                    len(data['instruments']) > settings.PICKER_MIN_SPLIT_INSTRUMENTS_LENGTH):
                k, m = divmod(len(data['instruments']), settings.PICKER_SPLIT_INSTRUMENTS)
                inst_groups = (
                    data['instruments'][i * k + min(i, m):(i + 1) * k + min(i + 1, m)]
                    for i in range(settings.PICKER_SPLIT_INSTRUMENTS)
                )
                new_data = []
                for g in inst_groups:
                    new_data.append({
                        'binsize': data['binsize'],
                        'samprate': data['samprate'],
                        'node_id': data['node_id'],
                        'instruments': g
                    })
                logger.info(
                    'picker.run.serialize.split',
                    total_instruments=len(data['instruments']),
                    splits=settings.PICKER_SPLIT_INSTRUMENTS,
                    groups=",".join([str(len(g['instruments'])) for g in new_data])
                )
                data = new_data
            else:
                data = [data]
        self.summary.n_instruments_total = stats['n_instruments_total']
        self.summary.n_samplesets_loaded = stats['n_samplesets_loaded']
        self.summary.n_samplesets_filtered = stats['n_samplesets_filtered']
        self.summary.n_instruments_good = sum([len(d['instruments']) for d in data])
        self.summary.serialize_time = serialize_time.elapsed
        self.summary.save()
        logger.info('picker.run.serialize', serialize_time=serialize_time)
        return data, stats['set_ids']

    def deserialize_picks(self, results):
        """
        De-serialize the pick data we got from PickerAPI.

        :param data dict: the JSON response from PickerAPI (deserialized to python primitives)

        :rtype: a rest_framework.serializers.Serializer populated with validated data.
        """
        serializer = PickRunResultsSerializer(data=results)
        with Timer() as deserialize_time:
            valid = serializer.is_valid()
        if not valid:
            raise ValueError('Bad Data from pick api: {}'.format(serializer.errors))
        logger.info(
            'picker.run.deserialize',
            deserialize_time=deserialize_time
        )
        return serializer

    def save_picks(self, serializer):
        """
        Save the pick data we got from the PickerAPI to the database

        :param serializer: a rest_framework.serializers.Serializer populated with validated data.
        """
        with Timer() as save_time:
            serializer.save()
        logger.info(
            'picker.run.save',
            save_time=save_time,
        )

    def format_pick_payload(self, data, timestamp, pick_type):
        return {
            'sta': data['station'],
            'net': data['network'],
            'loc': data['location'],
            'inst': data['instrument'],
            'timestamp': timestamp,
            'type': pick_type
        }

    def send_picks(self, data):
        """
        Push the pick events we got from the Picker API on to the Picks Kinesis stream.

        :param serializer: a rest_framework.serializers.Serializer populated with validated data.
        """
        with Timer() as send_time:
            picks = 0
            for waveform in data['pick_waveforms']:
                for pick in waveform['picks_p']:
                    self.kinesis_writer.write(self.format_pick_payload(waveform, pick, 'P'))
                    picks += 1
                for pick in waveform['picks_s']:
                    self.kinesis_writer.write(self.format_pick_payload(waveform, pick, 'S'))
                    picks += 1
        logger.info('picker.run.send', send_time=send_time, picks=picks)

    def write_picks_to_text(self,data,output_file):
        picks_file = open(output_file, 'a')
        count_picks=0

        for waveform in data['pick_waveforms']:
            # print("Waveform data")
            # print(waveform)

            sta=waveform['station']
            net=waveform['network']
            loc=waveform['location']
            inst=waveform['instrument']

            for pick in waveform['picks_p']:
                '''
                WLT CI HH S 2021-05-27T23:07:30.438392 0.443 0.210
                Net_sta_chan_phase_timestamp(iso)_probab_duration
                '''
                phase='P'
                picks_file.write("%s %s %s %s %s %s\n" % (sta, net, loc, inst, pick, phase)) 
                count_picks+=1         
            for pick in waveform['picks_s']:
                phase='S'
                picks_file.write("%s %s %s %s %s %s\n" % (sta, net, loc, inst, pick, phase)) 
                count_picks+=1         

        picks_file.close()
        return count_picks
         
    def mark_sets_as_processed(self, set_ids):
        """
        Update the sets we analyzed to mark them as processed

        :param set_ids list(int): a list of TimeshftedSampleSet object ids
        """
        if self.mark_as_processed:
            with Timer() as set_update_time:
                self.state.mark_sets_as_processed(set_ids)
            self.summary.set_update_time = set_update_time.elapsed
            self.summary.save()
            logger.info('picker.run.update-sets', set_update_time=set_update_time)

    def run(self, test=False):
        outputtime_file='timing_iterations.txt'
        timing_file = open(outputtime_file, 'a')

        try:
            #We can return the endtime of the latest sample wa have
            #see components\datastore\quakes2aws_datastore\core\models.py (class State has endtime)
            #see components\datastore\quakes2aws_datastore\picker\management\commands\pick.py (we took the starttime here; this gets us the update in realtime to DynamoDB
            # in the cloud, to let us see how much further behind we are going.)
            endtime = self.state.endtime
            earliesttime = self.state.starttime

            self.__start()
            # This is just to set the reference point for the next psutil.cpu_percent() call
            state = 'done'

            #Ryan added
            # output_file='picks_found.txt' #7/2/21 - in this case I'll write predicted picks inside other subfunctions

            now = datetime.now() # current date and time
            starting_format = now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-7]

            time_used="BLAH"

            #RT 7/6/21: Purposely sleep for 8 seconds to allow time to fill up data when batching (when in cloud/realtime mode)
            time.sleep(1) #prev 8
            complete_list=[]

            with Timer() as self.run_time:
                with Timer() as batch_time:
                    sets = self.batch() #7/1/21 RT I changed models.py sets such that it now returning .values(); modelsV2.py has the prior change

                '''
                Now we get a list of dictionaries, of all the filtered out sets we want.
                , {'id': 3388141, 'instrument_name': 'WRC2.CI.--.HH', 'channel_name': 'HHE', 'starttime': 1624435033.96839, 'endtime': 1624435034.95839,
                '''

                '''
                I am thinking instead of using the serializer which seems to take forever, why don't we just access the sets.data aspect and restructrure the data much like 
                we did with wavering_to_API.py? The constant serialization/deserialization seems to take too long.

                For a 16-second swath, organizes the data into the format we expect for the ML picker
                '''
                if sets:
                    with Timer() as get_stations_time:
                        station_list=[]
                        network_list=[]
                        channel_list=[]
                        location_list=[]
                        samprate_list=[]
                        startt_list=[]
                        endt_list=[]
                        datatype_list=[]
                        data_list=[]

                        for i, d in enumerate(sets):
                            '''
                            We look at our wavering_to_API.py filtered data, it is of this style
                            station,network,channel,location,samprate,startt,endt,datatype,data,inst
                            PLS,CI,HHE,--,100.0,1621970885.968392,1621970886.958392,i4,"[-264,
                            derive from: wavering_to_API.py
                            '''
                            # print("Set "+str(i)+" of "+str(len(sets))) #THIS WORKS!!!
                            # print(type(d)) #now we have a dictionary of values here

                            try:
                                seismic_station_name=d['instrument_name'].split('.')
                                station=seismic_station_name[0]
                                network=seismic_station_name[1]
                                location=seismic_station_name[2]
                                channel=d['channel_name']
                                samprate=d['samprate']
                                startt=d['starttime']
                                endt=d['endtime']

                                datatype='i4' #default stub
                                data=d['samples']

                                station_list.append(station)
                                network_list.append(network)
                                channel_list.append(channel)
                                location_list.append(location)
                                samprate_list.append(samprate)
                                startt_list.append(startt)
                                endt_list.append(endt)
                                datatype_list.append(datatype)
                                data_list.append(data)
                            except Exception as e: #sometimes we don't get data out of the station, in which case we skip (or continue)
                                print("Error encountered")
                                exc_type, exc_value, exc_traceback = sys.exc_info()
                                traceback.print_exception(exc_type, exc_value, exc_traceback,
                                                        limit=2, file=sys.stdout)

                        data_used = pd.DataFrame(list(zip(station_list,network_list,channel_list, location_list, samprate_list,startt_list,endt_list,datatype_list,data_list)), 
                                    columns =['station','network', 'channel', 'location', 'samprate','startt','endt','datatype','data']) 
                        '''
                        We recovered data of this format:
                        quakes2aws-datastore    | For given 16-second interval
                        quakes2aws-datastore    |       station  ...                                               data
                        quakes2aws-datastore    | 0        WRC2  ...  [1140, 1142, 1134, 1123, 1128, 1129, 1133, 113...
                        quakes2aws-datastore    | 1        WRC2  ...  [-135, -136, -135, -132, -136, -140, -124, -11...
                        quakes2aws-datastore    | 92009     HAR  ...  [-790, -871, -927, -955, -955, -922, -871, -78...
                        quakes2aws-datastore    | 92010     HAR  ...  [928, 897, 842, 766, 668, 560, 449, 331, 221, ...     
                        Sample rate is 100Hz, so 100 samples in the data
                        There can be 92011 rows as seen here
                        '''

                        data_used_filtered=data_used
                        goodinstruments_counter=0
                        totalinstruments_counter=0
                        number_picks=0

                        data_used_filtered['inst'] = data_used_filtered['channel'].astype(str).str[:2]

                        df_candidates = data_used_filtered[['station','network','inst']].drop_duplicates()
                        # print(len(df_candidates)) #175 unique combinations

                        # list_items=[]
                        # for _, row in df_candidates.iterrows():
                        #     sta_net_inst=row['station']+'.'+row['network']+'.'+row['inst']
                        #     list_items.append(sta_net_inst)
                        # print(list_items)
                        '''
                        ['WRC2.CI.HH', 'CJV2.CI.HH', 'WNM.CI.EH', 'TJR.CI.EH', 'HDH.CI.HH', 'PDR.CI.HH', 'SRI.CI.HH', 'CKP.CI.HH', 'RHR.CI.HH', 'RSI.CI.HH', 'RAG.CI.HH', 
                        'BHP.CI.HH', 'POB2.CI.HH', 'ARV.CI.HH', 'HOL.CI.HH', 'CGO.CI.HH', 'MUR.CI.HH', 'USC.CI.HH', 'RIO.CI.HH', 'WLT.CI.HH', 'HMT2.CI.HH', 'LMS.CI.HH', ...']
                        '''
                            
                        number_total_channels=(self.binsize)*3 #3 channels per instrument
                    
                    #Outside items (7/21 RT)
                    #If we run python api.py will be set to: http://127.0.0.1:12345/ (no port specified)
                    # url = 'http://127.0.0.1:12345'
                    # added_route='/predict'
                    # complete_query_test_model=url+added_route


                    complete_query_test_model='https://j3uqhhvyq2.execute-api.us-west-2.amazonaws.com/inference'
                    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}

                    '''
                    7/7/21: RT add multiprocessing for the prediction aspect
                    '''
                    with Timer() as process_stations_time:
                        result_queue = Queue()
                        predict_workers=[]

                        for _, row in df_candidates.iterrows():
                            
                            with Timer() as filtering_stations_time:
                                totalinstruments_counter+=1
                                # string_used='For '+row['station']+'-'+row['network']+'-'+row['inst']
                                df_complete=data_used_filtered[(data_used_filtered['station']==row['station']) & (data_used_filtered['network']==row['network']) & (data_used_filtered['inst']==row['inst'])]
                                # df_complete = df_complete[['station','network','channel','startt']].drop_duplicates() #RT!!!! Had to get rid of extra duplicates here too. 
                                df_complete = df_complete.drop_duplicates(subset=['station','network','channel','startt']) #RT!!!! Had to get rid of extra duplicates here too. (but need to keep specific items)
                                # print("Df complete: "+str(len(df_complete))+': desired channels: '+str(number_total_channels))
                                #Df complete: 120: desired channels: 123 (need it to be 120)
                                #Df complete: 117: desired channels: 120
                                # print(number_total_channels)

                            #if we have the right number of channels, we continue to process
                            #we might get EH channels, those aren't enough to process; HH and HN are likely most common
                            #different than csv file, our base is number_total_channels
                            #7/2/21 RT note: sometimes we can get 17 seconds of data bc we did a +1; starttime + seconds + 1
                            if len(df_complete)==number_total_channels-3 or len(df_complete)==number_total_channels or len(df_complete)==number_total_channels+3:
                                goodinstruments_counter+=1
                                # data_used_filtered = df_complete[['station','network','channel']].drop_duplicates()
                                data_used_final = df_complete
                                data_used_final_sorted=data_used_final.sort_values(by=['station', 'network','channel','startt'])

                                '''
                                7/21/21 RT update: At this pt, use wavering_to_API.py which multiprocesses the API requests for prediction
                                '''
                                #Cannot send the pandas dataframe to flask, can convert it to json so it can be read. 
                                #https://www.geeksforgeeks.org/how-to-convert-pandas-dataframe-into-json-in-python/#:~:text=To%20convert%20pandas%20DataFrames%20to%20JSON%20format%20we,by%20the%20functions%20and%20then%20explore%20the%20customization
                                df_json_str = data_used_final_sorted.to_json() #only string format

                                predict_worker=Process(target=self.issue_request, args=(complete_query_test_model, df_json_str, headers,result_queue))
                                predict_workers.append(predict_worker)
                                predict_worker.start()


                        results = [result_queue.get() for w in predict_workers]
                        for w in predict_workers:
                            w.join()
                        
                        for result in results:
                            list_dict_picks=result[0]

                            for item in list_dict_picks:
                                complete_list.append(item)
                        
                        number_picks+=len(complete_list)


                    good_instrument_ratio=str(goodinstruments_counter)+'/'+str(totalinstruments_counter)
                    # print("Number of good instruments for given seconds of data: "+str(goodinstruments_counter)+'/'+str(totalinstruments_counter))

                    #Below are timing subsets of the entire runtime
                    get_stations_time_elapsed=round(get_stations_time.elapsed,3)
                    process_stations_time_elapsed=round(process_stations_time.elapsed,3)
                    filtering_stations_time_elapsed=round(filtering_stations_time.elapsed,3)
                    # load_model_time_elapsed=round(load_model_time.elapsed,3)


                    #8/23/21: ADDED ALL THESE ITEMS to save out picks for comparison
                    #iterates across each record and prints out the record
                    list_of_records=[]
                    timestamps_used=[]
                    time_elapsed_list=[]
                    now = datetime.now() # current date and time
                    time_str = now.strftime("%Y_%m_%d")

                    #I forgot to add this (since we are not going into the api.py)
                    if not os.path.exists('GPD_PickLog'):
                        os.makedirs('GPD_PickLog')

                    output_file='GPD_PickLog/'+time_str+'_PIPELINEpicks.csv'


                    #DO SOME TESTING TO MAKE SURE WE CAN WRITE THE DICTIONARY INTO A S3 bucket (after all of the picks are retrieved back
                    #I will also report back the UTC time at this point to do some comparisons.
                    for dict_found in complete_list: #match is of type string within the list
                        # try:
                        match=json.dumps(dict_found) #convert dict to string
                        time_used=datetime.now()
                        datetime_obj_pacific = timezone('US/Pacific').localize(time_used) #our timestamps are in pacific time
                        now_utc = datetime_obj_pacific.astimezone(timezone('UTC')).replace(tzinfo=None) #get rid of timezone data
                        ts_used = datetime.timestamp(now_utc) #get the UTC timestamp now
                        time_elapsed=ts_used-float(dict_found['timestamp'])

                        list_of_records.append(match)
                        timestamps_used.append(ts_used)
                        time_elapsed_list.append(time_elapsed)
                        # except:
                        #     continue

                    #Need to see how long it takes to actually get the picks back when we are returning at high volume
                    d = {'RecordFound':list_of_records,'Retrieved':timestamps_used,'Elapsed':time_elapsed_list}
                    df = pd.DataFrame(d)
                    df.to_csv(output_file, mode='a', index=False, header=False) #set mode to append to edit onto it
                    
                    s3.upload_to_s3(output_file, output_file) #will also call the S3 bucket GPD_PickLog with the specific timestamps as well

                    #end 8/23/21 update

                    logger.info(
                        'runtime.subset.results',
                        good_instrument_ratio=good_instrument_ratio,
                        # load_model_time=load_model_time_elapsed,
                        get_stations_time=get_stations_time_elapsed,
                        process_stations_time=process_stations_time_elapsed,
                        filtering_stations_time=filtering_stations_time_elapsed
                    )
                else: #if we exceed the boundaries of the DB, catch up to it
                    state = 'no-data'

            alltime_elapsed=round(self.run_time.elapsed,3)

            with Timer() as write_totext_time:
                time_again = datetime.now() # current date and time
                fin_format = time_again.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-7]

                #Now let's move towards saving the timing metadata, as well as instruments/picks, in a text file
                if state == 'done':
                    timing_file.write("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n" % (" Time started running:", self.present_time, " Time finished:", fin_format,"Predtime_e:",str(alltime_elapsed)," Timestamp:", str(self.starttime), "Binsize:",str(self.binsize)," #PICKS", str(number_picks)," #INSTS", str(goodinstruments_counter)+'/'+str(totalinstruments_counter)," BatchState", state))
                else:
                    timing_file.write("%s %s %s %s %s %s %s %s %s %s\n" % (" Time started running:", self.present_time, "Predtime_e:",str(alltime_elapsed)," Timestamp:", str(self.starttime), "Binsize:",str(self.binsize)," BatchState", state))

                timing_file.close()
   
            '''
            RT 7/6/21 - We likely don't need to save picks to the DB, much less deserialize them
            Also we wrote the predicted picks to a text file already within our pickprediction.py code.
            so NO NEED:
            serializer = self.deserialize_picks(data) #Don't need to deserialize
            self.save_picks(serializer)
            count_picks=self.write_picks_to_text(data,output_file)

            WILL NEED:
            send picks back to kinesis (but deal with this after we are satisfied with the processing steps)

            We get back:
            string_dict_picks          
            settings.PICKS_KINESIS_STREAM_NAME          
            '''
            with Timer() as pushKinesis_time:
                if complete_list:
                    # print("Kinesis stream used for picks")
                    # print(settings.PICKS_KINESIS_STREAM_NAME)
                    with Timer() as send_time:
                        picks=0
                        for message in complete_list: #message is already a dict format
                            self.kinesis_writer.write(message)
                            picks+=1
                    logger.info('picker.run.send', send_time=send_time, picks=picks)

                #then flush at the end of getting all the picks
                # write_to_kinesis(kinesis_client,settings.PICKS_KINESIS_STREAM_NAME,kinesis_agg.clear_and_get())
                self.kinesis_writer.flush()

            #Get all global elapsed times to this point
            batch_time_elapsed=round(batch_time.elapsed,3)
            write_totext_time_elapsed=round(write_totext_time.elapsed,3)
            pushKinesis_time_elapsed=round(pushKinesis_time.elapsed,3)



            logger.info(
                'runtime.global.information',
                latestTS=str(endtime),
                earliestTS=str(earliesttime),
                presentTime=self.present_time,
                currentTS=str(self.starttime)
            )

            logger.info(
                'runtime.global.results',
                total_process_time=alltime_elapsed,
                batch_time=batch_time_elapsed,
                write_text_time=write_totext_time_elapsed,
                pushKinesis_time=pushKinesis_time_elapsed,
                num_picks_found=str(number_picks),
                state=state
            )

            self.__finish(state=state)
            return self.run_time.elapsed
        except Exception as e:
            # The first thing we can track is the early error logs that we have
            # print("Error encountered")
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_exception(exc_type, exc_value, exc_traceback,
                                      limit=2, file=sys.stdout)

            logger.info(
                'error.global.results',
                error_message=str(traceback.format_exc())
            )

            # with open(error_text, 'a') as f:
            timing_file.write("%s\n" % (str(e)))
            timing_file.write("%s\n" % (str(traceback.format_exc())))
            timing_file.close()

            return self.binsize #return a time by default 



class PickRunner:
    """
    Run the picker in a loop.
    """

    def __init__(self, starttime=None, count=None, no_sleep=False, live=True, mark_as_processed=True,test=False):
        """
        :param starttime float: start data going forward from this SampleSet starttime
        :param count int: do this many iterations, then stop
        :param no_sleep bool: don't sleep between iterations
        """
        self.state = State(live=live)
        logger.info('picker.boot')

        self.binsize = 30 #35, 16, 10, 30 <--all work
        #I added this starttime here so we can have a fixed starttime to deal with
        starttime = time.time() - settings.PICKER_DELAY_SECONDS - self.binsize

        self.__starttime = None
        if starttime:
            self.__starttime = starttime
        self.__count = count if count is not None else None
        self.no_sleep = no_sleep
        self.mark_as_processed = mark_as_processed

        self.samprate = settings.PICKER_SAMPLING_RATE_FILTER
        self.kinesis_writer = KinesisWriter(
            settings.PICKS_KINESIS_STREAM_NAME,
            endpoint_url=settings.KINESIS_ENDPOINT_URL
        )
        self.test=test

        #Introduced a stub value for comparison purposes; it starts at the end of the DB
        self.__stub=self.state.endtime #thought this could be None at first


    def __guess_starttime(self):
        starttime = time.time() - settings.PICKER_DELAY_SECONDS - self.binsize
        return starttime

    def __wait_for_enough_data(self):
        """
        Let ``settings.PICKER_DELAY_SECONDS`` seconds accumulate in the staging database before doing picks. This allows
        at least some late arriving packets to get here before we try to pick them.
        """
        while self.state.is_empty:
            logger.info('pick.starttime.no-data', sleep=self.binsize)
            time.sleep(self.binsize)
        wanted_starttime = self.__guess_starttime()
        oldest_sample = self.state.starttime
        while wanted_starttime < oldest_sample:
            logger.info(
                'picker.starttime.not-enough-data',
                wanted_starttime=wanted_starttime,
                oldest_sample=oldest_sample,
                delay_seconds=settings.PICKER_DELAY_SECONDS,
                binsize=self.binsize,
                sleep=self.binsize
            )
            time.sleep(self.binsize)
            wanted_starttime = self.__guess_starttime()
            oldest_sample = self.state.starttime

    @property
    def starttime(self):
        outputtime_file='timing_iterations.txt'
        timing_file = open(outputtime_file, 'a')

        if not self.__starttime: 
            #I don't think it ever starts here
            self.__wait_for_enough_data()
            starttime  = self.__guess_starttime()

            timing_file.write("%s\n" % (" Waiting for enough data"))
            timing_file.close()
        else:
            starttime = self.__starttime
            self.__starttime += self.binsize

            #RT added, feel like it iterates the data here:
            timing_file.write("%s %s\n" % (" Added starttime:", str(self.binsize)))
            timing_file.close()

        logger.info('picker.starttime', __startime=self.__starttime)
        return starttime

    def done(self):
        if self.__count is None:
            return False
        if self.__count == 0:
            return True
        self.__count -= 1
        return False

    #IMPLEMENTATION OF SCHEDULER HERE (via scheduleRunClass.py)
    def job(self):
        '''
        RT 7/6/21 - we can utilize the self.state here and get its endtime of the DB; if we see that the self.starttime
        exceeds the bounds of the DB, then we stay at that same starttime until the DB starts repopulating again (so
        we do not exceed its value. We will also not waste CPU resources by running the processor, either).

        In notes discussed doing this in PickRun but it will continue iterrating the self.starttime in other threads if we
        do so. Here we will literally end the job if it exceeds the DB, and will only start when there is enough data populated.

        I isolated the starttime here; we don't wnat to keep invoking self.starttime because that gets different valuese every time, our
        binsize keeps iterating with every call 

        7/7/21 - now self.starttime isn't that important other than recording where we are in the database 
        I want to avoid traversing the DB, but Chris already has it set up. Let's get it such that we traverse the DB, but we have a section
        where we want to catch up to the end of the DB (and don't process as it is catching up). Then once it catches up, it can process.

        We can use back Chris's old code and get last 15 seconds as well, but it would be sequential and would miss data without the scheduler.
        This is why Chris wanted to traverse the entire DB to try to get everything. 
        '''
        # start_time_used=self.starttime
        start_time_used=self.__starttime

        now = datetime.now() # current date and time
        starting_format = now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-7]
        present_time=starting_format

        outputtime_file='timing_iterations.txt'
        timing_file = open(outputtime_file, 'a')

        #Only if we are before or at the end of the DB do we run the picker algorithm to get the LATEST data. We then increment.
        #RT 7/7/21 changed start_time_usd to self.state.endtime in PickRun functionality. I'd assume running every minute, we can keep up.
        #RT 9/14/21 - introduced conditional for processing tnk files; the first conditional is for processing realtime live data 
        #NOte that for processing tnk files, we need to empty out the DB beforehand
        #conditional based on end time of DB; the moment we sense new data we start processing it, otherwise we are idling (whether beginning/end steps of tnk dump)
        if start_time_used<=self.state.endtime or self.state.endtime != self.__stub:
            timing_file.write("%s %s %s %s\n" % (" Starttime track:", str(start_time_used)," Current time:", present_time))
            timing_file.close()

            run_time = PickRun(
                self.state,
                self.state.endtime,
                self.binsize,
                self.samprate,
                self.kinesis_writer,
                present_time,
                mark_as_processed=self.mark_as_processed
            ).run(test=self.test)

            logger.info(
                'beginningOfNewJob',
                presentTime=present_time,
                currentTS=str(start_time_used),
                latestTS=str(self.state.endtime),
                binSize=self.binsize
            )

            #Then
            self.__stub=self.state.endtime
            incremented_time=self.starttime #value won't be used, but we NEED THIS to increment

            if not self.no_sleep: #never gets here, no_sleep in our code set as True
                if run_time < self.binsize:
                    sleep_time = self.binsize - run_time
                    logger.info('picker.sleep', sleep_time=sleep_time)
                    time.sleep(sleep_time)
                else:
                    logger.warning('picker.overrun', run_time=run_time)
        else: #too far ahead, do not write anything
            timing_file.write("%s %s %s %s %s %s %s\n" % ("Ahead of DB:", "Current Time:",starting_format,"Latest TS:",str(self.state.endtime),"Current TS:",str(start_time_used)))
            timing_file.close()

            logger.info(
                'caughtUpToDBSoIdle',
                latestTS=str(self.state.endtime),
                presentTime=starting_format,
                binSize=self.binsize,
                sampRate=self.samprate,
                currentTS=str(start_time_used)
            )


    def run_threaded(self,job_func):
        job_thread = threading.Thread(target=job_func)
        job_thread.start()

    def run(self, test=False):
        psutil.cpu_percent(interval=None)

        #Invoke the api call for predictions at the beginning
        # with Timer() as api_call_time:
        #     script_call = 'python api.py'  
        #     os.system(script_call)

        # api_call_time_elapsed=round(api_call_time.elapsed,3)
        # logger.info('api.call', apicall_time=api_call_time_elapsed)

        #Implementation of the scheduler: (every 16)-->change it to every 60 seconds here
        # schedule.every(16).seconds.do(self.run_threaded,self.job) #call the job method, not passing in as a solution (we get 16 seconds of data; schedule every 16 seconds)
        # schedule.every(40).seconds.do(self.run_threaded,self.job) #call the job method, not passing in as a solution (we get 16 seconds of data; schedule every 16 seconds)
        schedule.every(60).seconds.do(self.run_threaded,self.job) #call the job method, not passing in as a solution (we get 16 seconds of data; schedule every 16 seconds)

        while True: #previously while True, but keep consistent here; it should never stop as long as the container is running as __count is None not self.done()
            schedule.run_pending()




    # def run(self, test=False):
    #     psutil.cpu_percent(interval=None)

    #     present_time='N/A'

    #     while not self.done():
    #         run_time, present_time = PickRun(
    #             self.state,
    #             self.starttime,
    #             self.binsize,
    #             self.samprate,
    #             self.kinesis_writer,
    #             present_time,
    #             mark_as_processed=self.mark_as_processed
    #         ).run(test=test)
    #         if not self.no_sleep:
    #             if run_time < self.binsize:
    #                 sleep_time = self.binsize - run_time
    #                 logger.info('picker.sleep', sleep_time=sleep_time)
    #                 time.sleep(sleep_time)
    #             else:
    #                 logger.warning('picker.overrun', run_time=run_time)
