from django.db import models
from django.contrib.postgres.fields import ArrayField

from quakes2aws_datastore.core.models import Instrument


class PickProbabilityWaveform(models.Model):

    instrument = models.ForeignKey(
        Instrument,
        verbose_name='Instrument',
        on_delete=models.CASCADE,
        null=True,
        help_text='The instrument to which this pick relates',
        related_name='pick_waveforms'
    )

    starttime = models.FloatField(
        verbose_name='Start Time',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False
    )

    endtime = models.FloatField(
        verbose_name='End Time',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False
    )

    samprate = models.FloatField(
        verbose_name='Sampling Rate',
        help_text='Sampling rate in Hz for this sample set',
        editable=False
    )

    data_s = ArrayField(
        models.FloatField(),
        verbose_name='S-wave data',
        help_text='S-wave data for a pick',
        editable=False
    )

    data_p = ArrayField(
        models.FloatField(),
        verbose_name='P-wave data',
        help_text='P-wave data for a pick',
        editable=False
    )

    nsamples = models.IntegerField(
        verbose_name='Number of Samples',
        help_text='Number of samples stored in data_s and data_p',
        editable=False
    )

    max_data_s = models.FloatField(
        verbose_name="S-wave max",
        help_text="Maximum value of our S-wave trace",
        editable=False
    )

    max_data_p = models.FloatField(
        verbose_name="P-wave max",
        help_text="Maximum value of our P-wave trace",
        editable=False
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def json(self):
        return {
            'instrument_id': self.instrument.id,
            'starttime': self.starttime,
            'endtime': self.endtime,
            'samprate': self.samprate,
            'data_s': self.data_s,
            'data_p': self.data_p
        }

    class Meta:
        db_table = "pick_probability_waveform"
        verbose_name = "Pick Probability Waveform"
        verbose_name_plural = "Pick Probability Waveforms"
        ordering = ['instrument__station', 'instrument', 'starttime']
        index_together = [('instrument_id', 'starttime', 'endtime')]

    def __str__(self):
        return f'PickProbabilityWaveform(station={self.instrument.station.station_id}, instrument={self.instrument.instrument_id}, starttime={self.starttime}, endtime={self.endtime}, samprate={self.samprate})'  # noqa:E501


class PickEvent(models.Model):

    PICK_SOURCE_CHOICES = [
        ('P', 'P-wave'),
        ('S', 'S-wave'),
    ]

    instrument = models.ForeignKey(
        Instrument,
        verbose_name='Instrument',
        on_delete=models.CASCADE,
        null=True,
        help_text='The instrument to which this pick relates',
        related_name='picks'
    )

    probability_waveform = models.ForeignKey(
        PickProbabilityWaveform,
        verbose_name="Probability Waveform",
        on_delete=models.CASCADE,
        null=True,
        help_text='The probability waveform that this pick is from',
        related_name='picks'
    )

    timestamp = models.FloatField(
        verbose_name='Timestamp',
        help_text='Timestamp of the pick, with usec'
    )

    threshold = models.FloatField(
        verbose_name='Pick Threshold',
        help_text='The probability threshold used to detect this pick'
    )

    source = models.CharField(
        verbose_name="Pick Source",
        max_length=2,
        help_text="What kind of wave was this pick from? P or S?",
        choices=PICK_SOURCE_CHOICES,
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Pick(station={self.instrument.station.station_id}, instrument={self.instrument.instrument_id}, timestamp={self.timestamp}, source={self.source})'  # noqa:E501

    class Meta:
        db_table = "pick_event"
        verbose_name = "Pick"
        verbose_name_plural = "Picks"
        ordering = ['-created_at', 'timestamp']


class PickRunStats(models.Model):
    """
    Record some stats to monitor performance per pick run.
    """

    state = models.CharField(
        verbose_name='Pick state',
        max_length=10,
        help_text='At what point of the pick are we?',
        choices=(
            ('start', 'Started'),
            ('no-data', 'Finished: No Data'),
            ('done', 'Finished'),
        ),
        null=True
    )

    starttime = models.FloatField(
        verbose_name='Start Time',
        help_text='Start time of sample set in epoch seconds, with usec',
        editable=False
    )

    binsize = models.IntegerField(
        verbose_name='Binsize',
        help_text='Number seconds in this analysis',
        editable=False
    )

    n_instruments_total = models.IntegerField(
        verbose_name='Inst (loaded)',
        help_text='Number of instrument',
        editable=False,
        null=True
    )

    n_instruments_good = models.IntegerField(
        verbose_name='Inst (proc)',
        help_text='Number of instrument',
        editable=False,
        null=True
    )

    n_samplesets_loaded = models.IntegerField(
        verbose_name='Sets (loaded)',
        help_text='Number of sample sets loaded from the database',
        editable=False,
        null=True
    )

    n_samplesets_filtered = models.IntegerField(
        verbose_name='Sets (filtered)',
        help_text='Number of sample sets left after filtering by contiguous instrument',
        editable=False,
        null=True
    )

    n_picks = models.IntegerField(
        verbose_name='Picks',
        help_text='Number of picks',
        editable=False,
        null=True
    )

    run_time = models.FloatField(
        verbose_name='Run time (s)',
        help_text='Full run time in seconds',
        editable=False,
        null=True
    )

    def get_run_time_display(self):
        if self.run_time:
            return "{:0.2f}".format(self.run_time)
        return ''
    get_run_time_display.short_description = 'Run time'
    get_run_time_display.admin_order_field  = 'run_time'

    tail_time = models.FloatField(
        verbose_name='Tail time (s)',
        help_text='Time to retrieve and sort data from the database in seconds',
        editable=False,
        null=True
    )

    def get_tail_time_display(self):
        if self.tail_time:
            return "{:0.2f}".format(self.tail_time)
        return ''
    get_tail_time_display.short_description = 'Tail time'
    get_tail_time_display.admin_order_field  = 'tail_time'

    tail_query_time = models.FloatField(
        verbose_name='Tail: Query time (s)',
        help_text='Time to retrieve data from the database in seconds',
        editable=False,
        null=True
    )

    def get_tail_query_time_display(self):
        if self.tail_query_time:
            return "{:0.2f}".format(self.tail_query_time)
        return ''
    get_tail_query_time_display.short_description = 'Tail: query time'
    get_tail_query_time_display.admin_order_field  = 'tail_query_time'

    tail_serialize_time = models.FloatField(
        verbose_name='Tail: Serialize time (s)',
        help_text='Time to the data to JSON in seconds',
        editable=False,
        null=True
    )

    def get_tail_serialize_time_display(self):
        if self.tail_serialize_time:
            return "{:0.2f}".format(self.tail_serialize_time)
        return ''
    get_tail_serialize_time_display.short_description = 'Tail: serialize time'
    get_tail_serialize_time_display.admin_order_field  = 'tail_serialize_time'

    infer_time = models.FloatField(
        verbose_name='Inference time (s)',
        help_text='Time to run inference on the data in seconds',
        editable=False,
        null=True
    )

    def get_infer_time_display(self):
        if self.infer_time:
            return "{:0.2f}".format(self.infer_time)
        return ''
    get_infer_time_display.short_description = 'Infer time'
    get_infer_time_display.admin_order_field  = 'infer_time'

    save_time = models.FloatField(
        verbose_name='Pick save time (s)',
        help_text='Time to save the picks in seconds',
        editable=False,
        null=True
    )

    def get_save_time_display(self):
        if self.save_time:
            return "{:0.2f}".format(self.save_time)
        return ''
    get_save_time_display.short_description = 'Pick Save time'
    get_save_time_display.admin_order_field  = 'save_time'

    set_update_time = models.FloatField(
        verbose_name='SampleSet update time (s)',
        help_text='Time to update the sample sets as processed in seconds',
        editable=False,
        null=True
    )

    def get_set_update_time_display(self):
        if self.set_update_time:
            return "{:0.2f}".format(self.set_update_time)
        return ''
    get_set_update_time_display.short_description = 'Set Update time'
    get_set_update_time_display.admin_order_field  = 'set_update_time'

    cpu_percent = models.FloatField(
        verbose_name='CPU %',
        help_text='Current CPU Percentage',
        editable=False,
        null=True
    )

    load_1min = models.FloatField(
        verbose_name='1min Load',
        help_text='1min load average',
        editable=False,
        null=True
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "pick_run_stats"
        verbose_name = "Pick Run Statistics"
        verbose_name_plural = "Pick Run Statistics"
        ordering = ['created_at', 'starttime']
