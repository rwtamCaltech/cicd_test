from rest_framework import serializers

from quakes2aws.metadata import MetadataFactory

from quakes2aws_datastore.logging import logger
from quakes2aws_datastore.core.models import InstrumentDirectory

from .models import PickProbabilityWaveform, PickEvent


class PickRunRequestSerializer(serializers.Serializer):
    """

        {
            "binsize": 16,
            "samprate": 100.0,
            "node_id": "__NODE_ID__",
            "instruments": [
                {
                    "station": "ADO",
                    "network": "CI",
                    "location": "--",
                    "instrument": "EH",
                    "samprate": 100.0,
                    "starttime": 209412048.0,
                    "endtime": 209412049.0,
                    "channels": [
                        {
                            "channel": "EHE",
                            "data": [
                                12355,
                                12344,
                                ...
                                12312
                            ],
                        },
                        {
                            "channel": "EHN",
                            "data": [
                                ...
                            ],
                        },
                        {
                            "channel": "EHZ",
                            "data": [
                                ...
                            ],
                        {
                    }
                }
                ...
            ]
        }
    """

    @property
    def node_id(self):
        metadata = MetadataFactory.new()
        return metadata.get('local-hostname')

    def __filter_instruments(self, sets, seconds):
        """
        Return a list of instrument names for instruments found in ``sets`` with 3 channels with each channel having a
        ``seconds`` worth of sample sets.

        This is our first pass through the data to eliminate all instruments that have the wrong number of channels, or
        are obviously missing data.

        :param sets list(TimeShiftedSampleSet): a list of SampleSet instances
        :param seconds int: number of seconds that each channel in an instrument must have

        :rtype: tuple(list(str), int)
        """
        counts = {}
        total_sets = 0
        total_instruments = 0
        for s in sets:
            if s.instrument_name not in counts:
                counts[s.instrument_name] = {}
                total_instruments += 1
            if s.channel_name not in counts[s.instrument_name]:
                counts[s.instrument_name][s.channel_name] = 0
            counts[s.instrument_name][s.channel_name] += 1
            # We're doing this instead of len(sets) because sets is a QuerySet, and len(sets) will execute
            # the full query and load all our data into RAM, whereas this method is faster.
            total_sets += 1
        good = []
        #print(json.dumps(counts, indent=2))
        for instrument_name in counts:
            if (len(counts[instrument_name]) == 3 and
                    all([v >= seconds for v in counts[instrument_name].values()])):
                good.append(instrument_name)
        return good, total_sets, total_instruments

    def __new_instrument(self, sampleset):
        inst = {}
        (station, network, location, instrument) = sampleset.instrument_name.split('.')
        inst['station'] = station
        inst['network'] = network
        inst['location'] = location
        inst['instrument'] = instrument
        inst['samprate'] = sampleset.samprate
        if hasattr(sampleset, 'starttime_orig'):
            inst['starttime'] = sampleset.starttime_orig
            inst['endtime'] = sampleset.endtime_orig
        else:
            inst['starttime'] = sampleset.starttime
            inst['endtime'] = sampleset.endtime
        inst['channels'] = []
        return inst

    def to_representation(self, instance):
        """
        Return a payload suitable for sending to our picker web service.  The payload structure will be as described in
        the docstring for this class.

        ``instance`` is a tuple of (binsize, samprate, stats, sets) where:

        * ``binsize`` is our binsize in seconds
        * ``samprate`` is the sampling rate for all samples in Hz
        * ``stats`` is a dict for recording data to pass back to the caller
        * ``sets`` is a QuerySet returning TimeShiftedSampleSets

        Data problems we need to deal with:

            * Incomplete data -- samplesets missing.  this includes the start and end sets
            * Duplicate samplesets
            * Too many packets

        :param instance tuple(int, float, dict, QuerySet):

        :rtype:
        """
        (seconds, samprate, stats, sets) = instance
        good_instruments, total_sets, total_instruments = self.__filter_instruments(sets, seconds)
        stats['n_samplesets_loaded'] = total_sets
        stats['n_instruments_total'] = total_instruments
        data = {
            "binsize": seconds,
            "samprate": samprate,
            "node_id": self.node_id,
            "instruments": []
        }
        logger.info(
            'picker.run.serialize',
            binsize=seconds,
            samprate=samprate,
            node_id=self.node_id,
            total_sets=total_sets,
            total_instruments=total_instruments,
            good_instruments=len(good_instruments)
        )
        instruments = {}
        channels = {}
        stats['set_ids'] = []
        incomplete = set()
        for s in sets:
            if hasattr(s, 'endtime_orig'):
                endtime = s.endtime_orig
                starttime = s.starttime_orig
            else:
                endtime = s.endtime
                starttime = s.starttime
            if (s.instrument_name in good_instruments) and (s.instrument_name not in incomplete):
                if s.instrument_name not in instruments:
                    instruments[s.instrument_name] = self.__new_instrument(s)
                    channels[s.instrument_name] = {}
                inst = instruments[s.instrument_name]
                chans = channels[s.instrument_name]
                if s.channel_name not in chans:
                    chans[s.channel_name] = {
                        'channel': s.channel_name,
                        'sets': [],
                        'data': []
                    }
                    inst['channels'].append(chans[s.channel_name])
                if len(chans[s.channel_name]['sets']) < seconds:
                    # Sometimes we get ``seconds`` worth of data from our query; sometimes we get ``seconds + 1`` We
                    # only want ``seconds`` worth.  Assume the extra ones fall past the end of our time window and
                    # ignore them.
                    if (starttime - inst['endtime']) > .1:
                        # If we're here, we are missing one of more samplesets between this one and the last one we saw
                        # for this channel
                        logger.warning(
                            'picker.run.serialize.missing-set',
                            instrument=s.instrument_name,
                            channel=s.channel_name,
                            starttime=inst['endtime'],
                            endtime=starttime,
                            set_id=s.id
                        )
                        # Mark the instrument as missing data so we can purge it later
                        incomplete.add(s.instrument_name)
                        continue
                    # Deal with duplicate packets
                    set_key = (starttime, endtime)
                    if set_key not in chans[s.channel_name]['sets']:
                        chans[s.channel_name]['data'].extend(s.samples)
                        inst['endtime'] = endtime
                        # CPM: we shouldn't be storing the seen stations here, because they get sent off to the picker
                        #      API where they just add to the bandwidth and then are ignored during de-serialization
                        chans[s.channel_name]['sets'].append(set_key)
                        stats['set_ids'].append(s.id)
                    else:
                        # This is a duplicate sample set -- skip it
                        logger.warning(
                            'picker.run.serialize.duplicate-set.skipped',
                            instrument=s.instrument_name,
                            channel=s.channel_name,
                            starttime=starttime,
                            endtime=endtime
                        )
        stats['n_samplesets_filtered'] = len(stats['set_ids'])
        # Remove the instruments with missing data
        for instrument_name, inst in instruments.items():
            if (instrument_name not in incomplete):
                duration = inst['endtime'] - inst['starttime']
                if (duration <= seconds) and (duration > (seconds - 1)):
                    data['instruments'].append(inst)
                else:
                    # sometimes we get inst['endtime'] - inst['starttime'] > seconds
                    # even though there are only seconds samples.  This should mean
                    # that we're missing a sample at the beginning of one or more channels
                    # Thus, this instrument is incomplete
                    logger.warning(
                        'picker.run.serialize.instrument.wrong-duration',
                        instrument="{}.{}.{}.{}".format(
                            inst['station'],
                            inst['network'],
                            inst['location'],
                            inst['instrument']
                        ),
                        starttime=inst['starttime'],
                        endtime=inst['endtime'],
                        duration=(inst['endtime'] - inst['starttime'])
                    )
                    # purge the associated sets from stats['set_ids'] so that will not be not later
                    # marked as prcess
#                    for chan in inst['channels']:
#                        for s in chan['sets']:
#                            stats['set_ids'].remove(s.id)

        return data


class PickResultSerializer(serializers.Serializer):
    """
    {
        "station": "ADO",
        "network": "CI",
        "location": "--",
        "instrument": "EH",
        "samprate": 100.0,,
        "nsamples": 1600,
        "starttime": 209412048.0,
        "endtime": 209412049.0,
        "data_p": [
            12355.0,
            12344.0,
            ...
            12312.0
        ],
        "data_s": [
            ...
        ],
        "max_prob_p": 12355.0,
        "max_prob_s": 12355.0,
        "picks_p": [
           209412049.0,
            [...]
        ]
        "picks_s": [
           209412049.0,
            [...]
        ]
        "threshold": .5
    }
    """
    station = serializers.CharField(max_length=10)
    network = serializers.CharField(max_length=10)
    location = serializers.CharField(max_length=10)
    instrument = serializers.CharField(max_length=2)
    samprate = serializers.FloatField()
    nsamples = serializers.IntegerField()
    starttime = serializers.FloatField()
    endtime = serializers.FloatField()
    data_p = serializers.ListField(
        child=serializers.FloatField()
    )
    data_s = serializers.ListField(
        child=serializers.FloatField()
    )
    max_data_p = serializers.FloatField()
    max_data_s = serializers.FloatField()
    picks_p = serializers.ListField(
        child=serializers.FloatField()
    )
    picks_s = serializers.ListField(
        child=serializers.FloatField()
    )
    threshold = serializers.FloatField()

    def to_internal_value(self, data):
        data = super().to_internal_value(data)
        station_id = "{}.{}.{}".format(data['station'], data['network'], data['location'])
        data['instrument_id'] = InstrumentDirectory().get(
            station_id,
            data['instrument'],
            data['samprate']
        )
        return data


class PickRunResultsSerializer(serializers.Serializer):
    """
    Data format for returned pick data:

        {
            "node_id": "__NODE_ID__",
            "pick_waveforms": [
                {
                    "station": "ADO",
                    "network": "CI",
                    "location": "--",
                    "instrument": "EH",
                    "samprate": 100.0,,
                    "nsamples": 1600,
                    "starttime": 209412048.0,
                    "endtime": 209412049.0,
                    "data_p": [
                        12355.0,
                        12344.0,
                        ...
                        12312.0
                    ],
                    "data_s": [
                        ...
                    ],
                    "max_data_p": 12355.0,
                    "max_data_s": 12355.0,
                },
                {
                    "station": "BIC",
                    ...
                }
            ]
        }
    """
    node_id = serializers.CharField(max_length=64)
    pick_waveforms = PickResultSerializer(many=True)

    @property
    def node_id(self):
        metadata = MetadataFactory.new()
        return metadata.get('local-hostname')

    def make_event(self, data, waveform_id, timestamp, source):
        event = PickEvent()
        event.instrument_id = data['instrument_id']
        event.probability_waveform_id = waveform_id
        event.timestamp = timestamp
        event.source = source
        event.threshold = data['threshold']
        return event

    def create(self, validated_data):
        pick_waveforms = []
        # First the waveforms
        for p in validated_data['pick_waveforms']:
            pick_waveform = PickProbabilityWaveform()
            pick_waveform.instrument_id = p['instrument_id']
            pick_waveform.starttime = p['starttime']
            pick_waveform.endtime = p['endtime']
            pick_waveform.samprate = p['samprate']
            pick_waveform.nsamples = p['nsamples']
            pick_waveform.data_s = p['data_s']
            pick_waveform.data_p = p['data_p']
            pick_waveform.nsampes = p['nsamples']
            pick_waveform.max_data_s = p['max_data_s']
            pick_waveform.max_data_p = p['max_data_p']
            pick_waveforms.append(pick_waveform)
        PickProbabilityWaveform.objects.bulk_create(pick_waveforms, batch_size=1000)
        pick_ids = {(w.instrument_id, w.starttime): w.id for w in pick_waveforms}

        # Now for the PickEvents
        for p in validated_data['pick_waveforms']:
            if p['picks_s'] or p['picks_p']:
                pick_events = []
                pick_waveform_id = pick_ids[(p['instrument_id'], p['starttime'])]
                for e in p['picks_s']:
                    pick_events.append(self.make_event(p, pick_waveform_id, e, 'S'))
                for e in p['picks_p']:
                    pick_events.append(self.make_event(p, pick_waveform_id, e, 'P'))
                PickEvent.objects.bulk_create(pick_events, batch_size=1000)
        return pick_waveforms
