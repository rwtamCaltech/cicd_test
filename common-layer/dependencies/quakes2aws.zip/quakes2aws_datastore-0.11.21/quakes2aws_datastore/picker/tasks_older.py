import json
from multiprocessing import Process, Queue
import psutil
import time

from aws_kinesis_agg.aggregator import RecordAggregator
import boto3
from contexttimer import Timer
from django.conf import settings

from quakes2aws.picker.api import PickerAPI

from quakes2aws_datastore.logging import logger
from quakes2aws_datastore.core.models import State

from .models import PickRunStats
from .serializers import PickRunRequestSerializer, PickRunResultsSerializer

from quakes2aws_datastore.datastore.serializers import SnapshotSchema
from quakes2aws_datastore.api.serializers import SnapshotSerializer
from quakes2aws_datastore.models import DataSnapshot


def write_to_kinesis(kinesis_client, stream_name, agg_record):
    """
    Actually do a put_record to write some data to the Kinesis stream.
    """
    if agg_record is None:
        return

    num_records = agg_record.get_num_user_records()
    size_bytes = agg_record.get_size_bytes()
    partition_key, explicit_hash_key, raw_data = agg_record.get_contents()
    try:
        response = kinesis_client.put_record(
            StreamName=stream_name,
            Data=raw_data,
            PartitionKey=partition_key
        )
    except Exception as e:
        logger.exception('Transmission failed: {}'.format(e))
    else:
        logger.info(
            'push.kinesis_writer.put_record',
            kinesis_stream=stream_name,
            shard_id=response['ShardId'],
            partition_key=partition_key,
            num_records=num_records,
            size_bytes=size_bytes
        )


class KinesisWriter:

    def __init__(self, stream_name, endpoint_url=None):
        self.kinesis_client = boto3.client(
            'kinesis',
            endpoint_url=endpoint_url
        )
        self.stream_name = stream_name
        self.kinesis_agg = RecordAggregator()
        self.kinesis_agg.on_record_complete(
            lambda agg_record: write_to_kinesis(self.kinesis_client, self.stream_name, agg_record)
        )

    def write(self, record):
        partition_key = "{}.{}".format(record['sta'], record['net'])
        self.kinesis_agg.add_user_record(
            partition_key,
            json.dumps(record),
        )

    def flush(self):
        """
        Flush the data we have aggregated so far to the kinesis stream, even if we haven't achieved optimal packet size
        yet.
        """
        logger.info('push.kinesis_writer.flush')
        write_to_kinesis(
            self.kinesis_client,
            self.stream_name,
            self.kinesis_agg.clear_and_get()
        )


class PickAPIWorker(Process):

    def __init__(self, thread_id, payload, result_queue):
        super().__init__()
        self.thread_id = thread_id
        self.payload = payload
        self.result_queue = result_queue

    def run(self):
        """
        Run our data through the PickerAPI.
        """
        logger.info(
            'picker.run.infer.start',
            instruments=len(self.payload['instruments']),
            thread_id=self.thread_id
        )
        with Timer() as compute_time:
            api = PickerAPI(
                host=settings.PICKER_API_HOST,
                port=settings.PICKER_API_PORT,
                token=settings.PICKER_API_TOKEN
            )
            response = api.pick.submit(body=self.payload)
        self.result_queue.put(json.dumps(response.body))
        logger.info(
            'picker.run.infer.done',
            compute_time=compute_time,
            thread_id=self.thread_id
        )


class PickRun:
    """
    Run a single pick iteration.
    """

    def __init__(self, state, starttime, binsize, samprate, kinesis_writer, mark_as_processed=True):
        self.state = state
        self.starttime = starttime
        self.binsize = binsize
        self.samprate = samprate
        self.kinesis_writer = kinesis_writer
        self.mark_as_processed = mark_as_processed

    def __start(self):
        self.summary = PickRunStats()
        self.summary.binsize = self.binsize
        self.summary.starttime = self.starttime
        self.summary.samprate = self.samprate
        self.summary.state = 'start'
        self.summary.save()
        logger.info('picker.run.start', starttime=self.starttime, binsize=self.binsize)

    def __finish(self, state='done'):
        self.summary.cpu_percent = psutil.cpu_percent(interval=None)
        self.summary.load_1min = psutil.getloadavg()[0]
        self.summary.state = state
        self.summary.save()
        logger.info('picker.run.finish')

    def batch(self):
        """
        Load data from the database.

        :rtype: QuerySet of TimeshiftedSampleSet
        """
        with Timer() as query_time:
            data = self.state.tail(self.starttime, seconds=self.binsize)
        self.summary.query_time = query_time.elapsed
        self.summary.save()
        logger.info('picker.run.batch', query_time=query_time)
        return data

    def serialize_payload(self, sets):
        """
        Convert our TimeshiftedSampleSet data to a payload suitable for the PickerAPI.

        Returns a 2-tuple of (data, set_ids), where:

        * ``data`` is the payload for PickerAPI
        * ``set_ids`` is a list of TimeshiftedSampleSet object ids present in data

        :param sets QuerySet: a QuerySet of TimeshiftedSampleSets

        :rtype: tuple(dict, list(int))
        """
        with Timer() as serialize_time:
            stats = {}
            data = PickRunRequestSerializer((
                self.binsize,
                self.samprate,
                stats,
                sets
            )).data
            if (settings.PICKER_SPLIT_INSTRUMENTS > 1 and
                    len(data['instruments']) > settings.PICKER_MIN_SPLIT_INSTRUMENTS_LENGTH):
                k, m = divmod(len(data['instruments']), settings.PICKER_SPLIT_INSTRUMENTS)
                inst_groups = (
                    data['instruments'][i * k + min(i, m):(i + 1) * k + min(i + 1, m)]
                    for i in range(settings.PICKER_SPLIT_INSTRUMENTS)
                )
                new_data = []
                for g in inst_groups:
                    new_data.append({
                        'binsize': data['binsize'],
                        'samprate': data['samprate'],
                        'node_id': data['node_id'],
                        'instruments': g
                    })
                logger.info(
                    'picker.run.serialize.split',
                    total_instruments=len(data['instruments']),
                    splits=settings.PICKER_SPLIT_INSTRUMENTS,
                    groups=",".join([str(len(g['instruments'])) for g in new_data])
                )
                data = new_data
            else:
                data = [data]
        self.summary.n_instruments_total = stats['n_instruments_total']
        self.summary.n_samplesets_loaded = stats['n_samplesets_loaded']
        self.summary.n_samplesets_filtered = stats['n_samplesets_filtered']
        self.summary.n_instruments_good = sum([len(d['instruments']) for d in data])
        self.summary.serialize_time = serialize_time.elapsed
        self.summary.save()
        logger.info('picker.run.serialize', serialize_time=serialize_time)
        return data, stats['set_ids']

    def deserialize_picks(self, results):
        """
        De-serialize the pick data we got from PickerAPI.

        :param data dict: the JSON response from PickerAPI (deserialized to python primitives)

        :rtype: a rest_framework.serializers.Serializer populated with validated data.
        """
        serializer = PickRunResultsSerializer(data=results)
        with Timer() as deserialize_time:
            valid = serializer.is_valid()
        if not valid:
            raise ValueError('Bad Data from pick api: {}'.format(serializer.errors))
        logger.info(
            'picker.run.deserialize',
            deserialize_time=deserialize_time
        )
        return serializer

    def save_picks(self, serializer):
        """
        Save the pick data we got from the PickerAPI to the database

        :param serializer: a rest_framework.serializers.Serializer populated with validated data.
        """
        with Timer() as save_time:
            serializer.save()
        logger.info(
            'picker.run.save',
            save_time=save_time,
        )

    def format_pick_payload(self, data, timestamp, pick_type):
        return {
            'sta': data['station'],
            'net': data['network'],
            'loc': data['location'],
            'inst': data['instrument'],
            'timestamp': timestamp,
            'type': pick_type
        }

    def send_picks(self, data):
        """
        Push the pick events we got from the Picker API on to the Picks Kinesis stream.

        :param serializer: a rest_framework.serializers.Serializer populated with validated data.
        """
        with Timer() as send_time:
            picks = 0
            for waveform in data['pick_waveforms']:
                for pick in waveform['picks_p']:
                    self.kinesis_writer.write(self.format_pick_payload(waveform, pick, 'P'))
                    picks += 1
                for pick in waveform['picks_s']:
                    self.kinesis_writer.write(self.format_pick_payload(waveform, pick, 'S'))
                    picks += 1
        logger.info('picker.run.send', send_time=send_time, picks=picks)

    def write_picks_to_text(self,data,output_file):
        picks_file = open(output_file, 'a')

        for waveform in data['pick_waveforms']:
            # print("Waveform data")
            # print(waveform)

            sta=waveform['station']
            net=waveform['network']
            loc=waveform['location']
            inst=waveform['instrument']

            for pick in waveform['picks_p']:
                '''
                WLT CI HH S 2021-05-27T23:07:30.438392 0.443 0.210
                Net_sta_chan_phase_timestamp(iso)_probab_duration
                '''
                phase='P'
                picks_file.write("%s %s %s %s %s %s\n" % (sta, net, loc, inst, pick, phase))          
            for pick in waveform['picks_s']:
                phase='S'
                picks_file.write("%s %s %s %s %s %s\n" % (sta, net, loc, inst, pick, phase)) 

        picks_file.close()
         
    def mark_sets_as_processed(self, set_ids):
        """
        Update the sets we analyzed to mark them as processed

        :param set_ids list(int): a list of TimeshftedSampleSet object ids
        """
        if self.mark_as_processed:
            with Timer() as set_update_time:
                self.state.mark_sets_as_processed(set_ids)
            self.summary.set_update_time = set_update_time.elapsed
            self.summary.save()
            logger.info('picker.run.update-sets', set_update_time=set_update_time)

    def run(self, test=False):
        self.__start()
        # This is just to set the reference point for the next psutil.cpu_percent() call
        state = 'done'

        #Ryan added
        output_file='picks_found.txt'

        with Timer() as self.run_time:
            sets = self.batch()

            # print("Sets")
            # print(sets) #<QuerySet []>-->CANNOT be empty, but since it was empty, it never found data; changing the core/models.py would work but gets downstream API call errors.
            #Also changed entire core folder to reposQuakesOutbound version but that did not work. There are other changes I need to get this to work. 

            # print("Test")
            # print(test) #false (this has always been ok)

            if sets:
                data, set_ids = self.serialize_payload(sets)

                if not test:
                    workers = []
                    result_queue = Queue()
                    for i, d in enumerate(data):
                        # print("Data found")
                        # print(d)

                    # for i, d in enumerate(sets):
                        if not d['instruments']:
                            # Even though we retreived some sets, none of the channels were full
                            logger.warning('picker.run.no-data')
                            self.__finish(state='no-data')
                            return self.run_time.elapsed
                        
                        #to account for some location-based issues in the data
                        instrument_list=[]
                        for inst in d['instruments']:
                            # print(i['location'])
                            # print(type(i['location']))
                            if inst['location']=='':
                                inst['location']='--'
                        
                            #Only keep channels with size 1600, remove all other channels so we don't process them
                            inst['channels'] = [channel for channel in inst['channels'] if len(channel['data'])==d['binsize']*d['samprate']]

                            if len(inst['channels'])==3: #if all 3 channels for the given instrument are intact, then we can process that given instrument
                                instrument_list.append(inst)
                        d['instruments']=instrument_list #then we can modify the list accordingly, fixing the location and making sure the channels are of proper shape


                        # We're threading this here so we can take advantage of a cluster of picker nodes
                        worker = PickAPIWorker(i, d, result_queue)
                        workers.append(worker)
                        worker.start()
                    results = [result_queue.get() for w in workers]
                    for w in workers:
                        w.join()
                    for result in results:
                        data = json.loads(result)
                        serializer = self.deserialize_picks(data)
                        self.save_picks(serializer)
                        self.send_picks(data)

                        #Ryan add a function that saves the predicted picks into a txt file (derived from our end-to-end)
                        self.write_picks_to_text(data,output_file)

                    self.kinesis_writer.flush()

                    #Ryan change this?
                    self.mark_sets_as_processed(set_ids)

                else:
                    print("INSTRUMENTS TO BE PROCESSED: {}".format(sum([len(d['instruments']) for d in data])))
            else:
                state = 'no-data'
        self.__finish(state=state)
        return self.run_time.elapsed


class PickRunner:
    """
    Run the picker in a loop.
    """

    def __init__(self, starttime=None, count=None, no_sleep=False, live=True, mark_as_processed=True):
        """
        :param starttime float: start data going forward from this SampleSet starttime
        :param count int: do this many iterations, then stop
        :param no_sleep bool: don't sleep between iterations
        """
        self.state = State(live=live)
        logger.info('picker.boot')
        self.__starttime = None
        if starttime:
            self.__starttime = starttime
        self.__count = count if count is not None else None
        self.no_sleep = no_sleep
        self.mark_as_processed = mark_as_processed
        self.binsize = settings.PICKER_BIN_SECONDS
        self.samprate = settings.PICKER_SAMPLING_RATE_FILTER
        self.kinesis_writer = KinesisWriter(
            settings.PICKS_KINESIS_STREAM_NAME,
            endpoint_url=settings.KINESIS_ENDPOINT_URL
        )

    def __guess_starttime(self):
        starttime = time.time() - settings.PICKER_DELAY_SECONDS - self.binsize
        return starttime

    def __wait_for_enough_data(self):
        """
        Let ``settings.PICKER_DELAY_SECONDS`` seconds accumulate in the staging database before doing picks. This allows
        at least some late arriving packets to get here before we try to pick them.
        """
        while self.state.is_empty:
            logger.info('pick.starttime.no-data', sleep=self.binsize)
            time.sleep(self.binsize)
        wanted_starttime = self.__guess_starttime()
        oldest_sample = self.state.starttime
        while wanted_starttime < oldest_sample:
            logger.info(
                'picker.starttime.not-enough-data',
                wanted_starttime=wanted_starttime,
                oldest_sample=oldest_sample,
                delay_seconds=settings.PICKER_DELAY_SECONDS,
                binsize=self.binsize,
                sleep=self.binsize
            )
            time.sleep(self.binsize)
            wanted_starttime = self.__guess_starttime()
            oldest_sample = self.state.starttime

    @property
    def starttime(self):
        if not self.__starttime:
            self.__wait_for_enough_data()
            starttime  = self.__guess_starttime()
        else:
            starttime = self.__starttime
            self.__starttime += self.binsize
        logger.info('picker.starttime', __startime=self.__starttime)
        return starttime

    def done(self):
        if self.__count is None:
            return False
        if self.__count == 0:
            return True
        self.__count -= 1
        return False

    def run(self, test=False):
        psutil.cpu_percent(interval=None)
        while not self.done():
            run_time = PickRun(
                self.state,
                self.starttime,
                self.binsize,
                self.samprate,
                self.kinesis_writer,
                mark_as_processed=self.mark_as_processed
            ).run(test=test)
            if not self.no_sleep:
                if run_time < self.binsize:
                    sleep_time = self.binsize - run_time
                    logger.info('picker.sleep', sleep_time=sleep_time)
                    time.sleep(sleep_time)
                else:
                    logger.warning('picker.overrun', run_time=run_time)
