"""

Here's what a TRACEBUF2 packet from PyEarthworm looks like:

{ 'channel': 'HHN',
  'data': [ -195,
            -190,

            [...]

            -79,
            -83,
            -90,
            -86,
            -87],
  'datatype': 'i4',
  'endt': 1564769785.958393,
  'location': '--',
  'network': 'CI',
  'nsamp': 100,
  'samprate': 100.0,
  'startt': 1564769784.968393,
  'station': 'SMR'}

"""

import json
import logging

logger = logging.getLogger('quakes2aws.lib.models')


class Channel:

    """
    This class holds the data for a single channel in a single station.

    Stations have 2 sensors, and will have either 4 or 6 channels.

    If they have 4, the channels will be: EHZ, HNE, HNN, HNZ.  In this case, the EHZ comes from a dedicated up/down
    sensor, and the HN* come from a broad spectrum sensor.

    If they have 6, the channels will be: HHE, HHN, HHZ, HNE, HNN, HNZ.  In this case, HN* come from a broad spectrum
    sensor, and HH* come from a big motion sensor.

    .. note::

        Assume a channel always has the same sample size
    """

    def __init__(self, station_id, instrument_id, data=None):
        self.station_id = instrument_id
        self.instrument_id = instrument_id
        self.channel_id = ""
        self.sets = []
        if data:
            self.channel_id = data['channel']
            self.add_set(data)

    def __repr__(self):
        return "Channel({}.{}, starttime={}, endtime={}, sets={})".format(
            self.station_id,
            self.instrument_id,
            self.channel_id,
            self.starttime,
            self.endtime,
            len(self.sets)
        )

    def __add__(self, other):
        """
        Add the sample sets from Channel(other) to our self.sets if the former sample sets do not overlap the latter and
        return the resulting Channel.

        If ``other.station_id`` or `other.channel_id`` differ from ours, raise ValueError.

        :param other: A Channel to add to this channel
        :type other: Channel

        :rtype: Channel
        """
        if (self.station_id != other.station_id or
            self.instrument_id != other.instrument_id or
            self.channel_id != other.channel_id):
            raise ValueError('{} and {} do not represent data from the same channel'.format(repr(other), repr(self)))
        self.sets.extend(other.sets)
        return self

    @property
    def num_sample_sets(self):
        return len(self.sets)

    @property
    def samprate(self):
        try:
            return self.sets[0]['samprate']
        except IndexError:
            raise ValueError

    @property
    def starttime(self):
        return min([d['starttime'] for d in self.sets])

    @property
    def endtime(self):
        return max([d['endtime'] for d in self.sets])

    @property
    def duration(self):
        return self.endtime - self.starttime

    @property
    def is_empty(self):
        return len(self.sets) == 0

    def sorted(self):
        return sorted(self.sets, key=lambda d: d['starttime'])

    def purge(self, sample_set):
        """
        Remove the sample set matching ``sample_set`` from our self.sets list.

        :param sample_set: dict with keys "starttime", "endtime", "samprate" and "samples"
        """
        self.sets = [d for d in self.sets if d != sample_set]

    def add_set(self, data):
        """
        Add a new sample set to our self.sets.
        """
        self.sets.append({
            'starttime': data['startt'],
            'endtime': data['endt'],
            'samprate': data['samprate'],
            'samples': data['data']
        })

    def json(self):
        d = {}
        d['station_id'] = self.station_id
        d['instrument_id'] = self.instrument_id
        d['channel_id'] = self.channel_id
        d['sets'] = self.sorted()
        return d

    def load(self, d):
        self.station_id = d['station_id']
        self.instrument_id = d['instrument_id']
        self.channel_id = d['channel_id']
        self.sets = d['sets']


class Instrument:

    @staticmethod
    def instrument_id(channel_id):
        """
        Here are all the designations for different instrument types:

            * BH[ENZ]
            * EH[12Z]
            * EH[ENZ]
            * HH[ENZ]
            * HN[12Z]
            * HN[123]
            * HN[ENZ]

        I think we can assume that no single station will have both kinds of EH or HN sensors,
        so we can just return the first 2 chars of the `channel_id` to define the instrument.
        """
        return channel_id[0:2]

    def __init__(self, station_id):
        self.channels = {}
        self.station_id = station_id
        self.instrument_id = None

    def __repr__(self):
        return "Instrument({}.{}, channels={} starttimes={}, endtimes={})".format(
            self.station_id,
            self.instrument_id,
            ",".join(sorted(self.channel_ids)),
            ",".join(sorted([f"{k}:{v}" for k, v in self.starttimes.items()])),
            ",".join(sorted([f"{k}:{v}" for k, v in self.endtimes.items()]))
        )

    def __add__(self, other):
        """
        Add the channel data from Instrument(other) to ourselves, and return the resulting Instrument.

        If the data for any of the channels overlap, raise ValueError.

        :rtype: Station
        """
        if (self.station_id != other.station_id or self.instrument_id != other.instrument_id):
            raise ValueError('{} and {} do not represent data from the same instrument'.format(repr(other), repr(self)))
        channels = {}
        other_channel_ids = other.channel_ids
        for channel_id in self.channel_ids:
            if channel_id in other_channel_ids:
                # If self.channel and other.channel overlap, we'll get ValueError here
                channels[channel_id] = self.channel(channel_id) + other.channel(channel_id)
            else:
                # self has a channel that other doesn't
                channels[channel_id] = self.channel(channel_id)
        # Add any channels in other that we don't have in self
        for channel_id in other_channel_ids:
            if channel_id not in self.channel_ids:
                channels[channel_id] = other.channel(channel_id)
        self.channels = channels
        return self

    @property
    def channel_ids(self):
        """
        Return a list of the names of all the channels we have.

        :rtype: list of strings
        """
        return list(self.channels)

    def channel(self, channel_id):
        return self.channels[channel_id]

    @property
    def starttimes(self):
        """
        Return a dict of starttimes, where the keys are channel ids and the values are the startimes of the associated
        channel.
        """
        d = {}
        for c in self.channels.values():
            d[c.channel_id] = c.starttime
        return d

    @property
    def starttime(self):
        """
        Return the starttime of the oldest sample across all our channels.
        """
        return min(self.starttimes.values())

    @property
    def endtimes(self):
        """
        Return a dict of endtimes, where the keys are channel ids and the values are the endimes of the associated
        channel.
        """
        d = {}
        for c in self.channels.values():
            d[c.channel_id] = c.endtime
        return d

    @property
    def endtime(self):
        """
        Return the endtime of the newest sample across all our channels.
        """
        return min(self.endtimes.values())

    @property
    def samprate(self):
        # assume all channels have the same sampling rate
        return list(self.channels.values())[0].samprate

    def add_set(self, data):
        if data['channel'] not in self.channel_ids:
            channel = Channel(self.station_id, self.instrument_id)
            channel.channel_id = data['channel']
            self.channels[channel.channel_id] = channel
        self.channel(data['channel']).add_set(data)

    @property
    def is_empty(self):
        """
        Return True if we have no channels.
        """
        return not self.channels

    def json(self):
        d = {}
        d['station_id'] = self.station_id
        d['instrument_id'] = self.instrument_id
        d['channels'] = {c.channel_id: c.json() for c in self.channels.values()}
        return d

    def load(self, d):
        self.station_id = self.station_id
        self.instrument_id = self.instrument_id
        self.channels = {}
        for channel_id in d['channels']:
            channel = Channel(self.station_id, self.instrument_id)
            channel.channel_id = channel_id
            channel.load(d['channels'][channel_id])
            self.channels[channel_id] = channel


class Station:

    @staticmethod
    def station_id(data):
        return f"{data['station']}.{data['network']}.{data['location']}"

    def __init__(self, station_id):
        self.instruments = {}
        self.station_id = station_id
        self.station, self.network, self.location = station_id.split('.')

    def __repr__(self):
        return "Station({}, instruments={} starttimes={}, endtimes={})".format(
            self.station_id,
            ",".join(sorted(self.instrument_ids)),
            ",".join(sorted([f"{k}:{v}" for k, v in self.starttimes.items()])),
            ",".join(sorted([f"{k}:{v}" for k, v in self.endtimes.items()]))
        )

    def __add__(self, other):
        """
        Add the instrument data from Station(other) to ourselves, and return the resulting Station.

        If the data for any of the instruments overlap, raise ValueError.

        :rtype: Station
        """
        if self.station_id != other.station_id:
            raise ValueError('{} and {} do not represent data from the same station'.format(repr(other), repr(self)))
        instruments = {}
        other_instrument_ids = other.instrument_ids
        for instrument_id in self.instrument_ids:
            if instrument_id in other_instrument_ids:
                # If self.instrument and other.instrument overlap, we'll get ValueError here
                instruments[instrument_id] = self.instrument(instrument_id) + other.instrument(instrument_id)
            else:
                # self has a instrument that other doesn't
                instruments[instrument_id] = self.instrument(instrument_id)
        # Add any instruments in other that we don't have in self
        for instrument_id in other_instrument_ids:
            if instrument_id not in self.instrument_ids:
                instruments[instrument_id] = other.instrument(instrument_id)
        self.instruments = instruments
        return self

    @property
    def starttimes(self):
        """
        Return a dict of starttimes, where the keys are instrument ids and the values are the startimes of the
        associated instrument.
        """
        d = {}
        for i in self.instruments.values():
            d[i.instrument_id] = i.starttime
        return d

    @property
    def starttime(self):
        """
        Return the starttime of the oldest sample across all our instruments.
        """
        return min(self.starttimes.values())

    @property
    def endtimes(self):
        """
        Return a dict of endtimes, where the keys are instrument ids and the values are the endimes of the associated
        instruments.
        """
        d = {}
        for i in self.instruments.values():
            d[i.instrument_id] = i.endtime
        return d

    @property
    def endtime(self):
        """
        Return the endtime of the newest sample across all our instruments.
        """
        return min(self.endtimes.values())

    @property
    def samprate(self):
        """
        Different instruments might have different sampling rates?
        """
        return {i.instrument_id: i.samprate for i in self.instruments.values()}

    @property
    def instrument_ids(self):
        """
        Return a list of the names of all the instruments we have.

        :rtype: list of strings
        """
        return list(self.instruments)

    def instrument(self, instrument_id):
        return self.instruments[instrument_id]

    @property
    def is_empty(self):
        """
        Return True if we have no instruments.
        """
        return not self.instruments

    def add_set(self, data):
        instrument_id = Instrument.instrument_id(data['channel'])
        if instrument_id not in self.instrument_ids:
            self.instruments[instrument_id] = Instrument(self.station_id)
            self.instruments[instrument_id].instrument_id = instrument_id
        self.instrument(instrument_id).add_set(data)

    def json(self):
        d = {}
        d['station_id'] = self.station_id
        d['station'] = self.station
        d['network'] = self.network
        d['location'] = self.location
        d['instruments'] = {}
        for instrument_id in self.instrument_ids:
            d['instruments'][instrument_id] = self.instrument(instrument_id).json()
        d['starttime'] = self.starttime
        d['endtime'] = self.endtime
        return d

    def load(self, d):
        self.station_id = d['station_id']
        self.station = d['station']
        self.network = d['network']
        self.location = d['location']
        self.instruments = {}
        for instrument_id in d['instruments']:
            instrument = Instrument(self.station_id)
            instrument.instrument_id = instrument_id
            instrument.load(d['instruments'][instrument_id])
            self.instruments[instrument_id] = instrument


class DataSnapshot:
    """
    A class which holds all the stations, instruments, channels and sample sets that we've received from the Kinesis
    stream.

        DataSnapshot
            last_modified: float
            Station(A)
                Instrument(HH)
                    Channel(E)
                        SampleA-E-1
                        SampleA-E-2
                        SampleA-E-3
                        ...
                    Channel(N)
                        SampleA-N-1
                        SampleA-N-2
                        SampleA-N-3
                        ...
                    Channel(Z)
                        SampleA-Z-1
                        SampleA-Z-2
                        SampleA-Z-3
                        ...
                Instrument(HN)
                    Channel(E)
                        SampleA-E-1
                        SampleA-E-2
                        SampleA-E-3
                        ...
                    Channel(N)
                        SampleA-N-1
                        SampleA-N-2
                        SampleA-N-3
                        ...
                    Channel(Z)
                        SampleA-Z-1
                        SampleA-Z-2
                        SampleA-Z-3
                        ...
            Station(B)
                Instrument(HH)
                    Channel(E)
                        SampleB-E-1
                        SampleB-E-2
                        SampleB-E-3
                        ...
                    Channel(N)
                        SampleB-N-1
                        SampleB-N-2
                        SampleB-N-3
                        ...
                    Channel(Z)
                        SampleB-Z-1
                        SampleB-Z-2
                        SampleB-Z-3
                        ...
            ...
    """

    def __init__(self):
        self.stations = {}
        self.last_modified = 0.0

    def __repr__(self):
        return "DataSnapshot(stations={}, starttime={}, endtime={})".format(
            len(self.station_ids),
            self.starttime,
            self.endtime
        )

    @property
    def station_ids(self):
        """
        Return a list of the names of all the stations we have.

        :rtype: list of strings
        """
        return list(self.stations)

    @property
    def starttime(self):
        return min([s.starttime for s in self.stations.values()])

    @property
    def endtime(self):
        return max([s.endtime for s in self.stations.values()])

    @property
    def duration(self):
        return self.endtime - self.starttime

    @property
    def samprates(self):
        return list({s.samprate for s in self.stations.values()})

    def __add__(self, other):
        """
        Add the Station data from DataSnapshot(other) to ourselves, and return the resulting DataSnapshot.

        If the data for any of the channels overlap, raise ValueError.

        :rtype: DataSnapshot
        """
        stations = {}
        other_station_ids = other.station_ids
        for station_id in self.station_ids:
            if station_id in other_station_ids:
                # If self.station and other.station overlap, we'll get ValueError here
                stations[station_id] = self.stations[station_id] + other.stations[station_id]
            else:
                # self has a station that other doesn't
                stations[station_id] = self.stations[station_id]
        # Add any stations in other that we don't have in self
        for station_id in other_station_ids:
            if station_id not in self.station_ids:
                stations[station_id] = other.stations[station_id]
        self.stations = stations
        if self.last_modified < other.last_modified:
            self.last_modified = other.last_modified
        return self

    def add_set(self, data):
        try:
            station_id = Station.station_id(data)
            if station_id not in self.station_ids:
                self.stations[station_id] = Station(station_id)
            self.stations[station_id].add_set(data)
        except KeyError:
            # Sometimes we get bad packets
            logger.error('snapshot.add_set.failed data={}'.format(json.dumps(data)))

    @property
    def is_empty(self):
        return not self.stations

    def json(self):
        d = {}
        d['last_modified'] = self.last_modified
        d['stations'] = [s.json() for s in self.stations.values()]
        return d

    def load(self, d):
        """
        Reload our ourselves from a JSON dump produced by self.json().
        """
        self.stations = {}
        self.last_modified = d['last_modified']
        for s in d['stations']:
            station = Station(s['station_id'])
            station.load(s)
            self.stations[station.station_id] = station

    def save(self, key):
        raise NotImplementedError
