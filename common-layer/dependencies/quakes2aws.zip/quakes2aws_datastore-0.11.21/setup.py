#!/usr/bin/env python
from setuptools import setup, find_packages

setup(
    name="quakes2aws_datastore",
    version="0.11.21",
    python_requires='>=3.6',
    description="Quakes2AWS: DataStore",
    author="Caltech IMSS ADS",
    author_email="imss-ads-staff@caltech.edu",
    packages=find_packages(),
    package_data={
        'quakes2aws_datastore.users': [
            'fixtures/dev-users.json',
            'fixtures/dev-tokens.json',
        ]
    },
    include_package_data=True,
    zip_safe=False
)
